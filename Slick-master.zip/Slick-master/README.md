### Table of contents

1. [Introduction](#introduction)
	1. [About](#about)
	2. [General Architecture](#general-architecture)


2. [Installation](#installation)
    1. [Use config script or continue below](#config-script)
    
    1. [Clone Git Repository](#clone-git-repository)
    2. [Install Python](#setup-python-env)
          - [Windows](#setup-python-env-windows)
          - [Mac](#setup-python-env-mac)
    3. [Create "creds.py" file](#creds-file)
          - [PagerDuty API Token](#pagerduty-api-token)
          - [NewRelic API User Key](#newrelic-api-user-key)
          - [Jira Username/Password](#jira-username-password)
          - [Slack API Token](#slack-api-token)
          - [Device42 Username/Password](#device42-username-password)
          - [Github Access Token](#github-access-token)
          - [Kibana Session Cookies](#kibana-session-cookies)
    4. [Create User](#create-user)
          - [Create Django User](#create-django-user)
          - [Create SRER User](#create-srer-user)
    5. [Start application](#start-application)
          - [Load data](#load-data)
          - [Verify Login](#verify-login)


3. [Features](#features)
    1. [Operational Analytics](#operational-analytics)
          - [Charts](#pd-charts)
          - [PagerDuty Alerts](#pagerduty-alerts)
          - [NewRelic Incidents](#newrelic-incidents)
          - [NewRelic Alert Policies](#newrelic-alert-policies)
    2. [First Responder](#first-responder)
          - [Auto Acknowledge Alerts](#auto-acknowledge)
          - [Auto Resolve Watcher Alerts](#auto-resolve)
          - [Kibana/NewRelic Dasboards](#kibana-newrelic-dashboards)
          - [Active Jira Changes](#active-jira-changes)
          - [Expired Cert Admins List](#expired-cert-admins)
          - [Jira Ticket Creation](#jira-ticket-creation)
          - [Outstanding Alerts](#outstanding-alerts)
    3. [Changes in Progress](#changes-in-progress)
    4. [Knowledge Base](#knowledge-base)


4. [Scripts](#scripts)
    1. [Synthetic Accounts Password Rotation](#password-rotation)
    2. [RCA/RA Tickets Creation](#rca-ra-tickets-creation)
	

5. [Troubleshooting](#troubleshooting)
    1. [Database Queryset](#database-queryset)


6. [Uninstall](#uninstall)



## Introduction <a name="introduction"></a>

### About <a name="about"></a>
Slick application is developed for the use by Site Reliability Engineer Runtime (SRER) team. Main components of the application are Operational Analytics and First Responder tool. 


### General Architecture <a name="general-architecture"></a>

| | |
| ----------- | ----------- |
| ![](src/webapp/static/images/srer_fr_tool_architecture.png)      | ![](src/webapp/static/images/operational_analytics_architecture_v3.png)       |
| | |




## Installation <a name="installation"></a>

### Configuration script, recommend to use nonprod VPN <a name="config-script"></a>
1. Download configuration script from Github Repo: https://github.concur.com/SRER/Slick/blob/master/configure.sh or https://github.concur.com/SRER/Slick/blob/master/configure.ps1
2. Please use Powershell 7 for Windows script
3. Run script:
  * Windows: `.\configure.ps1 -cleanup -loaddata`
  * Linux: `./configure.sh -c -l`
4. Provide requested variables, be carefull when providing path to venv, if you want to have eg. C:\Users\user\Documents\frtool\Slick, use C:\Users\user\Documents\frtool only as Slick folder will be cloned from Git (same case for Linux and MacOS, just use OS specific paths)
5. Script will create all needed vars and start Slick. You can then start slick as usual.
* Windows: `& "C:\Users\Documents\frtool\Slick\Scripts\Activate.ps1" && python "$venv/Slick/src/manage.py" runserver`
* Linux: `source "/somepath/Slick/bin/activate" && python "/somepath/Slick/src/manage.py" runserver`
### Clone Git Repository <a name="clone-git-repository"></a>
1. Download GitHub Desktop from [https://desktop.github.com](https://desktop.github.com)
2. Open GitHub Desktop, Sign In to Concur GitHub by going to *Preferences* -> *Accounts* -> *GitHub Enterprise* -> *SignIn*, enter url [github.concur.com](https://github.concur.com) and follow instructions.
2. Open browser, sign into Concur GitHub and go to the Slick repository [https://github.concur.com/SRER/Slick](https://github.concur.com/SRER/Slick)
3. Click on ***Code*** and select ***Open With GitHub Desktop***
4. In GitHub Desktop, choose Local Path and append with ```/Slick``` and click ***Clone***


### Setup Python Virtual Environment <a name="setup-python-env"></a>

#### Following instructions for Windows OS <a name="setup-python-env-windows"></a>
##### Install Chocolatey
1. Open powershell with **Run as administrator** option
2. Enter command: `Set-ExecutionPolicy -Scope CurrentUser`
3. at the prompt, enter: `RemoteSigned`
4. `$script = New-Object Net.WebClient`
5. `$script.DownloadString("https://chocolatey.org/install.ps1")`
6. `iwr https://chocolatey.org/install.ps1 -UseBasicParsing | iex`
7. after installation, close and re-open powershell with *Run as administrator* option

##### Install python3/mysql
1. `choco install mysql -y`
2. `choco install python --version=3.9.0 -y`
3. `python -m pip install --upgrade pip`
4. after installation, close and re-open powershell with *Run as administrator* option

##### Create virtualenv
1. cd into the git cloned directory
1. `python -m venv venv`

##### Install packages
1. `source venv/bin/activate`
2. `pip install bin/mysqlclient-2.0.3-cp39-cp39-win_amd64.whl`
2. `pip install -r src/requirements.txt`


#### Following instructions for MacOS <a name="setup-python-env-mac"></a>
##### Install brew
1. `xcode-select --install`
2. `/bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/master/install.sh)"`

##### Install python3/mysql
1. `brew install mysql`
2. `brew install python@3.9`

##### Create virtualenv
1. cd into the git cloned directory
1. `python3 -m venv venv`

##### Install packages
1. `source venv/bin/activate`
2. `pip3 install -r src/requirements.txt`


### Create "creds.py" file<a name="creds-file"></a>
creds.py file contains credentials that are used by the application to connect to services such as PagerDuty, NewRelic, Kibana, Jira, Github etc.


create file and place it under ```Slick/src/webapp/creds.py```, below is the syntax:

```
pd_token = ''
nr_shared_api_key = ''
nr_uspscc_api_key = ''
jira_username = ''
jira_password = ''
github_token = ''
watcher_session = {
    'sea': 'BAh7C0kiD3Nlc3Npb25faWQGOgZFVEkiRTZiNjliNGRhOTUxYzVhOTk3YzRi%0AMjgxOWU5MjhmYmE5ZmViYWI3Yjg1ZDNiOWRlNjFhZmE0YjNmYzVjOTMxMTQG%0AOwBGSSINc2FtbF91aWQGOwBUSSISemFpbi5tb2hhbW1lZAY7AFRJIgtsb2dn%0AZWQGOwBGVEkiDXByb3ZpZGVyBjsARkkiCXNhbWwGOwBGSSIIdWlkBjsARkAJ%0ASSIOcmVtb3RlX2lwBjsARiIfMTAuMjA5LjYyLjgxLCAxMC4yMDUuNDUuMjA%3D%0A--88e74ff7c5a5111fd0c5ccf12eb13626c7e55042',
    'par': 'BAh7C0kiD3Nlc3Npb25faWQGOgZFVEkiRTdmYmMyOWE3YjBiYzkzYTA2Mjlm%0AZGUxM2IwMjk5OGQ1YzZlODA1YjVkMGVhZWE2ZWYzY2ZlNmE1YjA1MjFiMDEG%0AOwBGSSINc2FtbF91aWQGOwBUSSISemFpbi5tb2hhbW1lZAY7AFRJIgtsb2dn%0AZWQGOwBGVEkiDXByb3ZpZGVyBjsARkkiCXNhbWwGOwBGSSIIdWlkBjsARkAJ%0ASSIOcmVtb3RlX2lwBjsARiIgMTAuMjA5LjYyLjgxLCAxMC4yNDUuMTQ1LjEy%0A--c94d11e4a89c780e61622f330c0f0501d1e70652',
    'beipr1': ''
}
```

Follow below steps to fill all necessary credentials for different services

##### PagerDuty API Token <a name="pagerduty-api-token"></a>
1. Log in to [sap.pagerduty.com](https://sap.pagerduty.com)
2. From top right, click on User icon and select ***My Profile***
3. Click on ***User Settings***
4. From below, click on ***Create API User Token***
5. Type any name under Description and click ***Create Token***
6. Copy ***API User Token*** and paste into the creds.py under variable *pd_token* in single quotes  
	```pd_token = 'u+zjDahNcJLV7yAMwm-g'```


##### NewRelic API User Key <a name="newrelic-api-user-key"></a>
1. Login in to [Device42](https://seadevice4200.concurasp.com)
2. From **Resources**, select **All Secrets**
3. Under Search input, type *srer-new-relic-api-keys* and hit enter
4. Click on the returned entry
5. From **Notes:** section, copy *User* accounts keys and paste into creds file, using format: account_name__account_id = User Key (account name lowercase, double undersocre, account id)  
	```concur_travel__1301884 = 'NRAK-XXXXXXXXXXXXXXXXXXXXXXX'```  
	```concur_spend_management__1301883 = 'NRAK-XXXXXXXXXXXXXXXXXXXXXXX'```  
	```concur_shared__1280715 = 'NRAK-XXXXXXXXXXXXXXXXXXXXXXX'```  
	```concur_integration__2596260 = 'NRAK-XXXXXXXXXXXXXXXXXXXXXXX'```  
	```concur_analytics__1301885 = 'NRAK-XXXXXXXXXXXXXXXXXXXXXXX'```  
	```shared_platform_services__1301887 = 'NRAK-XXXXXXXXXXXXXXXXXXXXXXX'```  
	```prod_uspscc_hsm__2439350 = 'NRAK-XXXXXXXXXXXXXXXXXXXXXXX'```  
	```concur_imaging__1301886 = 'NRAK-XXXXXXXXXXXXXXXXXXXXXXX'```  


##### Jira Username/Password <a name="jira-username-password"></a>
Jira credentials are used to create tickets in Jira and also to get active *Changes In Progress* tickets. Your Jira Username and Password MAY NOT be same as your Okta, to confirm, try log in to Jira directly from here [https://jira.concur.com/login.jsp?nosso](https://jira.concur.com/login.jsp?nosso)

Once you validate your working Jira username and password, we will encode and use it in creds.py file.

1. To encode:
	* Mac, from terminal: ```echo -n "text" | od -A n -t x1 | sed 's/^ *//;s/ //g'``` 
	* Windows, from Powershell: ```("text"| Format-Hex | Select-Object -Expand Bytes | ForEach-Object { '{0:x2}' -f $_ }) -join ''```
2. Copy the encoded text from above and paste it into creds.py file under variable *jira_username* in single quotes.
3. Repeat steps 1 and 2 for Jira Password and paste in creds.py file under variable *jira_password* in single quotes   
	```jira_username = '6A697261757365726E616D65'```  
	```jira_password = '6A69726170617373776F7264'```


##### Slack API Token <a name="slack-api-token"></a>
1. Login in to [Device42](https://seadevice4200.concurasp.com)
2. From **Resources**, select **All Secrets**
3. Under Search input, type *slick-bot* and hit enter
4. Click on the returned entry
5. Copy and paste the password in creds.py file under variable *slack_api_token* in single quotes
	```
	slack_api_token = 'xoxb-3490251431-xxxxxxxxxx-xxxxxxxxxxxxxxxxx'
	```

##### Device42 Username/Password <a name="device42-username-password"></a>
Device42 credentials are used by the Synthetic Monitors password rotation script.

1. Use your credentials that is used to login into [https://seadevice4200.concurasp.com](https://seadevice4200.concurasp.com), and encode into Hex and pasted into *device42_username* and *device42_password*. Follow instructions from [Jira Username/Password section](jira-username-password) on how to Hex encode.

	```
	device42_username = '7A61696E2E6D6F68616D6D6564'
	device42_password = '646576696365343270617373776F7264'
	```


##### Github Access Token <a name="github-access-token"></a>
1. Log in to [github.concur.com](http://github.concur.com)
2. From top right, click on your profile icon and select **Settings** from the dropdown menu
3. Click on ***Developer Settings*** from the left side menu
4. Click on ***Personal access tokens*** from the left side menu
5. Click ***Generate new token***
6. Type any name and select below permission scopes. 
	```
	public_repo 
	read:discussion
	read:enterprise
	read:gpg_key
	read:org
	read:public_key
	read:repo_hook
	repo:invite
	repo:status
	repo_deployment
	user
	```

Click **Generate token** and copy highlighted token and paste in creds.py file under variable *github_token* in single quotes
 

##### Kibana Session Cookies <a name="kibana-session-cookies"></a>
Copy session keys from below and paste in creds.py file under variable *watcher_session*

```
{
    'sea': 'BAh7C0kiD3Nlc3Npb25faWQGOgZFVEkiRTZiNjliNGRhOTUxYzVhOTk3YzRi%0AMjgxOWU5MjhmYmE5ZmViYWI3Yjg1ZDNiOWRlNjFhZmE0YjNmYzVjOTMxMTQG%0AOwBGSSINc2FtbF91aWQGOwBUSSISemFpbi5tb2hhbW1lZAY7AFRJIgtsb2dn%0AZWQGOwBGVEkiDXByb3ZpZGVyBjsARkkiCXNhbWwGOwBGSSIIdWlkBjsARkAJ%0ASSIOcmVtb3RlX2lwBjsARiIfMTAuMjA5LjYyLjgxLCAxMC4yMDUuNDUuMjA%3D%0A--88e74ff7c5a5111fd0c5ccf12eb13626c7e55042',
    'par': 'BAh7C0kiD3Nlc3Npb25faWQGOgZFVEkiRTdmYmMyOWE3YjBiYzkzYTA2Mjlm%0AZGUxM2IwMjk5OGQ1YzZlODA1YjVkMGVhZWE2ZWYzY2ZlNmE1YjA1MjFiMDEG%0AOwBGSSINc2FtbF91aWQGOwBUSSISemFpbi5tb2hhbW1lZAY7AFRJIgtsb2dn%0AZWQGOwBGVEkiDXByb3ZpZGVyBjsARkkiCXNhbWwGOwBGSSIIdWlkBjsARkAJ%0ASSIOcmVtb3RlX2lwBjsARiIgMTAuMjA5LjYyLjgxLCAxMC4yNDUuMTQ1LjEy%0A--c94d11e4a89c780e61622f330c0f0501d1e70652',
    'beipr1': ''
}
```


### Create User <a name="create-user"></a>
 First Responder tool is login restricted, and only Users that exist in the database can access the application.

##### Create Django User <a name="create-django-user"></a>
 1. from command prompt, cd into the project src directory ```cd Slick/src``` 
 2. ```source ../venv/bin/activate```, on Windows: ```..\venv\Scripts\activate```
 3. to create User in the Django default *User* table that handles authentication, type ```python manage.py createsuperuser```
 4. enter Username, ideally your firstname.lastname
 5. enter Email address
 6. and then enter any password you wish to use for accessing First Responder tool



##### Create SRER User <a name="create-srer-user"></a>
We will be creating an entry in the *SRER* table for the previously created user. This table contains other User related fields, such as pagerduty_token, pagerduty_id, and region. We will add more fields to the *SRER* table in the future releases.


1. from command prompt, cd into the project src directory ```cd Slick/src```
2. ```source ../venv/bin/activate```, on Windows: ```..\venv\Scripts\activate```
3. ```python manage.py shell```
4. import python modules
	
	```
	from webapp.models import *
	from django.contrib.auth.models import User
	from webapp import creds
	```
3. create variables
	- username = this is same as previously entered username from ```python manage.py createsuperuser```
	- pagerduty_token = creds.pd_token
	- pagerduty_id = you can grab this from browser by logging to [sap.pagerduty.com](https://sap.pagerduty.com), then from top right click on profile icon and click on ***My Profile***. Copy UserId from URL ```https://sap.pagerduty.com/users/PJQIMXI```
	- region = choose from US, EMEA, APAC
	
	```
	username = 'zain.mohammed'
	pagerduty_token = creds.pd_token
	pagerduty_id = 'PJQIMXI'
	region = 'US'	
	```

4. create *SRER* user

	```
	user = User.objects.get(username=username)
	SRER.objects.update_or_create(user=user, defaults={'pagerduty_token': pagerduty_token, 'pagerduty_id': pagerduty_id, 'region': region})
	```


### Start application <a name="start-application"></a>

Execute the **startup.py** script located in project src directory to start application. To run manually follow below steps:

1. cd into the project src directory, ```cd Slick/src```
2. load virtualenv, ```source ../venv/bin/activate```, on Windows: ```..\venv\Scripts\activate```
4. apply database migrations, ```python manage.py migrate --no-input```
3. start application, ```python manage.py runserver```

#### Load data <a name="load-data"></a>
To update data from the GitHub repo *data/serialized* folder, run **startup.py** script with `--loaddata` flag.  
e.g. `./startup.py --loaddata`


#### Verify Login <a name="verify-login"></a>
From browser, go to *http://127.0.0.1:8000/first-responder* and enter your username and password


## Scripts <a name="scripts"></a>

### Synthetic Accounts Password Rotation <a name="password-rotation"></a>

```synthetic_accounts_pwd_rotation.py``` script is located under *src/webapp/scripts* directory, it is used for password rotation of Synthetic Accounts owned by SRER team.

script workflow identified are as follows:

- disable synthetics
- get current password from device42
- update password in CTE
- update password in synthetics
- update password in device42
- enable synthetics


##### Pre-Requisites <a name="pr-pre-requisites"></a>

- connect to the prod VPN
- device42 credentials is required to run the script, follow instructions on how to add credentials into creds.py file from [Device42 Username/Password section](device42-username-password)
- go to */synthetic-accounts* url and verify ***Auto-Rotate*** column for each secure credential before running the script 
- To modify/add/remove accounts shown in table at url */synthetic-accounts*, go to *admin/webapp/syntheticaccounts*.
	
    *Note: to login into */admin* page, login is required. See [Create User](#create-user) section if you don't already have an account.*
- To load initial data shown at */synthetic-accounts*, follow steps below:
```shell
docker exec -it slick-web bash
python manage.py shell
from webapp.scripts.synthetics import SyntheticsAPI
synthetics = SyntheticsAPI()
synthetics.add_accounts_monitors_to_db()
```

##### Running script <a name="pr-running-script"></a>

- Login into the docker container and execute the script:
```shell
docker exec -it slick-web bash
python manage.py shell
from webapp.scripts import synthetic_accounts_pwd_rotation as rotation
rotation.main()
```

- Script will list out all the affecting synthetic accounts and gives a warning text to confirm before proceeding, press Y and enter to continue
```shell
WARNING: This will reset password in CTE for above accounts, are you sure you want to continue? (Y/N): Y
```

- monitor the progress on screen for any errors/messages, in addition to that script will also log messages in *webapp/logs/add_accounts_monitors_to_db.log*

***Note***: script normally takes around 30 seconds for each password to update


### RCA/RA Tickets Creation <a name="rca-ra-tickets-creation"></a>

1. Log into the FR Tool
2. Select **Scripts** in the top menu bar
3. Select ***jira\_rca\_ra.py*** in the Scripts Details window located on the left side
4. Enter the **OPI ticket number** in the text box located on the right side of the Execute button. For example, enter OPI-5430022 in the text box.
5. Click on the **Execute** button to create the RCA and RA tickets
6. View the output window for results
7. Verify the OPI ticket in Jira to see if the RCA/RA tickets have been created successfully

**Create RCA/RA tickets via command line interface (CLI):**

**NOTE: You must have the Python virtual environment (venv) configured before executing commands via CLI.**

```cd Slick/src
source ../venv/bin/activate
python manage.py shell

from webapp.scripts import jira_rca_ra
jira_rca_ra.main('OPI-5430022')
```


## Features <a name="features"></a>

### Operational Analytics <a name="operational-analytics"></a>
#### Charts <a name="charts"></a>
#### PagerDuty Alerts <a name="pagerduty-alerts"></a>
#### NewRelic Incidents <a name="newrelic-incidents"></a>
#### NewRelic Alert Policies <a name="newrelic-alert-policies"></a>

### First Responder <a name="first-responder"></a>

#### Auto Acknowledge Alerts <a name="auto-acknowledge"></a>
#### Auto Resolve Watcher Alerts <a name="auto-resolve"></a>
#### Kibana/NewRelic Dasboards <a name="kibana-newrelic-dashboards"></a>
#### NewRelic Alert Policies <a name="newrelic-alert-policies"></a>
#### Active Jira Changes <a name="active-jira-changes"></a>
#### Expired Cert Admins List <a name="expired-cert-admins"></a>
#### Jira Ticket Creation <a name="jira-ticket-creation"></a>
#### Outstanding Alerts <a name="outstanding-alerts"></a>


### Changes in Progress <a name="changes-in-progress"></a>

### Knowledge Base <a name="knowledge-base"></a>
To be able to view documents in the Knowledge Base section, we need to create a symbolic link/shortcut from the Docs/docs Github repo into the Slick/src/webapp/static directory.

```shell
I541573@C02DM2D8MD6T git % pwd
/Users/I541573/Documents/git

I541573@C02DM2D8MD6T git % ls -ld Docs Slick
drwxr-xr-x  14 I541573  staff  448 Jul 17 23:08 Docs
drwxr-xr-x@ 15 I541573  staff  480 Dec  2 22:04 Slick

I541573@C02DM2D8MD6T git % cd Slick/src/webapp/static

I541573@C02DM2D8MD6T static % ln -s ~/Documents/git/Docs/docs .

I541573@C02DM2D8MD6T static % ls -l
total 0
drwxr-xr-x   5 I541573  staff  160 Nov 18 12:33 assets
drwxr-xr-x  19 I541573  staff  608 Nov 18 12:33 css
lrwxr-xr-x   1 I541573  staff   38 Dec  8 13:01 docs -> /Users/I541573/Documents/git/Docs/docs
drwxr-xr-x  18 I541573  staff  576 Nov 18 12:33 images
drwxr-xr-x  18 I541573  staff  576 Dec  2 22:04 js
I541573@C02DM2D8MD6T static %
```


## Troubleshooting <a name="troubleshooting"></a>
#### Database Queryset <a name="database-queryset"></a>


## Uninstall <a name="uninstall"></a>
