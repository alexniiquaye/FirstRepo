"""Slick URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/3.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from webapp.views import *
from webapp.api import *

urlpatterns = [
    path('admin/', admin.site.urls),
    path('login', login_view, name="login"),
    path('logout', logout_view, name='logout'),
    path('health', health, name='health'),

    path('', dashboard, name='main'),
    path('dashboard', dashboard, name='dashboard'),
    path('newrelic-incidents-data', newrelic_incidents_data, name='newrelic-incidents-data'),
    path('newrelic-alert-policies', newrelic_alert_policies, name='newrelic-alert-policies'),
    path('synthetic-accounts', synthetic_accounts, name='synthetic-accounts'),
    path('first-responder', first_responder, name='first-responder'),
    path('changes-in-progress', changes_in_progress, name='changes-in-progress'),
    path('change-history', change_history, name='change-history'),
    path('quick-links', quick_links, name='quick-links'),
    path('synthetics-health', synthetics_health, name='synthetics-health'),
    path('knowledge-base', knowledge_base, name='knowledge-base'),
    path('scripts', scripts, name='scripts'),
    path('pagerduty-muting', pagerduty_muting, name='pagerduty-muting'),

    # api's
    path('api/active-pagerduty-alerts', get_active_pd_alerts, name="active-pagerduty-alerts"),
    path('api/resolved-pagerduty-alerts', get_resolved_pd_alerts, name="resolved-pagerduty-alerts"),
    path('api/pagerduty-alerts', get_pagerduty_alerts, name="pagerduty-alerts"),
    path('api/pagerduty-alert-details/<alert_id>', pd_alert_details, name="pagerduty-alert-details"),
    path('api/newrelic-chart-data', nr_chart_data, name="newrelic-chart-data"),
    path('api/newrelic-violation-state', nr_violation_state, name="newrelic-violation-state"),
    path('api/newrelic-incident-close', nr_incident_close, name="newrelic-incident-close"),
    path('api/newrelic-incidents-data', nr_incidents_data_api, name="newrelic-incidents-data-api"),
    path('api/newrelic-alert-policies-api', nr_alert_policies_api, name="newrelic-alert-policies-api"),
    path('api/watcher-alert', watcher_alert, name='watcher-alert'),
    path('api/pagerduty-summary', get_pagerduty_summary, name="pagerduty-summary"),
    path('api/changes-in-progress', get_jira_changes, name='get-jira-changes'),
    path('api/get-cert-admins/<cert>', get_cert_admins, name='get-cert-admins'),
    path('api/create-jira-ticket/', create_jira_ticket, name='create-jira-ticket'),
    path('api/update-pagerduty-alert-status', update_pagerduty_alert_status, name='update-pagerduty-alert-status'),
    path('api/parse-pagerduty', parse_pagerduty, name='parse-pagerduty'),
    path('api/dashboard-kibana-chart', dashboard_kibana_chart, name='dashboard-kibana-chart'),
    path('api/dashboard-newrelic-chart', dashboard_newrelic_chart, name='dashboard-newrelic-chart'),
    path('api/pagerduty-alerts-list', pd_alerts_list, name="pagerduty-alerts-list"),
    path('api/pagerduty-escalation-policy', pd_escalation_policy, name='pagerduty-escalation-policy'),
    path('api/pagerduty-open-alerts-count', pd_open_alerts_count, name='pagerduty-open-alerts-count'),
    path('api/synthetics-monitors-list', synthetics_monitors_list, name='synthetics-monitors-list'),
    path('api/synthetics-alert-history', synthetics_alert_history, name='synthetics-alert-history'),
    path('api/synthetics-error-screenshot', synthetics_error_screenshot, name='synthetics-error-screenshot'),

    path('api/add-pagerduty-data', add_pagerduty_data, name="add-pagerduty-data"),
    path('api/pagerduty-services', get_pd_services, name="get-pd-services"),
    path('api/active-maintenance-windows', get_pd_maintenances, name="active-maintenance-windows"),
    path('api/set-maintenance-windows', set_pd_maintenances, name="set-maintenance-windows"),
    path('api/update-maintenance-windows/<maint_id>', update_pd_maintenances, name="update-maintenance-windows"),
    path('api/delete-maintenance-windows/<maint_id>', delete_pd_maintenances, name="delete-maintenance-windows"),

    path('api/pagerduty-top-alerts', pagerduty_top_alerts, name='pagerduty-top-alerts'),
    path('api/knowledge-base-doc', knowledge_base_doc, name='knowledge-base-doc'),
    path('api/knowledge-base-search', knowledge_base_search, name='knowledge-base-search'),
    path('api/knowledge-base-like', knowledge_base_like, name='knowledge-base-like'),
    path('api/knowledge-base-comment', knowledge_base_comment, name='knowledge-base-comment'),
    path('api/knowledge-base-edit', knowledge_base_edit, name='knowledge-base-edit'),

    path('api/script-details', script_details, name='script-details'),
    path('api/script-execute', script_execute, name='script-execute'),
    path('api/job-abort', job_abort, name='job-abort'),
    path('api/jobs-data', jobs_data, name='jobs-data'),
    path('api/events-data', events_data, name='events-data'),
    path('api/stream-job-output', stream_job_output, name='stream-job-output'),
    path('api/get-change-history', get_change_history, name='get-change-history'),

    path('test', test),
    path('api/test', api_test, name='api-test'),
]
