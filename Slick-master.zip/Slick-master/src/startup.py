#!/usr/bin/env python3

import os
import sys
import argparse
import subprocess


class Startup(object):
    def __init__(self):
        self.os = sys.platform
        self.environ = dict(os.environ, **{'PYTHONUNBUFFERED': '1', 'PYTHONDONTWRITEBYTECODE': '1'})

    def cleanup(self):
        if self.os == 'win32':
            activate_cmd = '..\\venv\\Scripts\\activate &&'
        else:
            activate_cmd = 'source ../venv/bin/activate;'

        check_migration = '''{0} python3 manage.py shell << EOF
from django.db.migrations.recorder import MigrationRecorder
qs = list(MigrationRecorder.Migration.objects.all().filter(name='0065_auto_20211126_0030').values_list('pk', flat=True))
print(qs)
EOF'''.format(activate_cmd)
        p = subprocess.Popen(check_migration, shell=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        output = p.stdout.readline()
        if not eval(output.strip().decode('utf-8')):
            drop_table = '''{0} python3 manage.py dbshell << EOF
DROP TABLE IF EXISTS webapp_scripts;
DROP TABLE IF EXISTS webapp_jobs;
EOF'''.format(activate_cmd)
            subprocess.Popen(drop_table, shell=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)

    def stop(self):
        if self.os == 'win32':
            p = subprocess.Popen('netstat -ano | findstr :8000 | findstr LISTENING', shell=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
            output = p.stdout.readline()
            if output:
                subprocess.Popen(['taskkill', '/PID', output.strip().split()[-1].decode('utf-8'), '/f'], shell=True)
        else:
            subprocess.Popen(['kill -9 $(lsof -ti :8000 -sTCP:LISTEN)'], shell=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)

    def run_server(self):
        if self.os == 'win32':
            return '..\\venv\\Scripts\\activate && python manage.py migrate --noinput && python manage.py runserver'
        else:
            return 'source ../venv/bin/activate; python3 manage.py migrate --noinput; python3 manage.py runserver'

    def load_data(self):
        if self.os == 'win32':
            return '..\\venv\\Scripts\\activate && python manage.py shell --command ' \
                   '"from webapp.scripts import migrations; migrations.main()"'
        else:
            return 'source ../venv/bin/activate; python3 manage.py shell --command ' \
                   '"from webapp.scripts import migrations; migrations.main()"'

    def run_command(self, command):
        process = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, env=self.environ)
        while True:
            output = process.stdout.readline()
            if process.poll() is not None:
                break
            if output:
                print(output.strip().decode('utf-8'))


def usage():
    parser = argparse.ArgumentParser()
    parser.add_argument('--loaddata', help='update database', required=False, action='store_true')
    return parser.parse_args()


def main():
    args = usage()
    startup = Startup()
    try:
        startup.cleanup()
        if args.loaddata:
            startup.run_command(startup.load_data())
        startup.stop()
        startup.run_command(startup.run_server())
    except KeyboardInterrupt:
        startup.stop()


if __name__ == '__main__':
    main()
