from rest_framework.decorators import api_view
from django.http import JsonResponse, HttpResponse, StreamingHttpResponse
from django.utils import timezone
from django.db import IntegrityError
from django.db.models import Count, Q, F
from django.db.models.functions import Extract

from webapp.models import *
from webapp.scripts import pagerduty_analysis
from webapp.scripts.add_pagerduty_data import PagerDutyData
from webapp.scripts import thycotic

import os
import re
import csv
import time
import json
import pytz
import yaml
import socket
import urllib3
import requests
import datetime
import subprocess
from jira import JIRA
from dateutil import parser
from webapp.scripts import multitasking

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)


@api_view(['GET'])
def get_active_pd_alerts(request):
    if request.method == 'GET':
        params = {
            'date_range': 'all',
            'sort_by': 'urgency:desc,created_at:desc',
            'include[]': ['services', 'priorities', 'privileges'],
            'exclude[]': 'subscriber_requests',
            'user_ids': '',
            'statuses[]': ['acknowledged', 'triggered'],
            'current_user': request.user.srer.pagerduty_id,
            'on_my_teams': 'true',
            'with_suppressed': 'true'
        }

        headers = {
            'content-type': 'application/json',
            'authorization': f'Token token={request.user.srer.pagerduty_token}',
        }

        try:
            offset = 0
            more = True
            incidents = []
            while more:
                response = requests.get('https://sap.pagerduty.com/api/v1/incidents', params=params, headers=headers)
                incidents.extend(response.json()['incidents'])
                more = response.json()['more']
                offset += response.json()['limit']
                params['offset'] = offset
                if response.reason != 'OK':
                    raise Exception(response.reason)
            return JsonResponse({'incidents': incidents})
        except Exception as error:
            return JsonResponse({'error': str(error)})
    return JsonResponse(None, safe=False)


@api_view(['GET'])
def get_pd_services(request):
    offset, limit, more, services = 0, 100, True, []
    try:
        while more:
            params = (
                ('team_ids[]', 'PVKSDSW'),
                ('limit', limit),
                ('offset', offset),
                ('total', 'true')
            )
            headers = {
                'content-type': 'application/json',
                'authorization': f'Token token={request.user.srer.pagerduty_token}',
            }
            response = requests.get('https://sap.pagerduty.com/api/v1/services', params=params, headers=headers)
            if response.reason != 'OK':
                raise Exception(response.reason)
            services.extend(response.json()['services'])
            offset += limit
            more = response.json()['more']
        return JsonResponse({'services': services})
    except Exception as error:
        return JsonResponse({'error': str(error)})


@api_view(['GET'])
def get_resolved_pd_alerts(request):
    if request.method == 'GET':
        hours_ago = request.GET.get('hours-ago', 1)
        headers = {
            'content-type': 'application/json',
            'authorization': f'Token token={request.user.srer.pagerduty_token}',
        }

        until = datetime.datetime.utcnow()
        since = (until - datetime.timedelta(hours=int(hours_ago)))

        # services = get_pd_services(request)
        # if isinstance(services, Exception):
        #     raise Exception(services)

        services = {'services': ['PWOPSSU', 'PSC1RD4', 'PZKAT4H', 'PN85W7D', 'PDWLTH7', 'PP2DR0E', 'P9Y06EO', 'P0LCA3Q',
                                 'PQ7O7TB', 'PDV9X60', 'PTGZ861', 'PS68G9Y', 'P8Y9BQQ', 'PVZH9QS', 'PS0W8B2', 'PZ95N2F',
                                 'PKDIYXD', 'PCITNF5', 'POR87LC', 'PXMB8LG', 'PBYM9B6', 'PXW3MGB', 'PF8NNQW', 'P0WO5HZ',
                                 'PJSX64G', 'P45Z6WM', 'PZILWTA', 'P7EK79P', 'PFG95ST', 'POFXWDT', 'P869W13', 'PSRIXSG',
                                 'PUN5106', 'PW16Y56', 'P4WLVOD', 'PC22P01', 'PR759IL', 'PYSEONB', 'P6LW8U8', 'PUGTNYO',
                                 'PNXH96Y', 'P17GOJB', 'PK42P6I', 'P4H4PZ1', 'PH4XXIQ', 'P8TSQOR', 'PGUEOUV']}

        offset, limit, more, entries = 0, 100, True, []
        try:
            while more:
                params = (
                    ('since', since.strftime('%Y-%m-%dT%H:%M:%S.00Z')),
                    ('until', until.strftime('%Y-%m-%dT%H:%M:%S.00Z')),
                    ('limit', limit),
                    ('offset', offset),
                    ('time_zone', 'UTC'),
                    ('sort_by_direction', 'asc'),
                    ('statuses[]', ['resolved']),
                    ('service_ids[]', services['services']),
                    ('include[]', ['first_trigger_log_entries']),
                    ('total', 'true')
                )
                response = requests.get('https://sap.pagerduty.com/api/v1/incidents', params=params, headers=headers)
                if response.reason != 'OK':
                    raise Exception(response.reason)
                entries.extend(response.json()['incidents'])
                offset += limit
                more = response.json()['more']
            return JsonResponse({'incidents': entries})
        except Exception as error:
            return JsonResponse({'error': str(error)})
    return JsonResponse(None, safe=False)


@api_view(['GET'])
def nr_alert_policies_api(request):
    if request.method == 'GET':
        account_id = request.GET.get('account_id', None)
        product = request.GET.get('product', None)

        qs = NrAlertConditions.objects.all()

        if account_id:
            qs = qs.filter(policy__account__account_id__in=account_id.split(','))

        if product:
            qs = qs.filter(product__in=product.split(','))

        results = list(qs.values('created_at', 'name', 'policy__policy_id', 'policy__name', 'policy__account__account_id', 'policy__account__name', 'product', 'description'))
        return JsonResponse({'results': results, 'count': qs.count()})
    return JsonResponse(None, safe=False)


@api_view(['GET'])
def nr_incidents_data_api(request):
    if request.method == 'GET':
        account_id = request.GET.get('account_id', None)
        event = request.GET.get('event', None)
        priority = request.GET.get('priority', None)
        entity_type = request.GET.get('entity_type', None)
        daterange = request.GET.get('daterange', None)
        locale = request.GET.get('locale', 'utc')
        qs = NrAiIncident.objects.all()

        if account_id:
            qs = qs.filter(account_id__in=account_id.split(','))

        if event:
            qs = qs.filter(event__in=event.split(','))

        if priority:
            qs = qs.filter(priority__in=priority.split(','))

        if entity_type:
            qs = qs.filter(entity_type__in=entity_type.split(','))

        if daterange:
            start_date, end_date = (daterange.split(' - ')[0], daterange.split(' - ')[1])
            start_date = pytz.timezone(locale).localize(parser.parse(start_date))
            end_date = pytz.timezone(locale).localize(parser.parse(end_date))
        else:
            end_date = qs.order_by('timestamp').last().timestamp
            start_date = end_date - datetime.timedelta(days=1)

        qs = qs.filter(timestamp__range=(start_date, end_date))

        return JsonResponse({'results': list(qs.values()), 'count': qs.count(), 'start_date': start_date, 'end_date': end_date,})
    return JsonResponse(None, safe=False)


@api_view(['GET'])
def get_pagerduty_alerts(request):
    if request.method == 'GET':
        daterange = request.GET.get('daterange', None)
        service_names = request.GET.get('service_names', None)
        alert_types = request.GET.get('alert_types', None)
        datacenters = request.GET.get('datacenters', None)
        timezones = request.GET.get('timezones', None)
        day_of_week = request.GET.get('day_of_week', None)
        locale = request.GET.get('locale', 'utc')

        qs = PagerDuty.objects.all()

        if daterange:
            start_date, end_date = (daterange.split(' - ')[0], daterange.split(' - ')[1])
            start_date = pytz.timezone(locale).localize(parser.parse(start_date))
            end_date = pytz.timezone(locale).localize(parser.parse(end_date))
        else:
            end_date = qs.order_by('created_on').last().created_on
            start_date = end_date - datetime.timedelta(days=14)

        qs = qs.filter(created_on__range=(start_date, end_date))

        if service_names:
            qs = qs.filter(service_name__in=service_names.split(','))

        if alert_types:
            query = Q()
            for alert in alert_types.split(','):
                if alert == 'synthetics':
                    query.add(Q(description__icontains='synthetics'), Q.OR)
                else:
                    query.add(Q(description__iregex=r'(-error|-rt|-rpm|-avail)'), Q.OR)
            qs = qs.filter(query)

        if datacenters:
            query = Q()
            for datacenter in datacenters.split(','):
                if datacenter == 'paris':
                    query.add(Q(description__iregex=r'(par|emea)'), Q.OR)
                elif datacenter == 'uspscc':
                    query.add(Q(description__iregex=r'(ccps|pscc|uspscc)'), Q.OR)
                elif datacenter == 'beijing':
                    query.add(Q(description__iregex=r'(bei|china)'), Q.OR)
                elif datacenter == 'seattle':
                    query.add(~Q(description__iregex=r'(par|emea|ccps|pscc|uspscc|bei|china)'), Q.OR)
            qs = qs.filter(query)

        if timezones:
            query = Q()
            apac = 23 if bool(end_date.dst()) else 0
            apac = (apac, apac + 7 - 24 if bool(end_date.dst()) else apac + 7)
            emea = (apac[1] + 1, apac[1] + 1 + 7)
            amers = (emea[1] + 1, emea[1] + 1 + 7)
            apac_query = Q(created_on__hour__gte=apac[0]) | Q(created_on__hour__lte=apac[1]) if bool(
                end_date.dst()) else Q(created_on__hour__gte=apac[0]) & Q(created_on__hour__lte=apac[1])
            emea_query = Q(created_on__hour__gte=emea[0]) & Q(created_on__hour__lte=emea[1])
            amers_query = Q(created_on__hour__gte=amers[0]) & Q(created_on__hour__lte=amers[1])

            for timezone in timezones.split(','):
                if timezone == 'apac':
                    query.add(apac_query, Q.OR)
                elif timezone == 'emea':
                    query.add(emea_query, Q.OR)
                elif timezone == 'amers':
                    query.add(amers_query, Q.OR)
            qs = qs.filter(query)

        if day_of_week:
            qs = qs.filter(created_on__week_day__in=day_of_week.split(','))

        top_alerts = list(qs.values('description').annotate(count=Count('description')).order_by('count').reverse()[:10])
        top_alerts = [
            {'description': re.sub('_CRITICAL -.*', '_CRITICAL', i['description'].replace('[watcher] ', '')),
             'count': i['count']
             } for i in top_alerts
        ]

        datacenters_count = list(qs.values('urgency').annotate(
                        Seattle=Count('id', filter=~Q(description__iregex=r'(par|emea|ccps|pscc|uspscc|bei|china)')),
                        Paris=Count('id', filter=Q(description__iregex=r'(par|emea)')),
                        Beijing=Count('id', filter=Q(description__iregex=r'(bei|china)')),
                        uspscc=Count('id', filter=Q(description__iregex=r'(ccps|pscc|uspscc)')),
        ).values('Paris', 'uspscc', 'Beijing', 'Seattle'))
        if datacenters_count:
            datacenters_count = [{'category': k, 'value': v} for k, v in list(datacenters_count)[0].items()]

        sli_count = list(qs.values('urgency').annotate(
                        Error=Count('id', filter=Q(description__icontains='-error')),
                        Latency=Count('id', filter=Q(description__icontains='-rt')),
                        Capacity=Count('id', filter=Q(description__icontains='-rpm')),
                        Availability=Count('id', filter=Q(description__icontains='-availability'))
        ).values('Error', 'Latency', 'Capacity', 'Availability'))
        if sli_count:
            sli_count = [{'category': k, 'value': v} for k, v in list(sli_count)[0].items()]

        service_count_q = list(qs.extra(select={'name': 'service_name'}).values('name').annotate(value=Count('pk', distinct=True)))
        service_count = []
        for i in service_count_q:
            if i['name'] == 'CNQR-SM-CTE':
                service_count.append({'name': 'Infra', 'value': i['value']})
            elif i['name'] == 'CNQR-SM-CTE [New Relic]':
                service_count.append({'name': 'NewRelic', 'value': i['value']})
            elif i['name'] == 'CNQR-SM-CTE [Watcher]':
                service_count.append({'name': 'Watcher', 'value': i['value']})

        region_count = pd_region_data(start_date, end_date, locale, qs)

        values = qs.values(*[field.name for field in PagerDuty._meta.fields], *[f'incidents__{field.name}' for field in PagerDuty.incidents.related.related_model._meta.fields])
        return JsonResponse({'results': list(values), 'count': qs.count(), 'top_alerts': top_alerts,
            'datacenters_count': datacenters_count, 'sli_count': sli_count, 'service_count': service_count,
            'start_date': start_date, 'end_date': end_date, 'region_count': region_count,
        })
    return JsonResponse(None, safe=False)


def pd_region_data(start_date, end_date, locale, qs):
    region_count = []
    diff = (end_date - start_date)
    apac = 23 if bool(end_date.dst()) else 0
    apac = (apac, apac + 7 - 24 if bool(end_date.dst()) else apac + 7)
    emea = (apac[1] + 1, apac[1] + 1 + 7)
    amers = (emea[1] + 1, emea[1] + 1 + 7)
    apac_query = Q(created_on__hour__gte=apac[0]) | Q(created_on__hour__lte=apac[1]) if bool(
        end_date.dst()) else Q(created_on__hour__gte=apac[0]) & Q(created_on__hour__lte=apac[1])
    emea_query = Q(created_on__hour__gte=emea[0]) & Q(created_on__hour__lte=emea[1])
    amers_query = Q(created_on__hour__gte=amers[0]) & Q(created_on__hour__lte=amers[1])

    if diff.days <= 5:
        locale = pytz.timezone(locale)
        region_data = list(
            qs.order_by('created_on').annotate(minute=Extract('created_on', 'minute'), hour=Extract('created_on', 'hour')).values('minute', 'hour').annotate(
                apac=Count('id', filter=apac_query),
                emea=Count('id', filter=emea_query),
                amers=Count('id', filter=amers_query),
                total=Count('id'),
            ).values('minute', 'hour', 'apac', 'emea', 'amers', 'total'))
        for i in region_data:
            region_count.append({
                'date': parser.parse(f'{i["hour"]}:{i["minute"]}').astimezone(locale).strftime('%I:%M %p'),
                'APAC': i['apac'],
                'EMEA': i['emea'],
                'AMERS': i['amers'],
                'TOTAL': i['total'],
            })
    elif diff.days > 5 and diff.days <= 90:
        region_data = list(
            qs.annotate(month=Extract('created_on', 'month'), day=Extract('created_on', 'day')).values('month', 'day').annotate(
                apac=Count('id', filter=apac_query),
                emea=Count('id', filter=emea_query),
                amers=Count('id', filter=amers_query),
                total=Count('id'),
            ).values('month', 'day', 'apac', 'emea', 'amers', 'total'))
        for i in region_data:
            region_count.append({
                'date': parser.parse(f'{i["month"]}/{i["day"]}').strftime('%b %d'),
                'APAC': i['apac'],
                'EMEA': i['emea'],
                'AMERS': i['amers'],
                'TOTAL': i['total'],
            })
    else:
        region_data = list(
            qs.annotate(year=Extract('created_on', 'year'), month=Extract('created_on', 'month')).values('month', 'year').annotate(
                apac=Count('id', filter=apac_query),
                emea=Count('id', filter=emea_query),
                amers=Count('id', filter=amers_query),
                total=Count('id'),
            ).values('month', 'year', 'apac', 'emea', 'amers', 'total'))
        for i in region_data:
            region_count.append({
                'date': parser.parse(f'{i["month"]}/{i["year"]}').strftime('%B %Y'),
                'APAC': i['apac'],
                'EMEA': i['emea'],
                'AMERS': i['amers'],
                'TOTAL': i['total'],
            })
    return region_count


@api_view(['GET'])
def get_pagerduty_summary(request):
    if request.method == 'GET':
        qs = PagerDuty.objects.all()
        total = qs.count()
        resolved = qs.filter(resolved_on__isnull=False).count()
        escalated = qs.filter(acknowledge_count=0).filter(escalation_count__gt=1).count()
        pending = qs.filter(resolved_on__isnull=True).count()
        return JsonResponse({'total': total, 'resolved': resolved, 'escalated': escalated, 'pending': pending})
    return JsonResponse(None, safe=False)


@api_view(['GET'])
def watcher_alert(request):
    if request.method == 'GET':

        alert_id = request.GET.get('alert_id', None)
        datacenter = request.GET.get('datacenter', None)
        user = SRER.objects.get(user__username='admin')

        cookies = {
            'rack.session': getattr(user, f'watcher_session_{datacenter.lower()}'),
        }

        headers = {
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
            'Accept-Encoding': 'gzip, deflate, br',
            'Host': 'lp-search-sea.concur.com',
            'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_6) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/14.0.3 Safari/605.1.15',
            'Accept-Language': 'en-us',
            'Connection': 'keep-alive',
            'kbn-version': '5.6.15',
        }

        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(5)
            domain = 'cnqr-cn.com' if datacenter == 'beipr1' else 'concur.com'
            sock.connect((f'lp-search-{datacenter}.{domain}', 443))

            response = requests.get(f'https://lp-search-{datacenter}.{domain}/api/watcher/watch/{alert_id}', headers=headers, cookies=cookies, verify=False)
            if response.reason != 'OK':
                raise Exception(response.reason)
            return JsonResponse(response.json(), safe=False)
        except Exception as error:
            return JsonResponse({'error': str(error)})
    return JsonResponse(None, safe=False)


@api_view(['GET'])
def pd_alert_details(request, alert_id):
    if request.method == 'GET':
        params = (
            ('include[]',
             ['first_trigger_log_entries', 'responders', 'metadata', 'parent_incident', 'alerts', 'impacted_services',
              'basic_alert_grouping', 'slack_channel', 'reminders', 'acknowledgers', 'assignees', 'subscribers',
              'webhooks', 'external_references', 'privileges', 'services', 'reopening_details', 'automation_actions']),
        )
        headers = {
            'content-type': 'application/json',
            'authorization': f'Token token={request.user.srer.pagerduty_token}',
        }
        try:
            incident_response = requests.get(f'https://sap.pagerduty.com/api/v1/incidents/{alert_id}', headers=headers, params=params)
            if incident_response.reason != 'OK':
                raise Exception(incident_response.reason)
            alert_response = requests.get(f'https://sap.pagerduty.com/api/v1/incidents/{alert_id}/alerts', headers=headers, params=params)
            return JsonResponse({'incident': incident_response.json()['incident'], 'alerts': alert_response.json()['alerts']})
        except Exception as error:
            return JsonResponse({'error': str(error)})
    return JsonResponse(None, safe=False)


@api_view(['GET'])
def nr_incident_close(request):
    if request.method == 'GET':
        try:
            account_id = request.GET.get('account_id', None)
            incident_id = request.GET.get('incident_id', None)
            user = SRER.objects.get(user__username='admin')
            nr_api_key = getattr(user, [i for i in dir(user) if i.split('_')[-1] == str(account_id)][0])

            url = f'https://api.newrelic.com/v2/alerts_incidents/{incident_id}/close.json'

            response = requests.put(url, headers={'Api-Key': nr_api_key})
            if response.reason != 'OK':
                raise Exception(response.reason)
            return JsonResponse(response.json())
        except Exception as error:
            print(error)
            return JsonResponse({'error': str(error)})
    return JsonResponse(None, safe=False)


@api_view(['GET'])
def nr_violation_state(request):
    if request.method == 'GET':
        try:
            account_id = request.GET.get('account_id', None)
            incident_id = request.GET.get('incident_id', None)
            user = SRER.objects.get(user__username='admin')
            nr_api_key = getattr(user, [i for i in dir(user) if i.split('_')[-1] == account_id][0])

            url = f'https://frame-alerts.newrelic.com/internal_api/1/accounts/{account_id}/incidents/{incident_id}/violations?only_muted=false&only_open=false&per_page_size=10'
            response = requests.get(url, headers={'Api-Key': nr_api_key})
            if response.reason != 'OK':
                raise Exception(response.reason)

            return JsonResponse(response.json())
        except Exception as error:
            print(error)
            return JsonResponse({'error': str(error)})
    return JsonResponse(None, safe=False)


@api_view(['GET'])
def nr_chart_data(request):
    if request.method == 'GET':
        try:
            account_id = request.GET.get('account_id', None)
            incident_id = request.GET.get('incident_id', None)
            synthetics = request.GET.get('synthetics', None)
            user = SRER.objects.get(user__username='admin')
            nr_api_key = getattr(user, [i for i in dir(user) if i.split('_')[-1] == account_id][0])

            url = f'https://frame-alerts.newrelic.com/internal_api/1/accounts/{account_id}/incidents/{incident_id}/violations?only_muted=false&only_open=false&per_page_size=10'
            response = requests.get(url, headers={'Api-Key': nr_api_key})
            if response.reason != 'OK':
                raise Exception(response.reason)

            critical_threshold = response.json()['violations'][0]['criticalThreshold']
            degrade_start = response.json()['violations'][0]['degradationStartTime']
            degrade_end = response.json()['violations'][0]['recoveryEndTime']
            violation_start = response.json()['violations'][0]['violationStartTimestamp']
            violation_end = response.json()['violations'][0]['violationEndTimestamp']
            violation_id = response.json()['violations'][0]['id']

            current_time = int(datetime.datetime.now().timestamp()) * 1000
            start_time = violation_start - (30 * 60 * 1000)
            diff = (current_time - start_time) / 1000 / 60

            if diff <= 59:
                end_time = current_time
                duration = int(end_time - start_time)
            else:
                end_time = violation_start + (30 * 60 * 1000)
                duration = int(end_time - start_time)

            if not violation_end:
                violation_end = end_time
            if not degrade_start:
                degrade_start = start_time

            if eval(synthetics):
                url = f'https://frame-alerts.newrelic.com/internal_api/1/accounts/{account_id}/charts/violations?violation_id={violation_id}&timestamp={violation_start}'
                retries = 0
                while retries <= 5:
                    response = requests.get(url, headers={'Api-Key': nr_api_key})
                    if response.reason == 'OK':
                        break
                    retries += 1
                if response.reason != 'OK':
                    raise Exception(response.reason)
                chart_data = [{'date': i['c'][0]['v'], 'value': i['c'][1]['f']} for i in response.json() if i['c'][1]['f'] != 'No available data']
                return JsonResponse({
                    'chart_data': chart_data,
                    'threshold': critical_threshold,
                    'degrade_start': degrade_start,
                    'violation_start': violation_start,
                    'violation_end': violation_end,
                    'degrade_end': degrade_end
                })
            data = {
                "account_id": account_id,
                "duration": duration,
                "end_time": end_time,
                "proxied_data": {
                    "account_violation_id": response.json()['violations'][0]['accountViolationId'],
                    "label": response.json()['violations'][0]['label'],
                    "violation_regions": [{
                        "name": "CRITICAL",
                        "color": "#DA726C",
                        "begin_time": violation_start,
                        "end_time": violation_end
                    }, {
                        "name": "DEGRADATION",
                        "color": "#F9C3C9",
                        "begin_time": degrade_start,
                        "end_time": violation_start
                    }],
                    "thresholds": [{
                        "color": "#D1D1D1",
                        "unit": "UNSPECIFIED",
                        "value": critical_threshold
                    }]
                }
            }
            retries = 0
            while retries <= 5:
                response = requests.post('https://chartdata.service.newrelic.com/v2/ext/alerts/violations', headers={'Api-Key': nr_api_key}, data=json.dumps(data))
                if response.reason == 'OK':
                    break
                retries += 1
            if response.reason != 'OK':
                raise Exception(response.reason)
            return JsonResponse(response.json())
        except Exception as error:
            print(error)
            return JsonResponse({'error': str(error)})
    return JsonResponse(None, safe=False)


@api_view(['GET'])
def get_jira_changes(request):
    default = '''(status = "In Progress" AND project = "Operations Service Management" AND "Data Center" in ("Lynnwood - Com", "Paris - Com", China, "US Gov West") AND "Affected Service(s)." in (Travel, Expense, Invoice, Mobile) AND updated >= -24h) OR (issueFunction IN parentsof("cf[19405] = 'External Communication'") AND status = 'In Progress' AND Key NOT IN (OPI-5265819, OPI-5423471) AND (component not in (Government-Service-Delivery) OR component is EMPTY) AND "Data Center" not in ("Lynnwood - CGE Prev", "Lynnwood - CGE Stable", "Lynnwood - Impl", "Paris - Impl") AND "Request Type" in ("Change Requiring downtime (impacting outage)", "OS Upgrade (version)/Upgrade of DBMS")) ORDER BY updated'''
    if request.method == 'GET':
        try:
            query = request.GET.get('query', default)
            user = SRER.objects.get(user__username='admin')
            jira = JIRA('https://jira.concur.com', token_auth=user.jira_token)
            jira.session()
            issues = jira.search_issues(jql_str=query)
            return JsonResponse({'issues': [issue.raw for issue in issues], 'query': query})
        except Exception as error:
            return JsonResponse({'error': str(error.text)})
    return JsonResponse(None, safe=False)


@api_view(['POST'])
def create_jira_ticket(request):
    if request.method == 'POST':
        try:
            jira_summary = request.POST.get('jira-summary', None)
            jira_description = request.POST.get('jira-description', None)
            jira_actual_start = request.POST.get('jira-actual-start', None)
            jira_affected_service = request.POST.get('jira-affected-service', None)
            jira_datacenter = request.POST.get('jira-datacenter', None)
            jira_alarm_source = request.POST.get('jira-alarm-source', None)
            jira_notification_method = request.POST.get('jira-notification-method', None)
            jira_incident_category = request.POST.get('jira-incident-category', None)
            jira_component = request.POST.get('jira-component', None)
            jira_after_the_fact = request.POST.get('jira-after-the-fact', None)
            locale = request.POST.get('locale', 'utc')
            jira_actual_start = pytz.timezone(locale).localize(parser.parse(jira_actual_start)).astimezone(pytz.utc).strftime('%Y-%m-%dT%H:%M:%S.000+0000')

            data = {
                "project": {"key": "OPI"},
                "issuetype": {"name": "Incident"},
                "summary": jira_summary,
                "description": jira_description,
                "components": [{'name': i} for i in jira_component.split(',') if jira_component],
                "customfield_10842": jira_actual_start,
                "customfield_11301": [{'value': i} for i in jira_affected_service.split(',') if jira_affected_service],
                "customfield_10836": [{'value': i} for i in jira_datacenter.split(',') if jira_datacenter],
                "customfield_12904": {'value': jira_alarm_source},
                "customfield_10811": {'value': jira_notification_method},
                "customfield_13704": {'value': jira_incident_category},
                'customfield_12534': {'value': jira_after_the_fact},
            }

            user = SRER.objects.get(user__username='admin')
            jira = JIRA('https://jira.concur.com', token_auth=user.jira_token)
            issue = jira.create_issue(**data)
            return JsonResponse({'success': issue.key})
        except Exception as error:
            print(error)
            return JsonResponse({'error': str(error)})
    return JsonResponse(None, safe=False)


@api_view(['GET'])
def get_cert_admins(request, cert):
    if request.method == 'GET':
        user = SRER.objects.get(user__username='admin')
        try:
            session = requests.Session()
            session.headers = {'Authorization': f'token {user.github_token}'}
            url = 'https://github.concur.com/api/v3/search/code?q=org:namespaces+in:file+language:yaml+' + cert
            try:
                users = [i['Email'] for i in yaml.load(session.get(session.get(session.get(url).json()['items'][0]['url']).json()['download_url']).content)['Admins']]
                return JsonResponse({'admins': users})
            except Exception as e:
                raise Exception(e)
        except Exception as error:
            return JsonResponse({'error': str(error)})
    return JsonResponse(None, safe=False)


@api_view(['GET'])
def pd_escalation_policy(request):
    if request.method == 'GET':
        headers = {
            'content-type': 'application/json',
            'authorization': f'Token token={request.user.srer.pagerduty_token}',
        }
        try:
            team_id = 'PVKSDSW'
            response = requests.get(f'https://sap.pagerduty.com/api/v1/escalation_policies?include[]=current_oncall&team_ids[]={team_id}', headers=headers)
            if response.reason != 'OK':
                raise Exception(response.reason)
            return JsonResponse(response.json())
        except Exception as error:
            return JsonResponse({'error': str(error)})
    return JsonResponse(None, safe=False)


@api_view(['POST'])
def update_pagerduty_alert_status(request):
    if request.method == 'POST':
        try:
            incidents = request.POST.get('incidents', None)
            status = request.POST.get('status', None)
            requester_id = request.user.srer.pagerduty_id
            incidents = [{'id': i, 'type': 'incident_reference', 'status': status} for i in incidents.split(',')]
            headers = {
                'content-type': 'application/json',
                'authorization': f'Token token={request.user.srer.pagerduty_token}',
            }
            data = {
                "requester_id": requester_id,
                "incidents": incidents
            }
            response = requests.put('https://sap.pagerduty.com/api/v1/incidents', headers=headers, data=json.dumps(data))
            if response.reason != 'OK':
                raise Exception(response.reason)
            return JsonResponse(response.json())
        except Exception as error:
            print(error)
            return JsonResponse({'error': str(error)})
    return JsonResponse(None, safe=False)


@api_view(['GET'])
def parse_pagerduty(request):
    if request.method == 'GET':
        try:
            description = request.GET.get('description', None)
            service_name = request.GET.get('service_name', None)
            kwargs = pagerduty_analysis.parse_description({}, description, service_name)
            return JsonResponse(kwargs)
        except Exception as error:
            print(error)
            return JsonResponse({'error': str(error)})
    return JsonResponse(None, safe=False)


@api_view(['GET'])
def dashboard_newrelic_chart(request):
    user = SRER.objects.get(user__username='admin')

    @multitasking.task
    def query_data(name, account_id, nrql, presentation):
        headers['Api-Key'] = getattr(user, [i for i in dir(user) if i.split('_')[-1] == str(account_id)][0])
        response = requests.post('https://chartdata.service.newrelic.com/v3/nrql', headers=headers,
                                 data=json.dumps({'nrql': nrql, 'account_id': account_id}))
        results[name] = {'series': response.json()[0]['series'], 'presentation': presentation}

    if request.method == 'GET':
        headers = {
            'Content-Type': 'application/json'
        }
        try:
            datacenter = request.GET.get('datacenter', None)
            results = {}
            qs = NrDashboards.objects.filter(datacenter__acronym__iexact=datacenter)
            for item in qs:
                query_data(item.name, item.account.account_id, item.query, item.presentation)
            start = time.time()
            while len(results.keys()) != qs.count() and (time.time() - start) < 60:
                time.sleep(0.1)

            return JsonResponse(results, safe=False)
        except Exception as error:
            print(error)
            return JsonResponse({'error': str(error)})
    return JsonResponse(None, safe=False)


@api_view(['GET'])
def dashboard_kibana_chart(request):
    @multitasking.task
    def query_data(datacenter, name):
        url = f'https://lp-search-{datacenter}.concur.com/api/metrics/vis/data'
        data = params[datacenter][name]
        response = requests.post(url, headers=headers, cookies=cookies, data=json.dumps(data), verify=False)
        results[name] = response.json()

    if request.method == 'GET':
        datacenter = request.GET.get('datacenter', None)
        user = SRER.objects.get(user__username='admin')

        cookies = {
            'rack.session': getattr(user, f'watcher_session_{datacenter.lower()}'),
        }
        headers = {
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
            'Accept-Encoding': 'gzip, deflate, br',
            'Host': 'lp-search-sea.concur.com',
            'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_6) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/14.0.3 Safari/605.1.15',
            'Accept-Language': 'en-us',
            'Connection': 'keep-alive',
            'kbn-version': '5.6.15',
        }

        timerange_max = datetime.datetime.utcnow()
        timerange_min = timerange_max - datetime.timedelta(minutes=180)
        params = {
            "sea": {
                "SEA CTE session create": {
                    "filters": [{"bool": {"must": [{"match_all": {}}], "must_not": []}}],
                    "timerange": {
                        "max": timerange_max.strftime("%Y-%m-%dT%H:%M:%S"),
                        "min": timerange_min.strftime("%Y-%m-%dT%H:%M:%S"),
                    },
                    "panels": [
                        {
                            "id": "453eb330-caf7-11e8-8b2d-b7975c75e571",
                            "type": "timeseries",
                            "series": [
                                {
                                    "id": "33b784e0-cafa-11e8-8b2d-b7975c75e571",
                                    "color": "rgba(252,220,0,1)",
                                    "split_mode": "filters",
                                    "metrics": [
                                        {
                                            "id": "33b784e1-cafa-11e8-8b2d-b7975c75e571",
                                            "type": "count",
                                        }
                                    ],
                                    "seperate_axis": 0,
                                    "axis_position": "right",
                                    "formatter": "number",
                                    "chart_type": "line",
                                    "line_width": "2",
                                    "point_size": 1,
                                    "fill": "0.1",
                                    "stacked": "none",
                                    "label": "session-create",
                                    "split_filters": [
                                        {
                                            "filter": 'description: "create success" OR description: "create success with fallback"',
                                            "label": "success",
                                            "color": "rgba(252,220,0,1)",
                                            "id": "b5ea1950-6dce-11ea-9cba-81ccc1bb0cce",
                                        },
                                        {
                                            "filter": 'description: "create success with fallback"',
                                            "label": "fallback",
                                            "color": "rgba(0,156,224,1)",
                                            "id": "d54119a0-6dd0-11ea-9cba-81ccc1bb0cce",
                                        },
                                        {
                                            "filter": 'description: "create error"',
                                            "label": "failure",
                                            "color": "rgba(244,78,59,1)",
                                            "id": "0f829530-6dd1-11ea-9cba-81ccc1bb0cce",
                                        },
                                    ],
                                    "override_index_pattern": 1,
                                    "series_index_pattern": "main:log-*",
                                    "series_time_field": "@timestamp",
                                },
                                {
                                    "id": "e836f5a0-cafe-11e8-8b2d-b7975c75e571",
                                    "color": "rgba(174,161,255,1)",
                                    "split_mode": "filters",
                                    "metrics": [
                                        {
                                            "id": "e836f5a1-cafe-11e8-8b2d-b7975c75e571",
                                            "type": "count",
                                        }
                                    ],
                                    "seperate_axis": 0,
                                    "axis_position": "right",
                                    "formatter": "number",
                                    "chart_type": "line",
                                    "line_width": "1",
                                    "point_size": 1,
                                    "fill": "0",
                                    "stacked": "none",
                                    "label": "session-create (Last week)",
                                    "split_filters": [
                                        {
                                            "filter": 'description: "create success" OR description: "create success with fallback"',
                                            "label": "success (last week)",
                                            "color": "rgba(204,204,204,1)",
                                            "id": "3fdb6de0-cafa-11e8-8b2d-b7975c75e571",
                                        }
                                    ],
                                    "offset_time": "168h",
                                    "override_index_pattern": 1,
                                    "series_index_pattern": "main:log-*",
                                    "series_time_field": "@timestamp",
                                },
                            ],
                            "time_field": "@timestamp",
                            "index_pattern": "main:data-*",
                            "interval": "auto",
                            "axis_position": "left",
                            "axis_formatter": "number",
                            "show_legend": 1,
                            "gauge_color_rules": [
                                {"id": "46dc3690-caf7-11e8-8b2d-b7975c75e571"}
                            ],
                            "gauge_width": 10,
                            "gauge_inner_width": 10,
                            "gauge_style": "half",
                            "bar_color_rules": [{"id": "472bdd30-caf7-11e8-8b2d-b7975c75e571"}],
                            "background_color_rules": [
                                {"id": "47c13f60-caf7-11e8-8b2d-b7975c75e571"}
                            ],
                            "background_color": None,
                            "show_grid": 1,
                            "legend_position": "bottom",
                            "filter": "application: bangbang AND (kubernetes.pod: bangbang-seapr1* OR kubernetes.pod: bangbang-create-seapr1* OR kubernetes.pod: bangbang-prod*)",
                        }
                    ],
                },
                "SEA SM-Report-Submits-v4": {
                    "filters": [{"bool": {"must": [{"match_all": {}}], "must_not": []}}],
                    "timerange": {
                        "max": timerange_max.strftime("%Y-%m-%dT%H:%M:%S"),
                        "min": timerange_min.strftime("%Y-%m-%dT%H:%M:%S"),
                    },
                    "panels": [
                        {
                            "id": "453eb330-caf7-11e8-8b2d-b7975c75e571",
                            "type": "timeseries",
                            "series": [
                                {
                                    "id": "e3612db0-cc8a-11e8-9d4b-ab546f00aab9",
                                    "color": "#68BC00",
                                    "split_mode": "everything",
                                    "metrics": [
                                        {
                                            "id": "e3612db1-cc8a-11e8-9d4b-ab546f00aab9",
                                            "type": "count",
                                        }
                                    ],
                                    "seperate_axis": 0,
                                    "axis_position": "right",
                                    "formatter": "number",
                                    "chart_type": "line",
                                    "line_width": "2",
                                    "point_size": 1,
                                    "fill": 0.5,
                                    "stacked": "none",
                                    "label": "Report Submits",
                                    "split_filters": [
                                        {
                                            "filter": 'application:EMT AND cte.subcategory:"Report Submitted"',
                                            "label": "Report Submits",
                                            "color": "#68BC00",
                                            "id": "f018f240-cc8a-11e8-9d4b-ab546f00aab9",
                                        }
                                    ],
                                    "override_index_pattern": 1,
                                    "series_index_pattern": "main:metric-*",
                                },
                                {
                                    "id": "e836f5a0-cafe-11e8-8b2d-b7975c75e571",
                                    "color": "rgba(174,161,255,1)",
                                    "split_mode": "everything",
                                    "metrics": [
                                        {
                                            "id": "e836f5a1-cafe-11e8-8b2d-b7975c75e571",
                                            "type": "count",
                                        }
                                    ],
                                    "seperate_axis": 0,
                                    "axis_position": "right",
                                    "formatter": "number",
                                    "chart_type": "line",
                                    "line_width": "1",
                                    "point_size": 1,
                                    "fill": "0",
                                    "stacked": "none",
                                    "label": "Report Submits (Last week)",
                                    "split_filters": [
                                        {
                                            "filter": 'application:EMT AND cte.subcategory:"Report Submitted"',
                                            "label": "Report Submits (Last week)",
                                            "color": "rgba(250,40,255,1)",
                                            "id": "2f275190-cafe-11e8-8b2d-b7975c75e571",
                                        }
                                    ],
                                    "offset_time": "168h",
                                    "override_index_pattern": 1,
                                    "series_index_pattern": "main:metric-*",
                                },
                            ],
                            "time_field": "@timestamp",
                            "index_pattern": "main:metric-*",
                            "interval": "auto",
                            "axis_position": "left",
                            "axis_formatter": "number",
                            "show_legend": 1,
                            "gauge_color_rules": [
                                {"id": "46dc3690-caf7-11e8-8b2d-b7975c75e571"}
                            ],
                            "gauge_width": 10,
                            "gauge_inner_width": 10,
                            "gauge_style": "half",
                            "bar_color_rules": [{"id": "472bdd30-caf7-11e8-8b2d-b7975c75e571"}],
                            "background_color_rules": [
                                {"id": "47c13f60-caf7-11e8-8b2d-b7975c75e571"}
                            ],
                            "background_color": None,
                            "show_grid": 1,
                            "legend_position": "bottom",
                            "filter": 'application:EMT AND cte.subcategory:"Report Submitted"',
                        }
                    ],
                },
                "SEA SM-Travel-Booked-Trips-v3": {
                    "filters": [{"bool": {"must": [{"match_all": {}}], "must_not": []}}],
                    "timerange": {
                        "max": timerange_max.strftime("%Y-%m-%dT%H:%M:%S"),
                        "min": timerange_min.strftime("%Y-%m-%dT%H:%M:%S"),
                    },
                    "panels": [
                        {
                            "id": "453eb330-caf7-11e8-8b2d-b7975c75e571",
                            "type": "timeseries",
                            "series": [
                                {
                                    "id": "33b784e0-cafa-11e8-8b2d-b7975c75e571",
                                    "color": "rgba(251,158,0,1)",
                                    "split_mode": "filters",
                                    "metrics": [
                                        {
                                            "id": "33b784e1-cafa-11e8-8b2d-b7975c75e571",
                                            "type": "count",
                                        }
                                    ],
                                    "seperate_axis": 0,
                                    "axis_position": "right",
                                    "formatter": "number",
                                    "chart_type": "line",
                                    "line_width": "1",
                                    "point_size": "1",
                                    "fill": "0.3",
                                    "stacked": "none",
                                    "label": "Trips Booked (Current)",
                                    "split_filters": [
                                        {
                                            "filter": "*",
                                            "label": "Trips Booked (Current)",
                                            "color": "rgba(254,146,0,1)",
                                            "id": "3fdb6de0-cafa-11e8-8b2d-b7975c75e571",
                                        }
                                    ],
                                    "override_index_pattern": 0,
                                    "series_index_pattern": "main:metric-*",
                                    "series_drop_last_bucket": 1,
                                    "filter": "*",
                                },
                                {
                                    "id": "453eda40-caf7-11e8-8b2d-b7975c75e571",
                                    "color": "rgba(0,156,224,1)",
                                    "split_mode": "filters",
                                    "metrics": [
                                        {
                                            "id": "453eda41-caf7-11e8-8b2d-b7975c75e571",
                                            "type": "count",
                                        }
                                    ],
                                    "seperate_axis": 0,
                                    "axis_position": "right",
                                    "formatter": "number",
                                    "chart_type": "line",
                                    "line_width": "1",
                                    "point_size": "1",
                                    "fill": "0",
                                    "stacked": "none",
                                    "split_filters": [
                                        {
                                            "filter": "*",
                                            "label": "Trips Booked (1 week ago)",
                                            "color": "rgba(0,156,224,1)",
                                            "id": "104f9030-caf8-11e8-8b2d-b7975c75e571",
                                        }
                                    ],
                                    "label": "Trips Booked (1 week ago)",
                                    "split_color_mode": "rainbow",
                                    "override_index_pattern": 0,
                                    "series_index_pattern": "main:metric-*",
                                    "offset_time": "168h",
                                },
                            ],
                            "time_field": "@timestamp",
                            "index_pattern": "main:metric-*",
                            "interval": "auto",
                            "axis_position": "left",
                            "axis_formatter": "number",
                            "show_legend": 1,
                            "gauge_color_rules": [
                                {"id": "46dc3690-caf7-11e8-8b2d-b7975c75e571"}
                            ],
                            "gauge_width": 10,
                            "gauge_inner_width": 10,
                            "gauge_style": "half",
                            "bar_color_rules": [{"id": "472bdd30-caf7-11e8-8b2d-b7975c75e571"}],
                            "background_color_rules": [
                                {"id": "47c13f60-caf7-11e8-8b2d-b7975c75e571"}
                            ],
                            "background_color": None,
                            "show_grid": 1,
                            "legend_position": "bottom",
                            "drop_last_bucket": 0,
                            "filter": "application:Metric AND cte.category.analyzed:Cliqbook AND cte.subcategory.analyzed:Booked",
                        }
                    ],
                },
                "SEA SM-Travel-Unhandled-and-DB-Errors-v3": {
                    "filters": [{"bool": {"must": [{"match_all": {}}], "must_not": []}}],
                    "timerange": {
                        "max": timerange_max.strftime("%Y-%m-%dT%H:%M:%S"),
                        "min": timerange_min.strftime("%Y-%m-%dT%H:%M:%S"),
                    },
                    "panels": [
                        {
                            "id": "01d6e5b0-cb90-11e8-99d2-03e850154f06",
                            "type": "timeseries",
                            "series": [
                                {
                                    "id": "f2db2f20-cb90-11e8-99d2-03e850154f06",
                                    "color": "rgba(254,146,0,1)",
                                    "split_mode": "filters",
                                    "metrics": [
                                        {
                                            "id": "f2db2f21-cb90-11e8-99d2-03e850154f06",
                                            "type": "count",
                                        }
                                    ],
                                    "seperate_axis": 0,
                                    "axis_position": "right",
                                    "formatter": "number",
                                    "chart_type": "bar",
                                    "line_width": "1",
                                    "point_size": "2",
                                    "fill": "0.1",
                                    "stacked": "none",
                                    "split_filters": [
                                        {
                                            "filter": 'application:Outtask AND (cte.category:Database OR cte.subcategory:"Timeout/Deadlock")',
                                            "label": "DB ERRORS",
                                            "color": "rgba(254,146,0,1)",
                                            "id": "219c4a20-cb90-11e8-99d2-03e850154f06",
                                        }
                                    ],
                                    "label": "DB Errors",
                                    "override_index_pattern": 1,
                                    "series_index_pattern": "main:log-*",
                                },
                                {
                                    "id": "82e75d10-cb90-11e8-99d2-03e850154f06",
                                    "color": "rgba(244,78,59,1)",
                                    "split_mode": "filters",
                                    "metrics": [
                                        {
                                            "id": "82e75d11-cb90-11e8-99d2-03e850154f06",
                                            "type": "count",
                                        },
                                        {
                                            "script": "params.critical > 150 ? params.critical * 1 :null",
                                            "id": "92573cc0-cb90-11e8-99d2-03e850154f06",
                                            "type": "calculation",
                                            "variables": [
                                                {
                                                    "id": "9531acf0-cb90-11e8-99d2-03e850154f06",
                                                    "name": "critical",
                                                    "field": "82e75d11-cb90-11e8-99d2-03e850154f06",
                                                }
                                            ],
                                        },
                                    ],
                                    "seperate_axis": 0,
                                    "axis_position": "right",
                                    "formatter": "number",
                                    "chart_type": "line",
                                    "line_width": "2",
                                    "point_size": "2",
                                    "fill": "0.5",
                                    "stacked": "none",
                                    "split_filters": [
                                        {
                                            "filter": '(((application:Outtask OR cte.category:Travelmidtier) AND (saw_error_page:true OR cte.saw_error_page:true)) OR cte.category:("tws - sabrews" OR "TWS - SabreWS")) AND level:(Error OR ERROR)',
                                            "label": "CRITICAL",
                                            "color": "rgba(244,78,59,1)",
                                            "id": "219c4a20-cb90-11e8-99d2-03e850154f06",
                                        }
                                    ],
                                    "label": "Unhandled Errors Critical",
                                    "override_index_pattern": 1,
                                    "series_index_pattern": "main:log-*",
                                    "hide_in_legend": 1,
                                },
                                {
                                    "id": "01d6e5b1-cb90-11e8-99d2-03e850154f06",
                                    "color": "rgba(179,179,179,1)",
                                    "split_mode": "filters",
                                    "metrics": [
                                        {
                                            "id": "01d6e5b2-cb90-11e8-99d2-03e850154f06",
                                            "type": "count",
                                        }
                                    ],
                                    "seperate_axis": 0,
                                    "axis_position": "right",
                                    "formatter": "number",
                                    "chart_type": "line",
                                    "line_width": "2",
                                    "point_size": "2",
                                    "fill": "0",
                                    "stacked": "none",
                                    "split_filters": [
                                        {
                                            "filter": '(((application:Outtask OR cte.category:Travelmidtier) AND (saw_error_page:true OR cte.saw_error_page:true)) OR cte.category:("tws - sabrews" OR "TWS - SabreWS")) AND level:(Error OR ERROR)',
                                            "label": "ERRORS",
                                            "color": "rgba(179,179,179,1)",
                                            "id": "219c4a20-cb90-11e8-99d2-03e850154f06",
                                        }
                                    ],
                                    "label": "Unhandled Errors",
                                    "override_index_pattern": 1,
                                    "series_index_pattern": "main:log-*",
                                },
                            ],
                            "time_field": "@timestamp",
                            "index_pattern": "main:*",
                            "interval": "auto",
                            "axis_position": "left",
                            "axis_formatter": "number",
                            "show_legend": 1,
                            "legend_position": "bottom",
                            "show_grid": 1,
                            "background_color_rules": [
                                {"id": "25e51720-cce1-11ea-a6b9-ad3ede7a210d"}
                            ],
                            "filter": "NOT roletype:(eui OR euiasp OR euidef OR iuiasp)",
                        }
                    ],
                },
                "SEA SM-Unhandled-and-Outtask-Errors-v3": {
                    "filters": [{"bool": {"must": [{"match_all": {}}], "must_not": []}}],
                    "timerange": {
                        "max": timerange_max.strftime("%Y-%m-%dT%H:%M:%S"),
                        "min": timerange_min.strftime("%Y-%m-%dT%H:%M:%S"),
                    },
                    "panels": [
                        {
                            "id": "01d6e5b0-cb90-11e8-99d2-03e850154f06",
                            "type": "timeseries",
                            "series": [
                                {
                                    "id": "f2db2f20-cb90-11e8-99d2-03e850154f06",
                                    "color": "rgba(254,146,0,1)",
                                    "split_mode": "filters",
                                    "metrics": [
                                        {
                                            "id": "f2db2f21-cb90-11e8-99d2-03e850154f06",
                                            "type": "count",
                                        }
                                    ],
                                    "seperate_axis": 0,
                                    "axis_position": "right",
                                    "formatter": "number",
                                    "chart_type": "bar",
                                    "line_width": "1",
                                    "point_size": "2",
                                    "fill": "0.3",
                                    "stacked": "none",
                                    "split_filters": [
                                        {
                                            "filter": 'application:Outtask  AND NOT (cte.category:"encryption" AND cte.subcategory:("aesgcmdecrypt-failure" OR "unprotectvalueaesgcmold-failure listid")) AND NOT cte.category:"concur.runtime.crossPlatformDelivery" AND NOT cte.category:"TamperedData" AND NOT (description:"Could not retrieve jwtAccessToken" AND method:"/Mobile/MobileSession/AutoLoginV5") AND NOT cte.subcategory:"listitemapi-createlistitem" AND NOT host:"gwwy-qmm1"',
                                            "label": "OUTTASK",
                                            "color": "rgba(254,146,0,1)",
                                            "id": "219c4a20-cb90-11e8-99d2-03e850154f06",
                                        }
                                    ],
                                    "label": "Outtask Errors",
                                    "override_index_pattern": 1,
                                    "series_index_pattern": "main:log-*",
                                },
                                {
                                    "id": "82e75d10-cb90-11e8-99d2-03e850154f06",
                                    "color": "rgba(244,78,59,1)",
                                    "split_mode": "filters",
                                    "metrics": [
                                        {
                                            "id": "82e75d11-cb90-11e8-99d2-03e850154f06",
                                            "type": "count",
                                        },
                                        {
                                            "script": "params.critical > 1500 ? params.critical * 1 :null",
                                            "id": "92573cc0-cb90-11e8-99d2-03e850154f06",
                                            "type": "calculation",
                                            "variables": [
                                                {
                                                    "id": "9531acf0-cb90-11e8-99d2-03e850154f06",
                                                    "name": "critical",
                                                    "field": "82e75d11-cb90-11e8-99d2-03e850154f06",
                                                }
                                            ],
                                        },
                                    ],
                                    "seperate_axis": 0,
                                    "axis_position": "right",
                                    "formatter": "number",
                                    "chart_type": "line",
                                    "line_width": "2",
                                    "point_size": "2",
                                    "fill": "0.5",
                                    "stacked": "none",
                                    "split_filters": [
                                        {
                                            "filter": 'NOT application:Outtask AND NOT (cte.subcategory:(LoggedOut OR startdeployprocess OR other OR email.error.noemailaddress.loginId OR Invoice OR auditFieldChangesForImports OR log OR run OR debug) OR (handled:true OR cte.handled:true) OR emt_data.root_cause_message:"OnErrorThrowable.OnNextValue: OnError while emitting onNext value: com.couchbase.client.java.document.LegacyDocument.class" OR "Forbidden (403)" OR "Could not find the current AES Key" OR (subcategory:"mobile session configuration" OR cte.subcategory:"mobile session configuration") OR (category:"TWS - SabreWS" OR cte.category:"TWS - SabreWS")) AND NOT ((cte.category:com.concur.midtier.services.profile.ProfileService AND description:"HTTP/1.1 404 Not Found") OR (cte.category:com.concur.midtier.services.employee.DefaultEmployeeService AND cte.subcategory:"getUUIDFromEmpKey") OR cte.subcategory:getUserJsonByCUUID OR (cte.subcategory:(invoke OR TRVL_PTS_FEED) AND description:"Could not connect to the web service @ http://cliqservices.concursolutions.com/TravelMidtier/api/TravelPoints/FinalizeComputedTravelPointsTransaction")) AND NOT cte.category: com.concur.midtier.services.cache.localcache.GuavaLRUCache AND NOT cte.entity_code:(p0000999v7gd OR p0000998sozo OR p0014210mjrv OR p0014208fb3e) AND NOT (cte.category:com.concur.midtier.services.reference.defaultcurrencyservice  AND cte.entity_code:t0077475tzlz) AND NOT (cte.category:encryption AND cte.subcategory:aesgcmdecrypt-failure AND description:"mac check in GCM failed")',
                                            "label": "CRITICAL",
                                            "color": "rgba(244,78,59,1)",
                                            "id": "219c4a20-cb90-11e8-99d2-03e850154f06",
                                        }
                                    ],
                                    "label": "Unhandled Errors Critical",
                                    "override_index_pattern": 1,
                                    "series_index_pattern": "main:log-*",
                                },
                                {
                                    "id": "01d6e5b1-cb90-11e8-99d2-03e850154f06",
                                    "color": "rgba(179,179,179,1)",
                                    "split_mode": "filters",
                                    "metrics": [
                                        {
                                            "id": "01d6e5b2-cb90-11e8-99d2-03e850154f06",
                                            "type": "count",
                                        }
                                    ],
                                    "seperate_axis": 0,
                                    "axis_position": "right",
                                    "formatter": "number",
                                    "chart_type": "line",
                                    "line_width": "2",
                                    "point_size": "2",
                                    "fill": "0",
                                    "stacked": "none",
                                    "split_filters": [
                                        {
                                            "filter": 'NOT application:Outtask AND NOT (cte.subcategory:(LoggedOut OR startdeployprocess OR other OR email.error.noemailaddress.loginId OR Invoice OR auditFieldChangesForImports OR log OR run OR debug) OR (handled:true OR cte.handled:true) OR emt_data.root_cause_message:"OnErrorThrowable.OnNextValue: OnError while emitting onNext value: com.couchbase.client.java.document.LegacyDocument.class" OR "Forbidden (403)" OR "Could not find the current AES Key" OR (subcategory:"mobile session configuration" OR cte.subcategory:"mobile session configuration") OR (category:"TWS - SabreWS" OR cte.category:"TWS - SabreWS")) AND NOT ((cte.category:com.concur.midtier.services.profile.ProfileService AND description:"HTTP/1.1 404 Not Found") OR (cte.category:com.concur.midtier.services.employee.DefaultEmployeeService AND cte.subcategory:"getUUIDFromEmpKey") OR cte.subcategory:getUserJsonByCUUID OR (cte.subcategory:(invoke OR TRVL_PTS_FEED) AND description:"Could not connect to the web service @ http://cliqservices.concursolutions.com/TravelMidtier/api/TravelPoints/FinalizeComputedTravelPointsTransaction")) AND NOT cte.category: com.concur.midtier.services.cache.localcache.GuavaLRUCache AND NOT cte.entity_code:(p0000999v7gd OR p0000998sozo OR p0014210mjrv OR p0014208fb3e) AND NOT (cte.category:com.concur.midtier.services.reference.defaultcurrencyservice  AND cte.entity_code:t0077475tzlz) AND NOT (cte.category:encryption AND cte.subcategory:aesgcmdecrypt-failure AND description:"mac check in GCM failed")',
                                            "label": "ERRORS",
                                            "color": "rgba(179,179,179,1)",
                                            "id": "219c4a20-cb90-11e8-99d2-03e850154f06",
                                        }
                                    ],
                                    "label": "Unhandled Errors",
                                    "override_index_pattern": 1,
                                    "series_index_pattern": "main:log-*",
                                },
                            ],
                            "time_field": "@timestamp",
                            "index_pattern": "main:log-seapr1-*",
                            "interval": "auto",
                            "axis_position": "left",
                            "axis_formatter": "number",
                            "show_legend": 1,
                            "legend_position": "bottom",
                            "show_grid": 1,
                            "filter": "application:(EMT OR ExpenseUI OR CESClassic OR Outtask) AND level:(Error OR ERROR OR FATAL) AND NOT environment:im",
                        }
                    ],
                },
                "SEA SM-Invoice-Metrics-v3": {
                    "filters": [{"bool": {"must": [{"match_all": {}}], "must_not": []}}],
                    "timerange": {
                        "max": timerange_max.strftime("%Y-%m-%dT%H:%M:%S"),
                        "min": timerange_min.strftime("%Y-%m-%dT%H:%M:%S"),
                    },
                    "panels": [
                        {
                            "id": "453eb330-caf7-11e8-8b2d-b7975c75e571",
                            "type": "timeseries",
                            "series": [
                                {
                                    "id": "33b784e0-cafa-11e8-8b2d-b7975c75e571",
                                    "color": "rgba(89,141,250,1)",
                                    "split_mode": "filters",
                                    "metrics": [
                                        {
                                            "id": "33b784e1-cafa-11e8-8b2d-b7975c75e571",
                                            "type": "count",
                                        }
                                    ],
                                    "seperate_axis": 0,
                                    "axis_position": "right",
                                    "formatter": "number",
                                    "chart_type": "line",
                                    "line_width": "2",
                                    "point_size": 1,
                                    "fill": 0.5,
                                    "stacked": "none",
                                    "label": "Invoice Submits",
                                    "split_filters": [
                                        {
                                            "filter": "cte.subcategory:Action_SubmitRequest",
                                            "label": "Invoice Submits",
                                            "color": "rgba(77,133,255,1)",
                                            "id": "3fdb6de0-cafa-11e8-8b2d-b7975c75e571",
                                        }
                                    ],
                                    "override_index_pattern": 1,
                                    "series_index_pattern": "main:metric-*",
                                    "terms_field": "cte.subcategory",
                                    "terms_order_by": "33b784e1-cafa-11e8-8b2d-b7975c75e571",
                                },
                                {
                                    "id": "453eda40-caf7-11e8-8b2d-b7975c75e571",
                                    "color": "rgba(252,220,0,1)",
                                    "split_mode": "filters",
                                    "metrics": [
                                        {
                                            "id": "453eda41-caf7-11e8-8b2d-b7975c75e571",
                                            "type": "count",
                                        }
                                    ],
                                    "seperate_axis": 0,
                                    "axis_position": "right",
                                    "formatter": "number",
                                    "chart_type": "line",
                                    "line_width": "2",
                                    "point_size": 1,
                                    "fill": "0.3",
                                    "stacked": "none",
                                    "split_filters": [
                                        {
                                            "filter": "cte.subcategory: Screen_CVP_Portal.asp",
                                            "label": "Invoice Screen Views",
                                            "color": "rgba(252,220,0,1)",
                                            "id": "104f9030-caf8-11e8-8b2d-b7975c75e571",
                                        }
                                    ],
                                    "label": "Invoice Screen Views",
                                    "split_color_mode": "rainbow",
                                    "override_index_pattern": 1,
                                    "series_index_pattern": "main:metric-*",
                                },
                            ],
                            "time_field": "@timestamp",
                            "index_pattern": "main:metric-*",
                            "interval": "auto",
                            "axis_position": "left",
                            "axis_formatter": "number",
                            "show_legend": 1,
                            "gauge_color_rules": [
                                {"id": "46dc3690-caf7-11e8-8b2d-b7975c75e571"}
                            ],
                            "gauge_width": 10,
                            "gauge_inner_width": 10,
                            "gauge_style": "half",
                            "bar_color_rules": [{"id": "472bdd30-caf7-11e8-8b2d-b7975c75e571"}],
                            "background_color_rules": [
                                {"id": "47c13f60-caf7-11e8-8b2d-b7975c75e571"}
                            ],
                            "background_color": None,
                            "show_grid": 1,
                            "legend_position": "bottom",
                            "filter": "application:Metric AND cte.category:Invoice",
                        }
                    ],
                },
                "SEA SM-Report-Submits-AvgRT-v3": {
                    "filters": [{"bool": {"must": [{"match_all": {}}], "must_not": []}}],
                    "timerange": {
                        "max": timerange_max.strftime("%Y-%m-%dT%H:%M:%S"),
                        "min": timerange_min.strftime("%Y-%m-%dT%H:%M:%S"),
                    },
                    "panels": [
                        {
                            "id": "453eb330-caf7-11e8-8b2d-b7975c75e571",
                            "type": "timeseries",
                            "series": [
                                {
                                    "id": "0e4fd0b0-cb89-11e8-99d2-03e850154f06",
                                    "color": "rgba(244,78,59,1)",
                                    "split_mode": "filters",
                                    "metrics": [
                                        {
                                            "id": "0e4fd0b1-cb89-11e8-99d2-03e850154f06",
                                            "type": "avg",
                                            "field": "duration_ms",
                                        },
                                        {
                                            "script": "params.bad > 1500 ? params.bad * 1 : null",
                                            "id": "16d58450-cb89-11e8-99d2-03e850154f06",
                                            "type": "calculation",
                                            "variables": [
                                                {
                                                    "id": "213e01b0-cb89-11e8-99d2-03e850154f06",
                                                    "name": "bad",
                                                    "field": "0e4fd0b1-cb89-11e8-99d2-03e850154f06",
                                                }
                                            ],
                                        },
                                    ],
                                    "seperate_axis": 0,
                                    "axis_position": "right",
                                    "formatter": "number",
                                    "chart_type": "line",
                                    "line_width": "2",
                                    "point_size": "1",
                                    "fill": "0.7",
                                    "stacked": "none",
                                    "split_filters": [
                                        {
                                            "filter": "*",
                                            "label": "ART (Bad)",
                                            "color": "rgba(244,78,59,1)",
                                            "id": "104f9030-caf8-11e8-8b2d-b7975c75e571",
                                        }
                                    ],
                                    "label": "Report Submits ART (Bad)",
                                    "split_color_mode": "rainbow",
                                    "override_index_pattern": 0,
                                    "series_index_pattern": "main:*",
                                },
                                {
                                    "id": "453eda40-caf7-11e8-8b2d-b7975c75e571",
                                    "color": "rgba(164,221,0,1)",
                                    "split_mode": "filters",
                                    "metrics": [
                                        {
                                            "id": "453eda41-caf7-11e8-8b2d-b7975c75e571",
                                            "type": "avg",
                                            "field": "duration_ms",
                                        }
                                    ],
                                    "seperate_axis": 0,
                                    "axis_position": "right",
                                    "formatter": "number",
                                    "chart_type": "line",
                                    "line_width": "2",
                                    "point_size": "1",
                                    "fill": "0",
                                    "stacked": "none",
                                    "split_filters": [
                                        {
                                            "filter": "*",
                                            "label": "ART (Good)",
                                            "color": "rgba(164,221,0,1)",
                                            "id": "104f9030-caf8-11e8-8b2d-b7975c75e571",
                                        }
                                    ],
                                    "label": "Report Submits ART (Good)",
                                    "split_color_mode": "rainbow",
                                    "override_index_pattern": 0,
                                    "series_index_pattern": "main:*",
                                    "terms_order_by": "453eda41-caf7-11e8-8b2d-b7975c75e571",
                                    "terms_field": "duration_ms",
                                },
                                {
                                    "id": "f856b530-cb7e-11e8-99d2-03e850154f06",
                                    "color": "rgba(101,50,148,1)",
                                    "split_mode": "filters",
                                    "metrics": [
                                        {
                                            "id": "f856b531-cb7e-11e8-99d2-03e850154f06",
                                            "type": "avg",
                                            "field": "duration_ms",
                                        }
                                    ],
                                    "seperate_axis": 0,
                                    "axis_position": "right",
                                    "formatter": "number",
                                    "chart_type": "line",
                                    "line_width": "1",
                                    "point_size": "1",
                                    "fill": "0.2",
                                    "stacked": "none",
                                    "split_filters": [
                                        {
                                            "filter": "*",
                                            "label": "ART (Last week)",
                                            "color": "rgba(101,50,148,1)",
                                            "id": "104f9030-caf8-11e8-8b2d-b7975c75e571",
                                        }
                                    ],
                                    "label": "Report Submits ART (Last week)",
                                    "split_color_mode": "rainbow",
                                    "offset_time": "168h",
                                    "steps": 0,
                                    "override_index_pattern": 0,
                                    "series_index_pattern": "main:*",
                                },
                            ],
                            "time_field": "@timestamp",
                            "index_pattern": "main:metric-*",
                            "interval": "auto",
                            "axis_position": "left",
                            "axis_formatter": "number",
                            "show_legend": 1,
                            "gauge_color_rules": [
                                {"id": "46dc3690-caf7-11e8-8b2d-b7975c75e571"}
                            ],
                            "gauge_width": 10,
                            "gauge_inner_width": 10,
                            "gauge_style": "half",
                            "bar_color_rules": [{"id": "472bdd30-caf7-11e8-8b2d-b7975c75e571"}],
                            "background_color_rules": [
                                {"id": "47c13f60-caf7-11e8-8b2d-b7975c75e571"}
                            ],
                            "background_color": None,
                            "show_grid": 1,
                            "legend_position": "bottom",
                            "drop_last_bucket": 1,
                            "filter": "application:(EMT OR expense-report-service) AND method:SubmitReport",
                        }
                    ],
                },
                "SEA SRER_OAuth_Trend": {
                    "filters": [{"bool": {"must": [{"match_all": {}}], "must_not": []}}],
                    "timerange": {
                        "max": timerange_max.strftime("%Y-%m-%dT%H:%M:%S"),
                        "min": timerange_min.strftime("%Y-%m-%dT%H:%M:%S"),
                    },
                    "panels": [
                        {
                            "id": "2b5c4800-ba66-11ea-8245-4bcf2a56f1eb",
                            "type": "timeseries",
                            "series": [
                                {
                                    "id": "2b5c4801-ba66-11ea-8245-4bcf2a56f1eb",
                                    "color": "#68BC00",
                                    "split_mode": "terms",
                                    "metrics": [
                                        {
                                            "id": "2b5c4802-ba66-11ea-8245-4bcf2a56f1eb",
                                            "type": "count",
                                        }
                                    ],
                                    "seperate_axis": 0,
                                    "axis_position": "right",
                                    "formatter": "number",
                                    "chart_type": "line",
                                    "line_width": 1,
                                    "point_size": 1,
                                    "fill": "0.2",
                                    "stacked": "none",
                                    "terms_field": "name",
                                    "terms_size": "5",
                                    "split_color_mode": "rainbow",
                                    "steps": 0,
                                    "override_index_pattern": 1,
                                }
                            ],
                            "time_field": "@timestamp",
                            "index_pattern": "coresrv:metric-*",
                            "interval": "auto",
                            "axis_position": "left",
                            "axis_formatter": "number",
                            "show_legend": 1,
                            "filter": 'application: oauth2-service AND description: "metrics\\.web\\."',
                            "background_color_rules": [
                                {"id": "d164afa0-ba78-11ea-8245-4bcf2a56f1eb"}
                            ],
                            "drop_last_bucket": 1,
                            "gauge_color_rules": [
                                {"id": "1321c1d0-ba79-11ea-8245-4bcf2a56f1eb"}
                            ],
                            "gauge_width": 10,
                            "gauge_inner_width": 10,
                            "gauge_style": "half",
                            "bar_color_rules": [{"id": "14d11f80-ba79-11ea-8245-4bcf2a56f1eb"}],
                            "show_grid": 1,
                        }
                    ],
                },
                "SEA SM-Invoice-Errors-v3": {
                    "filters": [{"bool": {"must": [{"match_all": {}}], "must_not": []}}],
                    "timerange": {
                        "max": timerange_max.strftime("%Y-%m-%dT%H:%M:%S"),
                        "min": timerange_min.strftime("%Y-%m-%dT%H:%M:%S"),
                    },
                    "panels": [
                        {
                            "id": "01d6e5b0-cb90-11e8-99d2-03e850154f06",
                            "type": "timeseries",
                            "series": [
                                {
                                    "id": "01d6e5b1-cb90-11e8-99d2-03e850154f06",
                                    "color": "rgba(0,156,224,1)",
                                    "split_mode": "filters",
                                    "metrics": [
                                        {
                                            "id": "01d6e5b2-cb90-11e8-99d2-03e850154f06",
                                            "type": "count",
                                        }
                                    ],
                                    "seperate_axis": 0,
                                    "axis_position": "right",
                                    "formatter": "number",
                                    "chart_type": "bar",
                                    "line_width": "1",
                                    "point_size": "1",
                                    "fill": "0",
                                    "stacked": "none",
                                    "split_filters": [
                                        {
                                            "filter": 'cte.category:InvoiceRouter AND NOT cte.subcategory:GetInvoiceImage AND NOT cte.handled:true AND NOT description:"ProtectedValue tampered with" ',
                                            "label": "INVOICE ROUTER UE's",
                                            "color": "rgba(0,156,224,1)",
                                            "id": "219c4a20-cb90-11e8-99d2-03e850154f06",
                                        }
                                    ],
                                    "label": "INVOICE ROUTER UE's",
                                    "override_index_pattern": 1,
                                    "series_index_pattern": "main:log-*",
                                },
                                {
                                    "id": "82e75d10-cb90-11e8-99d2-03e850154f06",
                                    "color": "rgba(244,78,59,1)",
                                    "split_mode": "filters",
                                    "metrics": [
                                        {
                                            "id": "82e75d11-cb90-11e8-99d2-03e850154f06",
                                            "type": "count",
                                        },
                                        {
                                            "script": "params.critical > 0 ? params.critical * 1 :null",
                                            "id": "92573cc0-cb90-11e8-99d2-03e850154f06",
                                            "type": "calculation",
                                            "variables": [
                                                {
                                                    "id": "9531acf0-cb90-11e8-99d2-03e850154f06",
                                                    "name": "critical",
                                                    "field": "82e75d11-cb90-11e8-99d2-03e850154f06",
                                                }
                                            ],
                                        },
                                    ],
                                    "seperate_axis": 0,
                                    "axis_position": "right",
                                    "formatter": "number",
                                    "chart_type": "bar",
                                    "line_width": "2",
                                    "point_size": "2",
                                    "fill": "0.5",
                                    "stacked": "none",
                                    "split_filters": [
                                        {
                                            "filter": "cte.subcategory:GetInvoiceImage AND NOT cte.handled:true",
                                            "label": "INVOICE ERROS UE's",
                                            "color": "rgba(244,78,59,1)",
                                            "id": "219c4a20-cb90-11e8-99d2-03e850154f06",
                                        }
                                    ],
                                    "label": "INVOICE ERROS UE's",
                                    "override_index_pattern": 1,
                                    "series_index_pattern": "main:log-*",
                                },
                            ],
                            "time_field": "@timestamp",
                            "index_pattern": "main:log-*",
                            "interval": "auto",
                            "axis_position": "left",
                            "axis_formatter": "number",
                            "show_legend": 1,
                            "legend_position": "bottom",
                            "show_grid": 1,
                            "filter": "application:ExpenseUI",
                        }
                    ],
                },
            },
            "par": {
                "PAR CTE-session-create": {
                    "filters": [{"bool": {"must": [{"match_all": {}}], "must_not": []}}],
                    "timerange": {
                        "max": timerange_max.strftime("%Y-%m-%dT%H:%M:%S"),
                        "min": timerange_min.strftime("%Y-%m-%dT%H:%M:%S"),
                    },
                    "panels": [
                        {
                            "id": "745fd950-cc87-11e8-96f9-5776523bc03b",
                            "type": "timeseries",
                            "series": [
                                {
                                    "id": "d75bd090-cc87-11e8-96f9-5776523bc03b",
                                    "color": "rgba(252,220,0,1)",
                                    "split_mode": "filters",
                                    "metrics": [
                                        {
                                            "id": "d75bd091-cc87-11e8-96f9-5776523bc03b",
                                            "type": "count",
                                        }
                                    ],
                                    "seperate_axis": 0,
                                    "axis_position": "right",
                                    "formatter": "number",
                                    "chart_type": "line",
                                    "line_width": "2",
                                    "point_size": 1,
                                    "fill": "0.1",
                                    "stacked": "none",
                                    "label": "session-create",
                                    "split_filters": [
                                        {
                                            "filter": 'description: "create success" OR description: "create success with fallback"',
                                            "label": "success",
                                            "color": "rgba(252,220,0,1)",
                                            "id": "ffe6fee0-cc87-11e8-96f9-5776523bc03b",
                                        },
                                        {
                                            "filter": 'description: "create success with fallback"',
                                            "label": "fallback",
                                            "color": "rgba(0,156,224,1)",
                                            "id": "b516d5d0-e11b-11e9-8eba-fbc97288c37f",
                                        },
                                        {
                                            "filter": 'description: "create error"',
                                            "label": "failure",
                                            "color": "rgba(244,78,59,1)",
                                            "id": "ac434c00-6dd3-11ea-9d1d-430792e1344a",
                                        },
                                    ],
                                    "override_index_pattern": 0,
                                    "series_index_pattern": "log-*",
                                    "series_time_field": "@timestamp",
                                },
                                {
                                    "id": "745fd951-cc87-11e8-96f9-5776523bc03b",
                                    "color": "rgba(174,161,255,1)",
                                    "split_mode": "filters",
                                    "metrics": [
                                        {
                                            "id": "745fd952-cc87-11e8-96f9-5776523bc03b",
                                            "type": "count",
                                        }
                                    ],
                                    "seperate_axis": 0,
                                    "axis_position": "right",
                                    "formatter": "number",
                                    "chart_type": "line",
                                    "line_width": 1,
                                    "point_size": 1,
                                    "fill": "0",
                                    "stacked": "none",
                                    "label": "session-create (Last week)",
                                    "split_filters": [
                                        {
                                            "filter": 'description: "create success" OR description: "create success with fallback"',
                                            "label": "success (Last week)",
                                            "color": "rgba(204,204,204,1)",
                                            "id": "940c85a0-cc87-11e8-96f9-5776523bc03b",
                                        }
                                    ],
                                    "offset_time": "168h",
                                    "override_index_pattern": 0,
                                    "series_index_pattern": "log-*",
                                    "series_time_field": "@timestamp",
                                },
                            ],
                            "time_field": "@timestamp",
                            "index_pattern": "data-*",
                            "interval": "auto",
                            "axis_position": "left",
                            "axis_formatter": "number",
                            "show_legend": 1,
                            "legend_position": "bottom",
                            "show_grid": 1,
                            "background_color_rules": [
                                {"id": "130ec620-e11c-11e9-8eba-fbc97288c37f"}
                            ],
                            "bar_color_rules": [{"id": "31cce1d0-e11e-11e9-8f8b-d73846931136"}],
                            "gauge_color_rules": [
                                {"id": "328e3600-e11e-11e9-8f8b-d73846931136"}
                            ],
                            "gauge_width": 10,
                            "gauge_inner_width": 10,
                            "gauge_style": "half",
                            "filter": "application: bangbang AND (kubernetes.pod: bangbang-parpr1* OR kubernetes.pod: bangbang-create-parpr1* OR kubernetes.pod: bangbang-prod*)",
                        }
                    ],
                },
                "PAR SM-Report-Submits-v4": {
                    "filters": [{"bool": {"must": [{"match_all": {}}], "must_not": []}}],
                    "timerange": {
                        "max": timerange_max.strftime("%Y-%m-%dT%H:%M:%S"),
                        "min": timerange_min.strftime("%Y-%m-%dT%H:%M:%S"),
                    },
                    "panels": [
                        {
                            "id": "745fd950-cc87-11e8-96f9-5776523bc03b",
                            "type": "timeseries",
                            "series": [
                                {
                                    "id": "85791150-cc89-11e8-96f9-5776523bc03b",
                                    "color": "rgba(104,188,0,1)",
                                    "split_mode": "filters",
                                    "metrics": [
                                        {
                                            "id": "85791151-cc89-11e8-96f9-5776523bc03b",
                                            "type": "count",
                                        }
                                    ],
                                    "seperate_axis": 0,
                                    "axis_position": "right",
                                    "formatter": "number",
                                    "chart_type": "line",
                                    "line_width": "2",
                                    "point_size": 1,
                                    "fill": "0.5",
                                    "stacked": "none",
                                    "label": "Report Submits",
                                    "split_filters": [
                                        {
                                            "filter": "*",
                                            "label": "Report Submits",
                                            "color": "rgba(104,188,0,1)",
                                            "id": "907c4810-cc89-11e8-96f9-5776523bc03b",
                                        }
                                    ],
                                    "override_index_pattern": 1,
                                    "series_index_pattern": "metric-*",
                                },
                                {
                                    "id": "745fd951-cc87-11e8-96f9-5776523bc03b",
                                    "color": "rgba(174,161,255,1)",
                                    "split_mode": "filters",
                                    "metrics": [
                                        {
                                            "id": "745fd952-cc87-11e8-96f9-5776523bc03b",
                                            "type": "count",
                                        }
                                    ],
                                    "seperate_axis": 0,
                                    "axis_position": "right",
                                    "formatter": "number",
                                    "chart_type": "line",
                                    "line_width": 1,
                                    "point_size": 1,
                                    "fill": "0",
                                    "stacked": "none",
                                    "label": "Report Submits (Last week)",
                                    "split_filters": [
                                        {
                                            "filter": "*",
                                            "label": "Report Submits (Last week)",
                                            "color": "rgba(250,40,255,1)",
                                            "id": "a24d0d10-cc87-11e8-96f9-5776523bc03b",
                                        }
                                    ],
                                    "offset_time": "168h",
                                    "override_index_pattern": 1,
                                    "series_index_pattern": "metric-*",
                                },
                            ],
                            "time_field": "@timestamp",
                            "index_pattern": "metric-parpr1-*",
                            "interval": "auto",
                            "axis_position": "left",
                            "axis_formatter": "number",
                            "show_legend": 1,
                            "legend_position": "bottom",
                            "show_grid": 1,
                            "filter": 'application:EMT AND cte.subcategory:"Report Submitted"',
                        }
                    ],
                },
                "PAR SM-Travel-Trips Booked-v3": {
                    "filters": [{"bool": {"must": [{"match_all": {}}], "must_not": []}}],
                    "timerange": {
                        "max": timerange_max.strftime("%Y-%m-%dT%H:%M:%S"),
                        "min": timerange_min.strftime("%Y-%m-%dT%H:%M:%S"),
                    },
                    "panels": [
                        {
                            "id": "b55427d0-cc88-11e8-96f9-5776523bc03b",
                            "type": "timeseries",
                            "series": [
                                {
                                    "id": "094c47a0-cc89-11e8-96f9-5776523bc03b",
                                    "color": "rgba(251,158,0,1)",
                                    "split_mode": "filters",
                                    "metrics": [
                                        {
                                            "id": "094c47a1-cc89-11e8-96f9-5776523bc03b",
                                            "type": "count",
                                        }
                                    ],
                                    "seperate_axis": 0,
                                    "axis_position": "right",
                                    "formatter": "number",
                                    "chart_type": "line",
                                    "line_width": "1",
                                    "point_size": "1",
                                    "fill": "0.3",
                                    "stacked": "none",
                                    "label": "Trips Booked (Current)",
                                    "split_filters": [
                                        {
                                            "filter": "*",
                                            "label": "Trips Booked (Current)",
                                            "color": "rgba(251,158,0,1)",
                                            "id": "16315dc0-cc89-11e8-96f9-5776523bc03b",
                                        }
                                    ],
                                    "override_index_pattern": 0,
                                    "series_index_pattern": "metric-*",
                                },
                                {
                                    "id": "b55427d1-cc88-11e8-96f9-5776523bc03b",
                                    "color": "rgba(0,156,224,1)",
                                    "split_mode": "filters",
                                    "metrics": [
                                        {
                                            "id": "b5544ee0-cc88-11e8-96f9-5776523bc03b",
                                            "type": "count",
                                        }
                                    ],
                                    "seperate_axis": 0,
                                    "axis_position": "right",
                                    "formatter": "number",
                                    "chart_type": "line",
                                    "line_width": "1",
                                    "point_size": "1",
                                    "fill": "0",
                                    "stacked": "none",
                                    "split_filters": [
                                        {
                                            "filter": "*",
                                            "label": "Trips Booked (1 week ago)",
                                            "color": "rgba(0,156,224,1)",
                                            "id": "f76f1170-cc88-11e8-96f9-5776523bc03b",
                                        }
                                    ],
                                    "label": "Trips Booked (1 week ago)",
                                    "override_index_pattern": 1,
                                    "series_index_pattern": "metric-*",
                                    "split_color_mode": "gradient",
                                    "offset_time": "168h",
                                },
                            ],
                            "time_field": "@timestamp",
                            "index_pattern": "metric-*",
                            "interval": "auto",
                            "axis_position": "left",
                            "axis_formatter": "number",
                            "show_legend": 1,
                            "show_grid": 1,
                            "legend_position": "bottom",
                            "filter": "application:Metric AND cte.category.analyzed:Cliqbook AND cte.subcategory.analyzed:Booked",
                        }
                    ],
                },
                "PAR SM-Travel-Unhandled-and-DB-Errors-v3": {
                    "filters": [{"bool": {"must": [{"match_all": {}}], "must_not": []}}],
                    "timerange": {
                        "max": timerange_max.strftime("%Y-%m-%dT%H:%M:%S"),
                        "min": timerange_min.strftime("%Y-%m-%dT%H:%M:%S"),
                    },
                    "panels": [
                        {
                            "id": "ab42c3c0-cc8b-11e8-96f9-5776523bc03b",
                            "type": "timeseries",
                            "series": [
                                {
                                    "id": "e4418620-cc8b-11e8-96f9-5776523bc03b",
                                    "color": "rgba(251,158,0,1)",
                                    "split_mode": "filters",
                                    "metrics": [
                                        {
                                            "id": "e4418621-cc8b-11e8-96f9-5776523bc03b",
                                            "type": "count",
                                        }
                                    ],
                                    "seperate_axis": 0,
                                    "axis_position": "right",
                                    "formatter": "number",
                                    "chart_type": "bar",
                                    "line_width": 1,
                                    "point_size": 1,
                                    "fill": "0.1",
                                    "stacked": "none",
                                    "split_filters": [
                                        {
                                            "filter": 'application:Outtask AND (cte.category:Database OR cte.subcategory:"Timeout/Deadlock")',
                                            "label": "DB ERRORS",
                                            "color": "rgba(251,158,0,1)",
                                            "id": "e72ff380-cc8b-11e8-96f9-5776523bc03b",
                                        }
                                    ],
                                    "label": "DB Errors",
                                    "override_index_pattern": 1,
                                    "series_index_pattern": "log-*",
                                },
                                {
                                    "id": "cc2c83f0-cc8b-11e8-96f9-5776523bc03b",
                                    "color": "rgba(244,78,59,1)",
                                    "split_mode": "filters",
                                    "metrics": [
                                        {
                                            "id": "cc2c83f1-cc8b-11e8-96f9-5776523bc03b",
                                            "type": "count",
                                        },
                                        {
                                            "script": "params.critical > 100 ? params.critical * 1 :null",
                                            "id": "8554b910-cc8c-11e8-96f9-5776523bc03b",
                                            "type": "calculation",
                                            "variables": [
                                                {
                                                    "id": "88cd3e00-cc8c-11e8-96f9-5776523bc03b",
                                                    "name": "critical",
                                                    "field": "cc2c83f1-cc8b-11e8-96f9-5776523bc03b",
                                                }
                                            ],
                                        },
                                    ],
                                    "seperate_axis": 0,
                                    "axis_position": "right",
                                    "formatter": "number",
                                    "chart_type": "line",
                                    "line_width": "2",
                                    "point_size": "2",
                                    "fill": "0.8",
                                    "stacked": "none",
                                    "label": "Unhandled Errors Critical",
                                    "split_filters": [
                                        {
                                            "filter": '(((application:Outtask OR cte.category:Travelmidtier) AND (saw_error_page:true OR cte.saw_error_page:true)) OR cte.category:("tws - sabrews" OR "TWS - SabreWS")) AND level:(Error OR ERROR)',
                                            "label": "CRITICAL",
                                            "color": "rgba(244,78,59,1)",
                                            "id": "d4c83090-cc8b-11e8-96f9-5776523bc03b",
                                        }
                                    ],
                                    "override_index_pattern": 1,
                                    "series_index_pattern": "log-*",
                                    "hide_in_legend": 1,
                                },
                                {
                                    "id": "ab42c3c1-cc8b-11e8-96f9-5776523bc03b",
                                    "color": "rgba(179,179,179,1)",
                                    "split_mode": "filters",
                                    "metrics": [
                                        {
                                            "id": "ab42ead0-cc8b-11e8-96f9-5776523bc03b",
                                            "type": "count",
                                        }
                                    ],
                                    "seperate_axis": 0,
                                    "axis_position": "right",
                                    "formatter": "number",
                                    "chart_type": "line",
                                    "line_width": "2",
                                    "point_size": "2",
                                    "fill": "0",
                                    "stacked": "none",
                                    "label": "Unhandled Errors",
                                    "split_filters": [
                                        {
                                            "filter": '(((application:Outtask OR cte.category:Travelmidtier) AND (saw_error_page:true OR cte.saw_error_page:true)) OR cte.category:("tws - sabrews" OR "TWS - SabreWS")) AND level:(Error OR ERROR)',
                                            "label": "ERRORS",
                                            "color": "rgba(179,179,179,1)",
                                            "id": "c4848620-cc8b-11e8-96f9-5776523bc03b",
                                        }
                                    ],
                                    "override_index_pattern": 1,
                                    "series_index_pattern": "log-*",
                                },
                            ],
                            "time_field": "@timestamp",
                            "index_pattern": "log-*",
                            "interval": "auto",
                            "axis_position": "left",
                            "axis_formatter": "number",
                            "show_legend": 1,
                            "legend_position": "bottom",
                            "show_grid": 1,
                            "filter": "NOT roletype:(eui OR euiasp OR euidef OR iuiasp)",
                        }
                    ],
                },
                "PAR SM-Unhandled-and-Outtask-Errors-v3": {
                    "filters": [{"bool": {"must": [{"match_all": {}}], "must_not": []}}],
                    "timerange": {
                        "max": timerange_max.strftime("%Y-%m-%dT%H:%M:%S"),
                        "min": timerange_min.strftime("%Y-%m-%dT%H:%M:%S"),
                    },
                    "panels": [
                        {
                            "id": "ab42c3c0-cc8b-11e8-96f9-5776523bc03b",
                            "type": "timeseries",
                            "series": [
                                {
                                    "id": "e4418620-cc8b-11e8-96f9-5776523bc03b",
                                    "color": "rgba(251,158,0,1)",
                                    "split_mode": "filters",
                                    "metrics": [
                                        {
                                            "id": "e4418621-cc8b-11e8-96f9-5776523bc03b",
                                            "type": "count",
                                        }
                                    ],
                                    "seperate_axis": 0,
                                    "axis_position": "right",
                                    "formatter": "number",
                                    "chart_type": "bar",
                                    "line_width": 1,
                                    "point_size": 1,
                                    "fill": "0.1",
                                    "stacked": "none",
                                    "split_filters": [
                                        {
                                            "filter": 'application:Outtask  AND NOT (cte.category:"encryption" AND cte.subcategory:("aesgcmdecrypt-failure" OR "unprotectvalueaesgcmold-failure listid")) AND NOT cte.category:"concur.runtime.crossPlatformDelivery" AND NOT cte.category:"TamperedData" AND NOT (description:"Could not retrieve jwtAccessToken" AND method:"/Mobile/MobileSession/AutoLoginV5") AND NOT cte.subcategory:"listitemapi-createlistitem"',
                                            "label": "OUTTASK",
                                            "color": "rgba(251,158,0,1)",
                                            "id": "e72ff380-cc8b-11e8-96f9-5776523bc03b",
                                        }
                                    ],
                                    "label": "Outtask Errors",
                                    "override_index_pattern": 1,
                                    "series_index_pattern": "log-*",
                                },
                                {
                                    "id": "cc2c83f0-cc8b-11e8-96f9-5776523bc03b",
                                    "color": "rgba(244,78,59,1)",
                                    "split_mode": "filters",
                                    "metrics": [
                                        {
                                            "id": "cc2c83f1-cc8b-11e8-96f9-5776523bc03b",
                                            "type": "count",
                                        },
                                        {
                                            "script": "params.critical > 500 ? params.critical * 1 :null",
                                            "id": "8554b910-cc8c-11e8-96f9-5776523bc03b",
                                            "type": "calculation",
                                            "variables": [
                                                {
                                                    "id": "88cd3e00-cc8c-11e8-96f9-5776523bc03b",
                                                    "name": "critical",
                                                    "field": "cc2c83f1-cc8b-11e8-96f9-5776523bc03b",
                                                }
                                            ],
                                        },
                                    ],
                                    "seperate_axis": 0,
                                    "axis_position": "right",
                                    "formatter": "number",
                                    "chart_type": "line",
                                    "line_width": "2",
                                    "point_size": "2",
                                    "fill": "0.5",
                                    "stacked": "none",
                                    "label": "Unhandled Errors Critical",
                                    "split_filters": [
                                        {
                                            "filter": 'NOT application:Outtask AND NOT (cte.subcategory:(LoggedOut OR startdeployprocess OR other OR email.error.noemailaddress.loginId OR Invoice OR auditFieldChangesForImports OR log OR run OR debug) OR (handled:true OR cte.handled:true) OR emt_data.root_cause_message:"OnErrorThrowable.OnNextValue: OnError while emitting onNext value: com.couchbase.client.java.document.LegacyDocument.class" OR "Forbidden (403)" OR "Could not find the current AES Key" OR (subcategory:"mobile session configuration" OR cte.subcategory:"mobile session configuration") OR (category:"TWS - SabreWS" OR cte.category:"TWS - SabreWS")) AND NOT ((cte.category:com.concur.midtier.services.profile.ProfileService AND description:"HTTP/1.1 404 Not Found") OR (cte.category:com.concur.midtier.services.employee.DefaultEmployeeService AND cte.subcategory:"getUUIDFromEmpKey") OR cte.subcategory:getUserJsonByCUUID OR (cte.subcategory:(invoke OR TRVL_PTS_FEED) AND description:"Could not connect to the web service @ http://cliqservices.concursolutions.com/TravelMidtier/api/TravelPoints/FinalizeComputedTravelPointsTransaction")) AND NOT cte.category: com.concur.midtier.services.cache.localcache.GuavaLRUCache AND NOT cte.entity_code:(p0000999v7gd OR p0000998sozo OR p0014210mjrv OR p0014208fb3e) AND NOT (cte.category:com.concur.midtier.services.reference.defaultcurrencyservice  AND cte.entity_code:t0077475tzlz) AND NOT (cte.category:encryption AND cte.subcategory:aesgcmdecrypt-failure AND description:"mac check in GCM failed")',
                                            "label": "CRITICAL",
                                            "color": "rgba(244,78,59,1)",
                                            "id": "d4c83090-cc8b-11e8-96f9-5776523bc03b",
                                        }
                                    ],
                                    "override_index_pattern": 1,
                                    "series_index_pattern": "log-*",
                                },
                                {
                                    "id": "ab42c3c1-cc8b-11e8-96f9-5776523bc03b",
                                    "color": "rgba(179,179,179,1)",
                                    "split_mode": "filters",
                                    "metrics": [
                                        {
                                            "id": "ab42ead0-cc8b-11e8-96f9-5776523bc03b",
                                            "type": "count",
                                        }
                                    ],
                                    "seperate_axis": 0,
                                    "axis_position": "right",
                                    "formatter": "number",
                                    "chart_type": "line",
                                    "line_width": "2",
                                    "point_size": "2",
                                    "fill": "0",
                                    "stacked": "none",
                                    "label": "Unhandled Errors",
                                    "split_filters": [
                                        {
                                            "filter": 'NOT application:Outtask AND NOT (cte.subcategory:(LoggedOut OR startdeployprocess OR other OR email.error.noemailaddress.loginId OR Invoice OR auditFieldChangesForImports OR log OR run OR debug) OR (handled:true OR cte.handled:true) OR emt_data.root_cause_message:"OnErrorThrowable.OnNextValue: OnError while emitting onNext value: com.couchbase.client.java.document.LegacyDocument.class" OR "Forbidden (403)" OR "Could not find the current AES Key" OR (subcategory:"mobile session configuration" OR cte.subcategory:"mobile session configuration") OR (category:"TWS - SabreWS" OR cte.category:"TWS - SabreWS")) AND NOT ((cte.category:com.concur.midtier.services.profile.ProfileService AND description:"HTTP/1.1 404 Not Found") OR (cte.category:com.concur.midtier.services.employee.DefaultEmployeeService AND cte.subcategory:"getUUIDFromEmpKey") OR cte.subcategory:getUserJsonByCUUID OR (cte.subcategory:(invoke OR TRVL_PTS_FEED) AND description:"Could not connect to the web service @ http://cliqservices.concursolutions.com/TravelMidtier/api/TravelPoints/FinalizeComputedTravelPointsTransaction")) AND NOT cte.category: com.concur.midtier.services.cache.localcache.GuavaLRUCache AND NOT cte.entity_code:(p0000999v7gd OR p0000998sozo OR p0014210mjrv OR p0014208fb3e) AND NOT (cte.category:com.concur.midtier.services.reference.defaultcurrencyservice  AND cte.entity_code:t0077475tzlz) AND NOT (cte.category:encryption AND cte.subcategory:aesgcmdecrypt-failure AND description:"mac check in GCM failed")',
                                            "label": "ERRORS",
                                            "color": "rgba(179,179,179,1)",
                                            "id": "c4848620-cc8b-11e8-96f9-5776523bc03b",
                                        }
                                    ],
                                    "override_index_pattern": 1,
                                    "series_index_pattern": "log-*",
                                },
                            ],
                            "time_field": "@timestamp",
                            "index_pattern": "log-parpr1-*",
                            "interval": "auto",
                            "axis_position": "left",
                            "axis_formatter": "number",
                            "show_legend": 1,
                            "legend_position": "bottom",
                            "show_grid": 1,
                            "filter": "application:(EMT OR ExpenseUI OR CESClassic OR Outtask) AND level:(Error OR ERROR OR FATAL) AND NOT environment:im",
                        }
                    ],
                },
                "PAR SM-Invoice-Metrics-v3": {
                    "filters": [{"bool": {"must": [{"match_all": {}}], "must_not": []}}],
                    "timerange": {
                        "max": timerange_max.strftime("%Y-%m-%dT%H:%M:%S"),
                        "min": timerange_min.strftime("%Y-%m-%dT%H:%M:%S"),
                    },
                    "panels": [
                        {
                            "id": "06e34cf0-cd44-11e8-8a96-ebb7100becbf",
                            "type": "timeseries",
                            "series": [
                                {
                                    "id": "291851d0-cd44-11e8-8a96-ebb7100becbf",
                                    "color": "rgba(0,156,224,1)",
                                    "split_mode": "filters",
                                    "metrics": [
                                        {
                                            "id": "291851d1-cd44-11e8-8a96-ebb7100becbf",
                                            "type": "count",
                                        }
                                    ],
                                    "seperate_axis": 0,
                                    "axis_position": "right",
                                    "formatter": "number",
                                    "chart_type": "line",
                                    "line_width": "2",
                                    "point_size": 1,
                                    "fill": 0.5,
                                    "stacked": "none",
                                    "split_filters": [
                                        {
                                            "filter": "cte.subcategory:Action_SubmitRequest",
                                            "label": "Invoice Submits",
                                            "color": "rgba(0,156,224,1)",
                                            "id": "33bfd400-cd44-11e8-8a96-ebb7100becbf",
                                        }
                                    ],
                                    "label": "Invoice Submits",
                                    "override_index_pattern": 1,
                                    "series_index_pattern": "metric-*",
                                },
                                {
                                    "id": "06e34cf1-cd44-11e8-8a96-ebb7100becbf",
                                    "color": "rgba(252,220,0,1)",
                                    "split_mode": "filters",
                                    "metrics": [
                                        {
                                            "id": "06e37400-cd44-11e8-8a96-ebb7100becbf",
                                            "type": "count",
                                        }
                                    ],
                                    "seperate_axis": 0,
                                    "axis_position": "right",
                                    "formatter": "number",
                                    "chart_type": "line",
                                    "line_width": "2",
                                    "point_size": 1,
                                    "fill": "0.3",
                                    "stacked": "none",
                                    "label": "Invoice Screen Views",
                                    "split_filters": [
                                        {
                                            "filter": "cte.subcategory: Screen_CVP_Portal.asp",
                                            "label": "Invoice Screen Views",
                                            "color": "rgba(252,220,0,1)",
                                            "id": "22232940-cd44-11e8-8a96-ebb7100becbf",
                                        }
                                    ],
                                    "override_index_pattern": 1,
                                    "series_index_pattern": "metric-*",
                                },
                            ],
                            "time_field": "@timestamp",
                            "index_pattern": "metric-*",
                            "interval": "auto",
                            "axis_position": "left",
                            "axis_formatter": "number",
                            "show_legend": 1,
                            "legend_position": "bottom",
                            "show_grid": 1,
                            "filter": "application:Metric AND cte.category:Invoice",
                        }
                    ],
                },
                "PAR SM-Report-Submits-AvgRT-v3": {
                    "filters": [{"bool": {"must": [{"match_all": {}}], "must_not": []}}],
                    "timerange": {
                        "max": timerange_max.strftime("%Y-%m-%dT%H:%M:%S"),
                        "min": timerange_min.strftime("%Y-%m-%dT%H:%M:%S"),
                    },
                    "panels": [
                        {
                            "id": "f926c9f0-cd40-11e8-8a96-ebb7100becbf",
                            "type": "timeseries",
                            "series": [
                                {
                                    "id": "32677750-cd41-11e8-8a96-ebb7100becbf",
                                    "color": "rgba(244,78,59,1)",
                                    "split_mode": "filters",
                                    "metrics": [
                                        {
                                            "id": "32677751-cd41-11e8-8a96-ebb7100becbf",
                                            "type": "avg",
                                            "field": "duration_ms",
                                        },
                                        {
                                            "script": "params.bad > 2000 ? params.bad * 1 : null",
                                            "id": "59b591c0-cd41-11e8-8a96-ebb7100becbf",
                                            "type": "calculation",
                                            "variables": [
                                                {
                                                    "id": "5cf94b10-cd41-11e8-8a96-ebb7100becbf",
                                                    "name": "bad",
                                                    "field": "32677751-cd41-11e8-8a96-ebb7100becbf",
                                                }
                                            ],
                                        },
                                    ],
                                    "seperate_axis": 0,
                                    "axis_position": "right",
                                    "formatter": "number",
                                    "chart_type": "line",
                                    "line_width": "2",
                                    "point_size": 1,
                                    "fill": "0.7",
                                    "stacked": "none",
                                    "label": "Report Submits ART (Bad)",
                                    "split_filters": [
                                        {
                                            "filter": "*",
                                            "label": "Report Submits ART (Bad)",
                                            "color": "rgba(244,78,59,1)",
                                            "id": "3964b630-cd41-11e8-8a96-ebb7100becbf",
                                        }
                                    ],
                                    "override_index_pattern": 1,
                                    "series_index_pattern": "metric-*",
                                },
                                {
                                    "id": "f926c9f1-cd40-11e8-8a96-ebb7100becbf",
                                    "color": "#68BC00",
                                    "split_mode": "filters",
                                    "metrics": [
                                        {
                                            "id": "f926c9f2-cd40-11e8-8a96-ebb7100becbf",
                                            "type": "avg",
                                            "field": "duration_ms",
                                        }
                                    ],
                                    "seperate_axis": 0,
                                    "axis_position": "right",
                                    "formatter": "number",
                                    "chart_type": "line",
                                    "line_width": "2",
                                    "point_size": 1,
                                    "fill": "0",
                                    "stacked": "none",
                                    "label": "Report Submits ART (Good)",
                                    "split_filters": [
                                        {
                                            "filter": "*",
                                            "label": "ART (Good)",
                                            "color": "#68BC00",
                                            "id": "12af5950-cd41-11e8-8a96-ebb7100becbf",
                                        }
                                    ],
                                    "override_index_pattern": 1,
                                    "series_index_pattern": "metric-*",
                                },
                                {
                                    "id": "86003910-cd41-11e8-8a96-ebb7100becbf",
                                    "color": "rgba(101,50,148,1)",
                                    "split_mode": "filters",
                                    "metrics": [
                                        {
                                            "id": "86003911-cd41-11e8-8a96-ebb7100becbf",
                                            "type": "avg",
                                            "field": "duration_ms",
                                        }
                                    ],
                                    "seperate_axis": 0,
                                    "axis_position": "right",
                                    "formatter": "number",
                                    "chart_type": "line",
                                    "line_width": "1",
                                    "point_size": 1,
                                    "fill": "0.2",
                                    "stacked": "none",
                                    "label": "Report Submits ART (Last week)",
                                    "split_filters": [
                                        {
                                            "filter": "*",
                                            "label": "ART (Good)",
                                            "color": "rgba(101,50,148,1)",
                                            "id": "12af5950-cd41-11e8-8a96-ebb7100becbf",
                                        }
                                    ],
                                    "offset_time": "168h",
                                    "override_index_pattern": 1,
                                    "series_index_pattern": "metric-*",
                                },
                            ],
                            "time_field": "@timestamp",
                            "index_pattern": "metric-*",
                            "interval": "auto",
                            "axis_position": "left",
                            "axis_formatter": "number",
                            "show_legend": 1,
                            "legend_position": "bottom",
                            "show_grid": 1,
                            "filter": "method:SubmitReport",
                        }
                    ],
                },
                "PAR SRER_OAuth_Trend": {
                    "filters": [{"bool": {"must": [{"match_all": {}}], "must_not": []}}],
                    "timerange": {
                        "max": timerange_max.strftime("%Y-%m-%dT%H:%M:%S"),
                        "min": timerange_min.strftime("%Y-%m-%dT%H:%M:%S"),
                    },
                    "panels": [
                        {
                            "id": "e673d9f0-ba7a-11ea-84e8-f7f9d2d89783",
                            "type": "timeseries",
                            "series": [
                                {
                                    "id": "e6740100-ba7a-11ea-84e8-f7f9d2d89783",
                                    "color": "#68BC00",
                                    "split_mode": "terms",
                                    "metrics": [
                                        {
                                            "id": "e6740101-ba7a-11ea-84e8-f7f9d2d89783",
                                            "type": "count",
                                        }
                                    ],
                                    "seperate_axis": 0,
                                    "axis_position": "right",
                                    "formatter": "number",
                                    "chart_type": "line",
                                    "line_width": 1,
                                    "point_size": 1,
                                    "fill": "0.2",
                                    "stacked": "none",
                                    "terms_field": "name",
                                    "split_color_mode": "rainbow",
                                    "terms_size": "5",
                                }
                            ],
                            "time_field": "@timestamp",
                            "index_pattern": "metric-*",
                            "interval": "auto",
                            "axis_position": "left",
                            "axis_formatter": "number",
                            "show_legend": 1,
                            "filter": 'application: oauth2-service AND description: "metrics\\.web\\."',
                            "show_grid": 1,
                        }
                    ],
                },
                "PAR SM-Invoice-Errors-v3": {
                    "filters": [{"bool": {"must": [{"match_all": {}}], "must_not": []}}],
                    "timerange": {
                        "max": timerange_max.strftime("%Y-%m-%dT%H:%M:%S"),
                        "min": timerange_min.strftime("%Y-%m-%dT%H:%M:%S"),
                    },
                    "panels": [
                        {
                            "id": "a40ebe60-cd44-11e8-8a96-ebb7100becbf",
                            "type": "timeseries",
                            "series": [
                                {
                                    "id": "a40ebe61-cd44-11e8-8a96-ebb7100becbf",
                                    "color": "rgba(0,156,224,1)",
                                    "split_mode": "filters",
                                    "metrics": [
                                        {
                                            "id": "a40ee570-cd44-11e8-8a96-ebb7100becbf",
                                            "type": "count",
                                        }
                                    ],
                                    "seperate_axis": 0,
                                    "axis_position": "right",
                                    "formatter": "number",
                                    "chart_type": "bar",
                                    "line_width": 1,
                                    "point_size": 1,
                                    "fill": "0",
                                    "stacked": "none",
                                    "label": "INVOICE ROUTER UE's",
                                    "split_filters": [
                                        {
                                            "filter": 'cte.category:InvoiceRouter AND NOT cte.subcategory:GetInvoiceImage AND NOT cte.handled:true AND NOT description:"ProtectedValue tampered with" ',
                                            "label": "INVOICE ROUTER UE's",
                                            "color": "rgba(0,156,224,1)",
                                            "id": "bd92e0f0-cd44-11e8-8a96-ebb7100becbf",
                                        }
                                    ],
                                    "override_index_pattern": 1,
                                    "series_index_pattern": "log-*",
                                },
                                {
                                    "id": "033d0bd0-cd45-11e8-8a96-ebb7100becbf",
                                    "color": "rgba(244,78,59,1)",
                                    "split_mode": "filters",
                                    "metrics": [
                                        {
                                            "id": "033d0bd1-cd45-11e8-8a96-ebb7100becbf",
                                            "type": "count",
                                        },
                                        {
                                            "script": "params.critical > 0 ? params.critical * 1 :null",
                                            "id": "17b84570-cd45-11e8-8a96-ebb7100becbf",
                                            "type": "calculation",
                                            "variables": [
                                                {
                                                    "id": "1bf68b60-cd45-11e8-8a96-ebb7100becbf",
                                                    "name": "critical",
                                                    "field": "033d0bd1-cd45-11e8-8a96-ebb7100becbf",
                                                }
                                            ],
                                        },
                                    ],
                                    "seperate_axis": 0,
                                    "axis_position": "right",
                                    "formatter": "number",
                                    "chart_type": "bar",
                                    "line_width": "2",
                                    "point_size": 1,
                                    "fill": 0.5,
                                    "stacked": "none",
                                    "label": "INVOICE ERROS UE's",
                                    "split_filters": [
                                        {
                                            "filter": "cte.subcategory:GetInvoiceImage AND NOT cte.handled:true",
                                            "label": "INVOICE ERROS UE's",
                                            "color": "rgba(244,78,59,1)",
                                            "id": "08a3a520-cd45-11e8-8a96-ebb7100becbf",
                                        }
                                    ],
                                    "override_index_pattern": 1,
                                    "series_index_pattern": "log-*",
                                },
                            ],
                            "time_field": "@timestamp",
                            "index_pattern": "log-*",
                            "interval": "auto",
                            "axis_position": "left",
                            "axis_formatter": "number",
                            "show_legend": 1,
                            "legend_position": "bottom",
                            "show_grid": 1,
                            "filter": "application:ExpenseUI",
                        }
                    ],
                },
            },
        }

        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(3)
            sock.connect((f'lp-search-{datacenter}.concur.com', 443))
            results = {}
            for name in params[datacenter]:
                query_data(datacenter, name)

            start = time.time()
            while len(results.keys()) != len(params[datacenter].keys()) and (time.time() - start) < 60:
                time.sleep(0.1)

            return JsonResponse(results, safe=False)

        except Exception as error:
            print(error)
            return JsonResponse({'error': str(error)})
    return JsonResponse(None, safe=False)


@api_view(['GET'])
def pd_alerts_list(request):
    if request.method == 'GET':
        try:
            start_date = request.GET.get('start_date', None)
            end_date = request.GET.get('end_date', None)
            if not start_date and not end_date:
                end_date = Incidents.objects.all().order_by('pagerduty_id__created_on').last().pagerduty_id.created_on
                start_date = end_date - datetime.timedelta(days=1)
            qs = Incidents.objects.all().filter(pagerduty_id__created_on__range=(start_date, end_date))
            results = list(qs.values('pagerduty_id__created_on', 'pagerduty_id', 'pagerduty_id__description',
                                     'pagerduty_id__service_name', 'region', 'product', 'tier', 'dc', 'alert_source',
                                     'trans', 'alert_type', 'alert_category', 'dow'))
            return JsonResponse({'total': qs.count(), 'data': results}, safe=False)
        except Exception as error:
            print(error)
            return JsonResponse({'error': str(error)})
    return JsonResponse(None, safe=False)


@api_view(['GET'])
def pd_open_alerts_count(request):
    if request.method == 'GET':
        params = (
            ('date_range', 'all'),
            ('user_ids', ''),
            ('statuses[]', ['acknowledged', 'triggered']),
            ('current_user', request.user.srer.pagerduty_id),
            ('on_my_teams', 'true'),
            ('with_suppressed', 'true'),
        )
        headers = {
            'content-type': 'application/json',
            'authorization': f'Token token={request.user.srer.pagerduty_token}',
        }
        try:
            response = requests.get('https://sap.pagerduty.com/api/v1/incidents/count', params=params, headers=headers)
            if response.reason != 'OK':
                raise Exception(response.reason)
            return JsonResponse(response.json())
        except Exception as error:
            return JsonResponse({'error': str(error)})
    return JsonResponse(None, safe=False)


@api_view(['GET'])
def pagerduty_top_alerts(request):
    if request.method == 'GET':
        count = request.GET.get('count', None)
        start_date = request.GET.get('start_date', None)
        end_date = request.GET.get('end_date', None)
        alert_type = request.GET.get('alert_type', None)

        qs = PagerDuty.objects.all()

        if not count:
            count = 12

        if not start_date or not end_date:
            end_date = qs.order_by('created_on').last().created_on
            while True:
                if end_date.strftime('%A') == 'Wednesday':
                    break
                end_date = end_date - datetime.timedelta(days=1)
            start_date = end_date - datetime.timedelta(days=4*7)  # 4 weeks
        else:
            end_date = parser.parse(end_date)
            start_date = parser.parse(start_date)
        qs = qs.filter(created_on__range=(start_date, end_date))

        if alert_type:
            query = Q()
            for alert in alert_type.split(','):
                if alert == 'synthetics':
                    query.add(Q(description__icontains='synthetics'), Q.OR)
                else:
                    query.add(Q(description__iregex=r'(-error|-rt|-rpm|-avail)'), Q.OR)
            qs = qs.filter(query)

        top_alerts = list(qs.values('description').annotate(count=Count('description')).order_by('count').reverse()[:int(count)])
        top_alerts = [
            {'Description': re.sub('_CRITICAL -.*', '_CRITICAL', i['description'].replace('[watcher] ', '')),
             'Count': i['count']
             } for i in top_alerts
        ]

        filename = f'top-pd-alerts_{start_date.strftime("%Y-%m-%d")}_{end_date.strftime("%Y-%m-%d")}.csv'
        response = HttpResponse(content_type='text/csv', headers={'Content-Disposition': f'attachment; filename={filename}'})
        writer = csv.writer(response)
        writer.writerow(top_alerts[0].keys())
        for i in top_alerts:
            writer.writerow(i.values())
        return response
    return JsonResponse(None, safe=False)


@api_view(['GET'])
def api_test(request):
    if request.method == 'GET':
        try:
            account_id = request.GET.get('account_id', None)
            incident_id = request.GET.get('incident_id', None)
            synthetics = request.GET.get('synthetics', None)
            user = SRER.objects.get(user__username='admin')
            nr_api_key = getattr(user, [i for i in dir(user) if i.split('_')[-1] == account_id][0])

            url = f'https://frame-alerts.newrelic.com/internal_api/1/accounts/{account_id}/incidents/{incident_id}/violations?only_muted=false&only_open=false&per_page_size=10'
            response = requests.get(url, headers={'Api-Key': nr_api_key})
            if response.reason != 'OK':
                raise Exception(response.reason)

            critical_threshold = response.json()['violations'][0]['criticalThreshold']
            degrade_start = response.json()['violations'][0]['degradationStartTime']
            degrade_end = response.json()['violations'][0]['recoveryEndTime']
            violation_start = response.json()['violations'][0]['violationStartTimestamp']
            violation_end = response.json()['violations'][0]['violationEndTimestamp']
            violation_id = response.json()['violations'][0]['id']

            current_time = int(datetime.datetime.now().timestamp()) * 1000
            start_time = violation_start - (30 * 60 * 1000)
            diff = (current_time - start_time) / 1000 / 60

            if diff <= 59:
                end_time = current_time
                duration = int(end_time - start_time)
            else:
                end_time = violation_start + (30 * 60 * 1000)
                duration = int(end_time - start_time)

            if not violation_end:
                violation_end = end_time
            if not degrade_start:
                degrade_start = start_time

            if eval(synthetics):
                url = f'https://frame-alerts.newrelic.com/internal_api/1/accounts/{account_id}/charts/violations?violation_id={violation_id}&timestamp={violation_start}'
                retries = 0
                while retries <= 5:
                    response = requests.get(url, headers={'Api-Key': nr_api_key})
                    if response.reason == 'OK':
                        break
                    retries += 1
                if response.reason != 'OK':
                    raise Exception(response.reason)
                chart_data = [{'date': i['c'][0]['v'], 'value': i['c'][1]['f']} for i in response.json() if i['c'][1]['f'] != 'No available data']
                return JsonResponse({
                    'chart_data': chart_data,
                    'threshold': critical_threshold,
                    'degrade_start': degrade_start,
                    'violation_start': violation_start,
                    'violation_end': violation_end,
                    'degrade_end': degrade_end
                })
            data = {
                "account_id": account_id,
                "duration": duration,
                "end_time": end_time,
                "proxied_data": {
                    "account_violation_id": response.json()['violations'][0]['accountViolationId'],
                    "label": response.json()['violations'][0]['label'],
                    "violation_regions": [{
                        "name": "CRITICAL",
                        "color": "#DA726C",
                        "begin_time": violation_start,
                        "end_time": violation_end
                    }, {
                        "name": "DEGRADATION",
                        "color": "#F9C3C9",
                        "begin_time": degrade_start,
                        "end_time": violation_start
                    }],
                    "thresholds": [{
                        "color": "#D1D1D1",
                        "unit": "UNSPECIFIED",
                        "value": critical_threshold
                    }]
                }
            }
            retries = 0
            while retries <= 5:
                response = requests.post('https://chartdata.service.newrelic.com/v2/ext/alerts/violations', headers={'Api-Key': nr_api_key}, data=json.dumps(data))
                if response.reason == 'OK':
                    break
                retries += 1
            if response.reason != 'OK':
                raise Exception(response.reason)
            return JsonResponse(response.json())
        except Exception as error:
            print(error)
            return JsonResponse({'error': str(error)})
    return JsonResponse(None, safe=False)


@api_view(['GET'])
def synthetics_alert_history(request):
    if request.method == 'GET':
        try:
            monitor_name = request.GET.get('monitor_name', None)
            account_id = request.GET.get('account_id', None)
            since = request.GET.get('since', None)
            user = SRER.objects.get(user__username='admin')
            nr_api_key = getattr(user, [i for i in dir(user) if i.split('_')[-1] == account_id][0])
            headers = {
                'Content-Type': 'application/json',
                'Api-Key': nr_api_key
            }

            nrql = f"SELECT id, entityGuid, duration, result, error, location FROM SyntheticCheck WHERE monitorName = '{monitor_name}' since {since}"
            response = requests.post('https://chartdata.service.newrelic.com/v3/nrql', headers=headers,
                                     data=json.dumps({'nrql': nrql, 'account_id': account_id}))
            if response.reason != 'OK':
                raise Exception(response.reason)

            return JsonResponse({'results': response.json()[0]['series'][0]['data']})
        except Exception as error:
            print(error)
            return JsonResponse({'error': str(error)})
    return JsonResponse(None, safe=False)


@api_view(['GET'])
def synthetics_monitors_list(request):
    if request.method == 'GET':
        try:
            user = SRER.objects.get(user__username='admin')
            headers = {
                'Content-Type': 'application/json',
                'Api-Key': user.concur_shared_1280715
            }
            entities = []
            accounts = ['1301883', '1301884', '1280715', '1301885', '1301887', '2439350', '3111938', '3111936']
            for account in accounts:
                data = {'query': '''{
                  actor {
                    entitySearch(query: """
                            name LIKE 'SRER' AND 
                            name NOT LIKE 'LUI' AND name NOT LIKE 'test' AND name NOT LIKE 'lifecheck' AND
                            domain = 'SYNTH' AND type = 'MONITOR' AND 
                            accountId = %s AND `tags.monitorStatus` = 'Enabled'""") {
                      results {
                        entities {
                          name
                          account {
                            name
                            id
                          }
                          alertSeverity
                          permalink
                        }
                      }
                    }
                  }
                }''' % account}
                api_key = user.prod_uspscc_hsm_2439350 if account == '2439350' else user.concur_shared_1280715
                headers['Api-Key'] = api_key
                response = requests.post('https://api.newrelic.com/graphql', headers=headers, data=json.dumps(data))
                entities.extend(response.json()['data']['actor']['entitySearch']['results']['entities'])
            return JsonResponse({'results': entities})
        except Exception as error:
            print(error)
            return JsonResponse({'error': str(error)})
    return JsonResponse(None, safe=False)


@api_view(['GET'])
def synthetics_error_screenshot(request):
    if request.method == 'GET':
        try:
            guid = request.GET.get('guid', None)
            account_id = request.GET.get('account_id', None)
            check_id = request.GET.get('check_id', None)
            user = SRER.objects.get(user__username='admin')
            nr_api_key = getattr(user, [i for i in dir(user) if i.split('_')[-1] == account_id][0])
            headers = {
                'Content-Type': 'application/json',
                'Api-Key': nr_api_key
            }
            data = {'query': '''{
              actor {
                entity(guid: "%s") {
                  ... on SyntheticMonitorEntity {
                    assets(checkId: "%s") {
                      type
                      url
                    }
                  }
                }
              }
            }''' % (guid, check_id)}
            response = requests.post('https://api.newrelic.com/graphql', headers=headers, data=json.dumps(data))
            if response.reason != 'OK':
                raise Exception(response.reason)
            return JsonResponse({'results': response.json()})
        except Exception as error:
            print(error)
            return JsonResponse({'error': str(error)})


@api_view(['GET'])
def add_pagerduty_data(request):
    if request.method == 'GET':
        try:
            pd = PagerDutyData()
            pd_entries = pd.fetch_pagerduty_data()
            if isinstance(pd_entries, Exception):
                raise Exception(pd_entries)

            log_entries = pd.fetch_log_entries_data(pd_entries)
            if isinstance(log_entries, Exception):
                raise Exception(pd_entries)

            pd.add_pagerduty_data(pd_entries)
            pd.parse_pagerduty_data(pd_entries)
            pd.add_incident_data(log_entries)
            return HttpResponse(f'Total number of new incidents added: {len(pd_entries)}')
        except Exception as error:
            print(error)
            return JsonResponse({'error': str(error)})
    return JsonResponse(None, safe=False)


@api_view(['GET'])
def knowledge_base_doc(request):
    if request.method == 'GET':
        try:
            doc = request.GET.get('doc', None)
            q = KnowledgeBase.objects.get(document=doc.strip())
            q.views += 1
            q.save()

            docs_dir = 'webapp/static/docs'
            content = open(os.path.join(docs_dir, q.document), 'r').read()
            content = re.sub('../assets/', 'static/docs/assets/', content)
            comments = list(q.kbcomments_set.all().values('id', 'comment', 'user__user__username', 'created_at', 'likes'))
            return JsonResponse({'path': q.document, 'content': content, 'likes': q.kblikes_set.all().count(), 'views': q.views,
                                 'comments': comments})
        except Exception as error:
            print(error)
            return JsonResponse({'error': str(error)})
    return JsonResponse(None, safe=False)


@api_view(['GET'])
def knowledge_base_search(request):
    if request.method == 'GET':
        try:
            keyword = request.GET.get('keyword', None)
            if keyword:
                q = KnowledgeBase.objects.filter(document__icontains=keyword)
                return JsonResponse({'results': list(q.annotate(text=F('document')).values('text', 'id'))})
        except Exception as error:
            print(error)
            return JsonResponse({'error': str(error)})
    return JsonResponse(None, safe=False)


@api_view(['POST'])
def knowledge_base_like(request):
    if request.method == 'POST':
        try:
            doc = request.POST.get('doc', None)
            like = request.POST.get('like', None)
            q = KnowledgeBase.objects.get(document=doc.strip())
            if like:
                try:
                    KBLikes.objects.create(document=q, user=request.user.srer)
                except IntegrityError as e:
                    if 'UNIQUE constraint' in str(e.args):
                        KBLikes.objects.get(document=q, user=request.user.srer).delete()

            return JsonResponse({'likes': q.kblikes_set.all().count()})
        except Exception as error:
            print(error)
            return JsonResponse({'error': str(error)})
    return JsonResponse(None, safe=False)


@api_view(['POST'])
def knowledge_base_comment(request):
    if request.method == 'POST':
        try:
            doc = request.POST.get('doc', None)
            comment = request.POST.get('comment', None)
            delete = request.POST.get('delete', None)
            pk = request.POST.get('pk', None)
            q = KnowledgeBase.objects.get(document=doc.strip())

            if comment:
                KBComments.objects.create(comment=comment, document=q, user=request.user.srer)
            elif delete:
                KBComments.objects.get(id=pk, user=request.user.srer).delete()
            comments = list(q.kbcomments_set.all().values('id', 'comment', 'user__user__username', 'created_at', 'likes'))
            return JsonResponse({'comments': comments})
        except Exception as error:
            print(error)
            return JsonResponse({'error': str(error)})
    return JsonResponse(None, safe=False)


@api_view(['POST'])
def knowledge_base_edit(request):
    if request.method == 'POST':
        try:
            doc = request.POST.get('doc', None)
            new_content = request.POST.get('new_content', None)

            q = KnowledgeBase.objects.get(document=doc.strip())

            new_content = re.sub('static/docs/assets/', '../assets/', new_content)
            docs_dir = 'webapp/static/docs'

            modified_by = request.user.srer
            with open(os.path.join(docs_dir, q.document), 'w') as file:
                file.write(new_content)
                q.modified_at = timezone.now()
                q.modified_by = modified_by
                q.save()

            content = open(os.path.join(docs_dir, q.document), 'r').read()
            content = re.sub('../assets/', 'static/docs/assets/', content)

            return JsonResponse({'content': content})
        except Exception as error:
            print(error)
            return JsonResponse({'error': str(error)})
    return JsonResponse(None, safe=False)


@api_view(['GET'])
def script_details(request):
    if request.method == 'GET':
        try:
            script = request.GET.get('script', None)
            script_dir = 'webapp/scripts'
            script_qs = Scripts.objects.get(name=script.strip())
            content = open(os.path.join(script_dir, script.strip()), 'r').read()

            last_executed = script_qs.jobs_set.all().last()
            if last_executed:
                last_executed = last_executed.start

            jobs_running = Jobs.objects.all().filter(end__isnull=True)
            if jobs_running:
                jobs_running = [job.script.name for job in jobs_running]

            return JsonResponse({'content': content, 'last_executed': last_executed, 'jobs_running': list(jobs_running)})
        except Exception as error:
            print(error)
            return JsonResponse({'error': str(error)})
    return JsonResponse(None, safe=False)


@api_view(['GET'])
def script_execute(request):
    if request.method == 'GET':
        try:
            user = request.user.srer
            script = request.GET.get('script', None).strip()
            args = request.GET.get('args', None)
            if args:
                args = ','.join(args.split(','))

            if Jobs.objects.all().filter(script__name=script, end__isnull=True):
                raise Exception('job already running')

            def stream_response_generator():
                command = 'source ../venv/bin/activate;'
                command += 'python manage.py shell --command '
                command += f'"from webapp.scripts.scheduler import Event;'
                command += f'event = Event(\'{script}\', user=\'{user}\', args=\'{args}\'); event.execute_job()"'

                process = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, shell=True)
                while True:
                    output = process.stdout.readline()
                    if process.poll() is not None and output == b'':
                        break
                    yield f'{output.decode("utf-8").strip()}\n'

            return StreamingHttpResponse(stream_response_generator())

        except Exception as error:
            print(error)
            return JsonResponse({'error': str(error)})
    return JsonResponse(None, safe=False)


@api_view(['GET'])
def events_data(request):
    if request.method == 'GET':
        try:
            events_qs = Events.objects.all().filter(enabled=True)
            dt_now = datetime.datetime.now()
            today = dt_now.replace(hour=0, minute=0)
            events = []

            for i in range(1, 7):
                dt = today - datetime.timedelta(days=i)
                qs = [i.script.name for i in events_qs if
                      dt.day in eval(i.day) and dt.month in eval(i.months) and dt.weekday() in eval(i.dow)]
                events.append({dt.strftime('%Y-%m-%d'): qs})
            for i in range(0, 7):
                dt = today + datetime.timedelta(days=i)
                qs = [i.script.name for i in events_qs if
                      dt.day in eval(i.day) and dt.month in eval(i.months) and dt.weekday() in eval(i.dow)]
                events.append({dt.strftime('%Y-%m-%d'): qs})

            upcoming_events = []
            for i in range(60 * 24):
                dt = dt_now + datetime.timedelta(minutes=i)
                for j in events_qs:
                    if dt.hour in eval(j.hour) and dt.minute in eval(j.minute):
                        last = j.script.jobs_set.last()
                        last_executed = duration = last_status = None
                        if last:
                            last_status = last.result
                            last_executed = last.start
                            duration = round(last.duration, 2) if last.duration else None
                        upcoming_events.append({
                            'name': j.script.name, 'scheduled': dt, 'last_executed': last_executed,
                            'last_status': last_status, 'duration': duration
                        })
            return JsonResponse({'results': events, 'upcoming_events': upcoming_events})
        except Exception as error:
            print(error)
            return JsonResponse({'error': str(error)})
    return JsonResponse(None, safe=False)


@api_view(['GET'])
def jobs_data(request):
    if request.method == 'GET':
        try:
            job_id = request.GET.get('job_id', None)
            jobs_qs = Jobs.objects.all()
            job_failed_today = jobs_qs.filter(start__date=datetime.datetime.today().date(), end__isnull=False,
                                              result='FAILED').count()
            if job_id:
                jobs_qs = jobs_qs.filter(pk=job_id)
            return JsonResponse({'jobs_qs': list(jobs_qs.values('id', 'script__name', 'start', 'end', 'script__description', 'executed_by__user__username', 'duration', 'result', 'output')), 'job_failed_today': job_failed_today})
        except Exception as error:
            print(error)
            return JsonResponse({'error': str(error)})
    return JsonResponse(None, safe=False)


@api_view(['GET'])
def job_abort(request):
    if request.method == 'GET':
        try:
            script = request.GET.get('script', None)
            srer = request.user.srer

            script_qs = Scripts.objects.get(name=script.strip())
            jobs_qs = Jobs.objects.all()
            if not jobs_qs.filter(script=script_qs, end__isnull=True):
                raise Exception('job not found')

            job = jobs_qs.filter(script=script_qs, end__isnull=True).first()
            if job.executed_by.user.username != srer.user.username and job.executed_by.user.username != 'admin':
                raise Exception('failed to abort job')

            try:
                script = os.path.splitext(script_qs.name)[0]
                process = subprocess.run("kill -9 $(ps -ef | grep 'manage.py' | grep '%s' | awk '{print $2}')" % script,
                                         stdout=subprocess.PIPE, stderr=subprocess.STDOUT, shell=True)
                output = process.stdout.decode('utf-8').strip()
            except Exception as err:
                raise Exception(err)
            finally:
                job.end = timezone.now()
                job.duration = (job.end - job.start).microseconds / 1000000
                job.result = 'FAILED'
                job.save()
            return JsonResponse({'result': 'success'})
        except Exception as error:
            print(error)
            return JsonResponse({'error': str(error)})
    return JsonResponse(None, safe=False)


@api_view(['GET'])
def stream_job_output(request):
    if request.method == 'GET':
        try:
            script = request.GET.get('script', None)
            script_qs = Scripts.objects.get(name=script.strip())
            job = Jobs.objects.all().filter(script=script_qs, end__isnull=True).first()
            if not job:
                return JsonResponse({'end': True})
            print(job.output)
            return JsonResponse({'output': job.output})
        except Exception as error:
            print(error)
            return JsonResponse({'error': str(error)})
    return JsonResponse(None, safe=False)


@api_view(['GET'])
def get_pd_maintenances(request):
    offset, limit, more, maintenances = 0, 100, True, []
    headers = {
        'content-type': 'application/json',
        'authorization': f'Token token={request.user.srer.pagerduty_token}',
    }
    if request.method == 'GET':
        try:
            while more:
                _filter = request.GET.get('filter', 'ongoing')
                params = (
                    ('team_ids[]', 'PVKSDSW'),
                    ('limit', limit),
                    ('offset', offset),
                    ('total', 'true'),
                    ('filter', _filter)
                )
                response = requests.get('https://sap.pagerduty.com/api/v1/maintenance_windows', params=params, headers=headers)
                if response.reason != 'OK':
                    raise Exception(response.reason)
                maintenances.extend(response.json()['maintenance_windows'])
                offset += limit
                more = response.json()['more']
            return JsonResponse({'maintenance_windows': maintenances})
        except Exception as error:
            print(error)
            return JsonResponse({'error': str(error)})
    return JsonResponse(None, safe=False)


@api_view(['POST'])
def set_pd_maintenances(request):
    if request.method == 'POST':
        try:
            start_date = request.POST.get('start_time', None)
            end_date = request.POST.get('end_time', None)
            services = request.POST.get('services', None)
            locale = request.POST.get('locale', 'utc')

            start_time = pytz.timezone(locale).localize(parser.parse(start_date)).isoformat()
            end_time = pytz.timezone(locale).localize(parser.parse(end_date)).isoformat()
            services_json = [{'id': i, "type": "service_reference"} for i in services.split(',')]

            headers = {
                'content-type': 'application/json',
                'authorization': f'Token token={request.user.srer.pagerduty_token}',
            }
            data = {"maintenance_window": {
                "type": "maintenance_window",
                "start_time": start_time,
                "end_time": end_time,
                "services": services_json,
            }}
            response = requests.post('https://sap.pagerduty.com/api/v1/maintenance_windows', headers=headers, data=json.dumps(data))
            if response.reason != 'OK':
                raise Exception(response.reason)
            return JsonResponse(response.json())
        except Exception as error:
            print(error)
            return JsonResponse({'error': str(error)})
    return JsonResponse(None, safe=False)


@api_view(['POST'])
def update_pd_maintenances(request, maint_id):
    if request.method == 'POST':
        try:
            start_date = request.POST.get('start_time', None)
            end_date = request.POST.get('end_time', None)
            old_start = request.POST.get('old_start', None)
            serv_id = request.POST.get('serv_id', None)
            locale = request.POST.get('locale', 'utc')

            start_time = pytz.timezone(locale).localize(parser.parse(start_date)).isoformat()
            end_time = pytz.timezone(locale).localize(parser.parse(end_date)).isoformat()
            services_json = [{'id': serv_id, "type": "service_reference"}]

            headers = {
                'content-type': 'application/json',
                'authorization': f'Token token={request.user.srer.pagerduty_token}',
            }
            time_now = pytz.timezone(locale).localize(datetime.datetime.now()).isoformat()

            if old_start >= time_now:
                data = {
                    "maintenance_window": {
                        "id": maint_id,
                        "type": "maintenance_window",
                        "start_time": start_time,
                        "end_time": end_time,
                        "services": services_json,
                    }
                }
            else:
                data = {
                    "maintenance_window": {
                        "id": maint_id,
                        "type": "maintenance_window",
                        "end_time": end_time,
                        "services": services_json,
                    }
                }
            response = requests.put(f'https://sap.pagerduty.com/api/v1/maintenance_windows/{maint_id}', headers=headers, data=json.dumps(data))
            if response.reason != 'OK':
                raise Exception(response.reason)
            return JsonResponse(response.json())
        except Exception as error:
            print(error)
            return JsonResponse({'error': str(error)})
    return JsonResponse(None, safe=False)


@api_view(['POST'])
def delete_pd_maintenances(request, maint_id):
    if request.method == 'POST':
        try:
            headers = {
                'content-type': 'application/json',
                'authorization': f'Token token={request.user.srer.pagerduty_token}',
            }
            response = requests.delete(f'https://sap.pagerduty.com/api/v1/maintenance_windows/{maint_id}', headers=headers)
            if response.reason != 'No Content':
                raise Exception(response.reason)
            return JsonResponse(response.json())
        except Exception as error:
            print(error)
            return JsonResponse({'error': str(error)})
    return JsonResponse(None, safe=False)


@api_view(['GET'])
def get_change_history(request):
    if request.method == 'GET':
        try:
            url = 'https://open.concur.com/api/change/prod/recent_auto_changes/'
            api_key = SRER.objects.get(user__username='admin').aviary_api
            range_start = request.GET.get('range_start', (datetime.datetime.today() - datetime.timedelta(days=1)).strftime('%Y-%m-%dT%H:%M'))
            range_end = request.GET.get('range_end', datetime.datetime.today().strftime('%Y-%m-%dT%H:%M'))
            params = {'range_start': range_start, 'range_end': range_end}
            response = requests.get(url, params=params, headers={'X-API-Key': api_key, 'Content-Type': 'application/json'})
            return JsonResponse(response.json())
        except Exception as error:
            print(error)
            return JsonResponse({'error': str(error)})
    return JsonResponse(None, safe=False)
