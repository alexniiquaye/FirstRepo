from django.contrib import admin
from .models import *


@admin.register(PagerDuty)
class PagerDutyAdmin(admin.ModelAdmin):
    list_display = ('id', 'created_on', 'description', 'service_name', 'resolved_by_user_name')

    def description(self, obj):
        return obj.pagerduty_id.description

    def has_add_permission(self, request, obj=None):
        return False

    def has_delete_permission(self, request, obj=None):
        return False


@admin.register(Incidents)
class IncidentsAdmin(admin.ModelAdmin):
    list_display = ['pagerduty_id', 'created_on', 'description', 'alert_source', 'alert_category', 'dc', 'product', 'tier']

    def pagerduty_id(self, obj):
        return obj.pagerduty_id.id

    def description(self, obj):
        return obj.pagerduty_id.description

    def created_on(self, obj):
        return obj.pagerduty_id.created_on

    def has_add_permission(self, request, obj=None):
        return False

    def has_delete_permission(self, request, obj=None):
        return False


@admin.register(SRER)
class SRERAdmin(admin.ModelAdmin):
    list_display = ['user', 'email', 'first_name', 'last_name', 'pagerduty_id', 'region']

    def email(self, obj):
        return obj.user.email

    def first_name(self, obj):
        return obj.user.first_name

    def last_name(self, obj):
        return obj.user.last_name

    def has_add_permission(self, request, obj=None):
        return False

    def has_delete_permission(self, request, obj=None):
        return False

    def get_fields(self, request, obj=None):
        if obj.user.username == 'admin':
            fields = ['concur_spend_management_1301883', 'concur_travel_1301884', 'concur_shared_1280715', 'concur_analytics_1301885', 'shared_platform_services_1301887', 'concur_integration_2596260', 'prod_uspscc_hsm_2439350', 'concur_imaging_1301886', 'concur_us2_3111936', 'concur_eu2_3111938', 'jira_token', 'slack_api_token', 'github_token', 'watcher_session_sea', 'watcher_session_par', 'watcher_session_beipr1', 'aviary_api']
        else:
            fields = ['region', 'i_number', 'pagerduty_token', 'pagerduty_id', 'device42_username', 'device42_password']
        return fields


@admin.register(QuickLinks)
class QuickLinksAdmin(admin.ModelAdmin):
    list_display = ['description', 'datacenter', 'link', 'source', 'service']


@admin.register(SyntheticMonitors)
class SyntheticMonitors(admin.ModelAdmin):

    def synthetic_account(self, obj):
        return obj.syntheticaccounts_set.first().name

    list_display = ['name', 'account', 'datacenter', 'email', 'url', 'synthetic_account']


@admin.register(SyntheticAccounts)
class SyntheticAccounts(admin.ModelAdmin):
    readonly_fields = ('created_at', 'last_updated')

    list_display = ['name', 'account', 'created_at', 'last_updated', 'rotate']


@admin.register(Events)
class EventsAdmin(admin.ModelAdmin):
    readonly_fields = ('status',)

    list_display = ['script', 'schedule', 'enabled']
