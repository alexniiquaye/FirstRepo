import re
import time
import pytz
import json
import base64
import requests
from urllib.parse import urlparse
from dateutil import parser

from webapp.models import *
from webapp.scripts.kibana import KibanaAPI
from webapp.scripts import multitasking


class SyntheticsAPI(object):

    def __init__(self):
        self.user = SRER.objects.get(user__username='admin')
        self.session = requests.Session()
        self.session.headers.update({
            'Content-Type': 'application/json',
            'Api-Key': self.user.concur_shared_1280715
        })
        self.base_url = 'https://synthetics.newrelic.com/synthetics/api'

    def set_api_key(self, account_name, account_id):
        api_key = getattr(self.user, f'{account_name.lower()}_{account_id}')
        self.session.headers['Api-Key'] = api_key

    def get_monitor_id(self, guid):
        data = {'query': '''{
            actor {
                entity(guid: "%s") {
                    ... on SyntheticMonitorEntity {monitorId}
                }
            }
        }''' % guid}
        response = self.session.post('https://api.newrelic.com/graphql', data=json.dumps(data))
        return response.json()['data']['actor']['entity']['monitorId']

    def get_monitor_guid(self, name):
        data = {'query': ''' {
            actor {
                entitySearch(query: "name IN ('%s') AND domain IN ('SYNTH') AND type IN ('MONITOR')") {
                    results {
                        entities {
                            guid name account {name id}
                        }
                    }
                }
            }
        }''' % name}
        response = self.session.post('https://api.newrelic.com/graphql', data=json.dumps(data))
        for item in response.json()['data']['actor']['entitySearch']['results']['entities']:
            if item['name'].lower() == name.lower():
                return item['guid']

    def get_monitor(self, monitor_id):
        start = time.time()
        while True:
            response = self.session.get(f'{self.base_url}/v3/monitors/{monitor_id}')
            if response.reason == 'OK':
                return response.json()
            elif (time.time() - start) > 10:
                break
            time.sleep(0.2)

    @multitasking.task
    def get_monitor_script(self, account, monitor_id,  scripts):
        start = time.time()
        while True:
            self.set_api_key(account['name'], account['id'])
            response = self.session.get(f'{self.base_url}/v3/monitors/{monitor_id}/script')
            if response.reason == 'OK':
                scripts[monitor_id] = base64.b64decode(response.json()['scriptText']).decode('utf-8')
                break
            elif (time.time() - start) > 10:
                break
            time.sleep(0.2)

    @multitasking.task
    def get_secure_cred(self, account, secure_cred, secure_creds):
        start = time.time()
        while True:
            self.set_api_key(account['name'], account['id'])
            response = self.session.get(f'{self.base_url}/v1/secure-credentials/{secure_cred}')
            if response.reason == 'OK':
                secure_creds[secure_cred]['secure_cred'] = response.json()
                break
            elif (time.time() - start) > 10:
                break
            time.sleep(0.2)

    def update_monitor_status(self, monitor_id, status):
        monitor = self.get_monitor(monitor_id)
        monitor.update({'status': status})
        start = time.time()
        while True:
            response = self.session.put(f'{self.base_url}/v3/monitors/{monitor["id"]}', data=json.dumps(monitor))
            if response.reason == 'No Content':
                return response
            elif (time.time() - start) > 10:
                break
            time.sleep(0.2)

    def update_secure_cred(self, secure_cred, password):
        data = {
            'key': secure_cred,
            'value': password
        }
        response = self.session.put(f'{self.base_url}/v1/secure-credentials/{secure_cred}', data=json.dumps(data))
        return response

    def get_monitor_status(self, monitor_id):
        return self.get_monitor(monitor_id)['status']

    def get_monitor_state(self, name):
        data = {'query': ''' {
            actor {
                entitySearch(query: "name IN ('%s') AND domain IN ('SYNTH') AND type IN ('MONITOR')") {
                    results {
                        entities {
                            guid name account {name id} ... on AlertableEntityOutline {alertSeverity}
                        }
                    }
                }
            }
        }''' % name}
        response = self.session.post('https://api.newrelic.com/graphql', data=json.dumps(data))
        for item in response.json()['data']['actor']['entitySearch']['results']['entities']:
            if item['name'].lower() == name.lower():
                return item['alertSeverity']

    @staticmethod
    def parse_entity(email, script):
        regex = re.search('entity:.+?\\\\n', script, re.IGNORECASE)
        if regex:
            return regex.group().split(':')[-1].strip().replace('\\n', '')
        if 'bei' in email.lower():
            return None
        if 'emea' in email.lower() or 'par' in email.lower():
            datacenter = 'par'
        else:
            datacenter = 'sea'
        kibana = KibanaAPI()
        query = f"login_id: \"{email}\""
        response = kibana.m_search(datacenter, query)
        entity_set = set()
        for i in response.json()['responses'][0]['hits']['hits']:
            if 'cte' in i['_source'] and 'entity_code' in i['_source']['cte']:
                entity_set.add((i['_source']['cte']['entity_code']))
        if entity_set:
            return list(entity_set)[0]
        return None

    @staticmethod
    def parse_url(script):
        url = None
        url_matched = re.search('browser\\.get\\(.*?\\)', script)
        if not url_matched:
            url_matched = re.search(f'var.?cteUrl.*?=.*?(\"|\').*?(\"|\')', script)
            if url_matched:
                url = url_matched.group().split('=')[-1].replace('"', '').strip()
        else:
            url = re.findall('\\((.*?)\\)', url_matched.group())[-1].replace("'", '').replace('"', '')
            if 'http' not in url:
                url_matched = re.search(f'var.?{url}.*?=.*?(\"|\').*?(\"|\')', script)
                if not url_matched:
                    return url
                url = url_matched.group().split('=')[-1].replace('"', '').strip()
            url = f'https://{urlparse(url).hostname}'
        return url

    @staticmethod
    def parse_email(script):
        email = None
        email_matched = re.search('\\("username-input"\\)\\)\\.sendKeys\\(.*?\\)', script)
        if not email_matched:
            email_matched = re.search(f'var username.*?=.*?(\"|\').*?(\"|\')', script)
            if email_matched:
                email = email_matched.group().split('=')[-1].replace('"', '').strip()
        else:
            email = re.findall('\\((.*?)\\)', email_matched.group().replace('"', ''))[-1].strip()
            if '$secure' in email:
                return email

            if '@' not in email:
                email_matched = re.search(f'var {email}.*?=.*?(\"|\').*?(\"|\')', script)
                if not email_matched:
                    return email
                email = email_matched.group().split('=')[-1].replace('"', '').strip()
        return email

    @staticmethod
    def parse_secure_cred(script):
        secure_cred = None
        secure_cred_matched = re.search('\\("password"\\)\\)\\.sendKeys\\(.*?\\)', script)
        if not secure_cred_matched:
            secure_cred_matched = re.search(f'var password.*?=.*?(\"|\').*?(\"|\')', script)
            if secure_cred_matched:
                if '$secure' in secure_cred_matched.group():
                    secure_cred = re.search('\\$secure\\.(.*?)\\.toString', secure_cred_matched.group()).group(1)
        else:
            secure_cred = re.findall('\\((.*?)\\)', secure_cred_matched.group())[-1]
            if '$secure' not in secure_cred.lower():
                secure_cred_matched = re.search(f'var {secure_cred}.*?=.*?.toString', script)
                if not secure_cred_matched:
                    return secure_cred
                secure_cred = secure_cred_matched.group().split('=')[-1]
            secure_cred = secure_cred.split('.')[1]
        return secure_cred

    def get_all_secure_creds(self):
        entities = []
        accounts = ['1301883', '1301884', '1280715', '1301885', '1301887', '2439350', '3111936', '3111938']
        for account in accounts:
            data = {'query': '''{
              actor {
                entitySearch(query: """
                        name LIKE 'SRER' AND 
                        name NOT LIKE 'cognos_directlogin' AND name NOT LIKE 'test' AND name NOT LIKE 'lifecheck' AND name NOT LIKE 'LUI' AND
                        domain = 'SYNTH' AND type = 'MONITOR' AND 
                        accountId = %s AND `tags.monitorStatus` = 'Enabled'""") {
                  results {
                    entities {
                      name
                      account {
                        name
                        id
                      }
                      permalink
                      ... on SyntheticMonitorEntityOutline {
                        monitorId
                      }
                    }
                  }
                }
              }
            }''' % account}
            api_key = self.user.prod_uspscc_hsm_2439350 if account == '2439350' else self.user.concur_shared_1280715
            self.session.headers['Api-Key'] = api_key
            response = self.session.post('https://api.newrelic.com/graphql', data=json.dumps(data))
            entities.extend(response.json()['data']['actor']['entitySearch']['results']['entities'])
        return entities

    def add_accounts_monitors_to_db(self):
        try:
            SyntheticAccounts.objects.all().delete()
            SyntheticMonitors.objects.all().delete()

            entities = self.get_all_secure_creds()
            print(f'Total Synthetic Monitors: {len(entities)}')

            scripts = {}
            for entity in entities:
                self.get_monitor_script(entity['account'], entity['monitorId'], scripts)
                print("\r", f'{len(scripts.keys())} completed', end="", flush=True)
                time.sleep(0.5)

            secure_creds = {}
            for entity in entities:
                script = scripts[entity['monitorId']]
                secure_creds[self.parse_secure_cred(script)] = {'account': entity['account'], 'secure_cred': None}
            for secure_cred in secure_creds:
                self.get_secure_cred(secure_creds[secure_cred]['account'], secure_cred, secure_creds)
            while len(secure_creds.keys()) != len([secure_creds[i]['secure_cred'] for i in secure_creds if secure_creds[i]['secure_cred']]):
                time.sleep(0.1)
            print(f'Total Synthetic Accounts: {len(secure_creds.keys())}')

            for entity in entities:
                script = scripts[entity['monitorId']]
                url = self.parse_url(script)
                email = self.parse_email(script)
                secure_cred = secure_creds[self.parse_secure_cred(script)]['secure_cred']

                account, created = NrAccounts.objects.get_or_create(account_id=entity['account']['id'],
                                    defaults={'name': entity['account']['name']})

                created_at = pytz.utc.localize(parser.parse(secure_cred['createdAt']).replace(tzinfo=None))
                last_updated = pytz.utc.localize(parser.parse(secure_cred['lastUpdated']).replace(tzinfo=None))

                synth_account, created = SyntheticAccounts.objects.update_or_create(name=secure_cred['key'],
                                            defaults={'account': account, 'created_at': created_at, 'last_updated': last_updated})

                datacenter = 'Seattle' if 'SEA' in entity['name'] else 'Paris' if 'PAR' in entity['name'] else 'China' \
                    if 'BEI' in entity['name'] else 'USPSCC' if 'PSCC' or 'CCPS' in entity['name'] else 'US2' \
                    if 'US2' in entity['name'] else 'EU2' if 'EU2' in entity['name'] else None
                if datacenter:
                    datacenter, created = Datacenters.objects.get_or_create(name=datacenter)

                monitor, created = SyntheticMonitors.objects.update_or_create(name=entity['name'], monitor_id=entity['monitorId'],
                                    defaults={'account': account, 'datacenter': datacenter, 'email': email, 'url': url, 'permalink': entity['permalink']})
                if created:
                    synth_account.monitors.add(monitor)
                print(f'{monitor.name[:40]:<40s} {monitor.url[:35]:<35s} {monitor.email[:40]:<40s} {synth_account.name}')
        except Exception as err:
            print(err)
