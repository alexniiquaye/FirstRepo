import os
import sys
import pathlib
import logging
from logging.handlers import RotatingFileHandler


def config(file):
    log_dir = os.path.join(pathlib.Path(file).parent.resolve(), '../logs')
    filename = os.path.join(log_dir, f'{os.path.basename(file).split(".")[0]}.log')
    if not os.path.exists(log_dir):
        os.makedirs(log_dir)
    logging.basicConfig(level=logging.INFO, format="%(asctime)s: %(levelname)s - %(message)s",
                        handlers=[RotatingFileHandler(filename, maxBytes=2*1024*1024, backupCount=3)])
    logging.getLogger().addHandler(logging.StreamHandler(sys.stdout))
    return logging
