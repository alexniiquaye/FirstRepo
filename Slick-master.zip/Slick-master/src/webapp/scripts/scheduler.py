import subprocess
from datetime import datetime
from webapp.models import *
from webapp.scripts import logger
from django.utils import timezone
from django.conf import settings


class Event(object):
    def __init__(self, script, minute=None, hour=None, day=None, month=None, dow=None, user=None, args=()):
        self.minutes = eval(minute) if minute else None
        self.hours = eval(hour) if hour else None
        self.days = eval(day) if day else None
        self.months = eval(month) if month else None
        self.dow = eval(dow) if month else None
        self.script = script
        self.args = args
        self.user = SRER.objects.get(user__username=user) if user else SRER.objects.get(user__username='admin')

    def match_time(self, dt):
        return (
                (dt.minute in self.minutes) and
                (dt.hour in self.hours) and
                (dt.day in self.days) and
                (dt.month in self.months) and
                (dt.weekday() in self.dow)
        )

    @staticmethod
    def save_job(job, status_code, job_output):
        job.end = timezone.now()
        job.duration = (job.end - job.start).microseconds / 1000000
        job.result = 'SUCCESS' if status_code == 0 else 'FAILED'
        job.output = job_output
        job.save()
        return job

    def check_running(self, script):
        pass

    def execute_job(self):
        try:
            script = self.script.split('.')[0]
            job_output = ''
            script_qs = Scripts.objects.get(name=self.script)
            if Jobs.objects.all().filter(script=script_qs, end__isnull=True):
                raise Exception('job already running')

            job = Jobs.objects.create(script=script_qs, executed_by=self.user)
            try:
                _main = 'main()'
                if self.args != 'None':
                    if script in ['thycotic_device42', 'synthetic_accounts_pwd_rotation']:
                        self.args += f', {self.user.user.username}'
                    _main = 'main(' + ', '.join(f"'{arg.strip()}'" for arg in self.args.split(',')) + ')'

                process = subprocess.Popen([f'cd {settings.BASE_DIR.__str__()}; source ../venv/bin/activate; '
                                            f'python manage.py shell --command '
                                            f'"from webapp.scripts import {script}; {script}.{_main}"'],
                                           stdout=subprocess.PIPE, stderr=subprocess.STDOUT, shell=True)
                while True:
                    output = process.stdout.readline()
                    if process.poll() is not None and output == b'':
                        self.save_job(job, process.poll(), job_output)
                        break
                    if output:
                        job_output += f'{output.decode("utf-8").strip()}\n'
                        job.output = job_output
                        job.save()
                        logging.info(f'{output.decode("utf-8").strip()}')
            except Exception as err:
                job_error = ''
                for line in str(err):
                    job_error += f'{line.strip()}\n'
                self.save_job(job, 1, job_error)
                logging.error(err)
        except Exception as err:
            logging.error(err)

    def check(self, dt):
        if self.match_time(dt):
            try:
                logging.info(f'Running {self.script}')
                self.execute_job()
            except Exception as err:
                logging.error(f'{self.script} - {str(err)}')


def main():
    dt = datetime(*datetime.now().timetuple()[:5])
    events_qs = Events.objects.all().filter(enabled=True)
    for item in events_qs:
        event = Event(item.script.name, item.minute, item.hour, item.day, item.months, item.dow)
        event.check(dt)


logging = logger.config(__file__)
if __name__ == '__main__':
    main()
