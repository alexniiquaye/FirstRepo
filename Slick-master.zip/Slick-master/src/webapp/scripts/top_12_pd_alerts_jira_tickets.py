import re
from jira import JIRA
from datetime import datetime, timedelta, timezone

from webapp.models import *
from django.db.models import Count


class PdTopAlerts(object):

    def __init__(self):
        self.start_on = 'Wednesday'
        self.weeks_ago = 4
        self.top_alerts_count = 12
        self.sprint_start = datetime.strptime('2021-01-06', '%Y-%m-%d')
        self.user = SRER.objects.get(user__username='admin')
        self.jira = JIRA('https://jira.concur.com', token_auth=self.user.token)

    def last_sprint_alerts(self):
        top_alerts = []
        month = (datetime.today().replace(day=1) - timedelta(days=1)).strftime('%b%Y').upper()
        epic = self.jira.search_issues(f'project = "SRER" AND issuetype = Epic AND summary ~ "Review, Understand and Create Action Items for top 10 Noisy Alerts for {month}"')
        if not epic:
            return top_alerts
        issues = self.jira.search_issues(f'project = "SRER" AND issuetype = Story AND  "Epic Link" = {epic[-1].key}')
        for issue in issues:
            description = issue.fields.summary.replace('[Alert Tuning] ', '').strip()
            match = re.search('Count:.*?\\n', issue.fields.description)
            if not match:
                continue
            count = int(match.group().strip().split('Count:* ')[-1].split()[0])
            start_date = match.group().strip().split('alerts generated between ')[-1].split()[0]
            end_date = match.group().strip().split('alerts generated between ')[-1].split()[-1]
            top_alerts.append({'description': description, 'count': count, 'start_date': start_date, 'end_date': end_date})
        return top_alerts

    def filter_duplicates(self, top_alerts):
        _top_alerts = self.last_sprint_alerts()

        duplicate = True
        while duplicate:
            duplicate = False
            for i in top_alerts[:self.top_alerts_count][:]:
                for j in _top_alerts:
                    if j['description'] == i['description']:
                        duplicate = True
                        top_alerts.remove(i)

        return top_alerts[:self.top_alerts_count]

    def get_top_alerts(self):
        end_date = datetime.now(timezone.utc).replace(hour=0, minute=0, second=0, microsecond=0)
        while end_date.strftime('%A') != self.start_on:
            end_date = end_date - timedelta(days=1)
        start_date = end_date - timedelta(weeks=self.weeks_ago)

        qs = PagerDuty.objects.all().filter(created_on__range=(start_date, end_date))
        top_alerts = list(qs.values('description').annotate(count=Count('description')).order_by('count').reverse())

        return qs, top_alerts, start_date, end_date

    def create_epic(self):
        date = datetime.today().strftime('%b %Y')
        description = f'''
*Objective:*

 # *Review and Understand the Alerts threshold in reference to past P1s/P2 incidents. * We must have an understanding of how our alerts perform when there is a known P2/P1 outage. Ensure the alerts are tuned in such a way that we can detect an impact in 5-10 minutes before an outage.
 # *Review and Understand why identified alerts are firing even without an outage P2/P1*. Could it be a performance issue at the infra level or application level? How is this alert firing more in one DC than the other?
 # *Create action items for relevant teams to help improve service and minimize Alerts firing due to performance issues* e.g db performance etc.


*Instructions on how to tune Alerts:*
 # Search the alert assigned and update the Violation description of that alert to indicate the ticket raised to tune the specific alert. Be reminded of the correct practice in updating Violation description to not cause impact to observability slo dashboard. [Incident Management Process - SRE CTE Documentation (concur.com).|https://pages.github.concur.com/SRE-CTE-Docs/Docs/incident%20management%20process/#alert-and-dashboard-tuning-process]
 # If the Alert is in ELK, update the Remediation part in Elastic Watcher to include the ticket of the alert tuning.
 # Review occurrence of the alert identified against any P1 or P2 during the time period. If the alert fired during a known incident, then leave the alert threshold the same. If the alert fired falsely meaning, there is no ongoing P2 or P1, then investigate why the Alert has fired and create action items for relevant/owner teams to take action e.g DB, SRE-SE, etc. *[See Objectives of this ticket]*
 # Identify a P1/P2 incident that the service is affected and compare the performance of the alert threshold during that time.
 # Adjust the Alert threshold to ensure we can detect P2/P1 within 10-15 minutes before start of actual outage.
 # Review the similar alert in other DCs and Ensure the threshold is standard. If the trend and threshold should be different for other DC, please document and create an action item for RnD to have our data checked and verified correct.
 # Update the ticket with all the results of the investigation and changes implemented in the alert.  
        '''
        data = {
            "project": {"key": "SRER"},
            "issuetype": {"name": "Epic"},
            "summary": f'[{date}] Review, Understand and Create Action Items for top 10 Noisy Alerts for {date.upper().replace(" ", "")}',
            "description": description,
            "components": [{'name': 'SRE Runtime'}],
            "assignee": {"name": "__Unassigned"},
            "customfield_11004": "[Alert Tuning] Review, Understand and Create Action Items for top 10 Noisy Alerts"
        }
        epic = self.jira.create_issue(**data)
        return epic

    def create_jira_ticket(self, qs, top_alerts, start_date, end_date):
        try:
            epic = self.create_epic()

            for i in top_alerts:
                try:
                    pd_alert = qs.filter(description=i['description']).last().id
                    jira_description = f'''
*Tune Alert:* [{i['description']}|https://sap.pagerduty.com/incidents/{pd_alert}]

*Count:* {i['count']} alerts generated between {start_date.strftime('%Y-%m-%d')} and {end_date.strftime('%Y-%m-%d')}

*Objective:*
 # *Review and Understand the Alerts threshold in reference to past P1s/P2 incidents.* We must have an understanding of how our alerts perform when there is a known P2/P1 outage. Ensure the alerts are tuned in such a way that we can detect an impact in 5-10 minutes before an outage.
 # *Review and Understand why identified alerts are firing even without an outage P2/P1*. Could it be a performance issue at the infra level or application level? How is this alert firing more in one DC than the other? 
 # *Create action items for relevant teams to help improve service and minimize Alerts firing due to performance issues* e.g db performance etc. 

*Instructions on how to tune Alerts:* 
 # Search the alert assigned and update the Violation description of that alert to indicate the ticket raised to tune the specific alert. Be reminded of the correct practice in updating Violation description to not cause impact to observability slo dashboard. [Incident Management Process - SRE CTE Documentation (concur.com).|https://pages.github.concur.com/SRE-CTE-Docs/Docs/incident%20management%20process/#alert-and-dashboard-tuning-process]
 # If the Alert is in ELK, update the Remediation part in Elastic Watcher to include the ticket of the alert tuning. 
 # Review occurrence of the alert identified against any P1 or P2 during the time period. If the alert fired during a known incident, then leave the alert threshold the same. If the alert fired falsely meaning, there is no ongoing P2 or P1, then investigate why the Alert has fired and create action items for relevant/owner teams to take action e.g DB, SRE-SE, etc. *[See Objectives of this ticket]*
 # Identify a P1/P2 incident that the service is affected and compare the performance of the alert threshold during that time.
 # Adjust the Alert threshold to ensure we can detect P2/P1 within 10-15 minutes before start of actual outage. 
 # Review the similar alert in other DCs and Ensure the threshold is standard. If the trend and threshold should be different for other DC, please document and create an action item for RnD to have our data checked and verified correct. 
 # Update the ticket with all the results of the investigation and changes implemented in the alert.
                '''
                    data = {
                        "project": {"key": "SRER"},
                        "issuetype": {"name": "Story"},
                        "summary": f'[Alert Tuning] {i["description"]}',
                        "description": jira_description,
                        "components": [{'name': 'SRE Runtime'}],
                        "assignee": {"name": "__Unassigned"},
                        "customfield_11003": epic.key
                    }
                    issue = self.jira.create_issue(**data)
                    print(issue.key, i["description"])
                except Exception as err:
                    raise Exception(err, i)
        except Exception as err:
            return err

    def first_sprint_of_month(self):
        today = datetime.today()
        if today.strftime('%A') == self.start_on:
            while self.sprint_start < today:
                if self.sprint_start.date() == today.date() and today.strftime('%b') != (today - timedelta(weeks=2)).strftime('%b'):
                    return True
                self.sprint_start += timedelta(weeks=2)
            return False
        return False

    def report(self):
        _top_alerts = self.last_sprint_alerts()
        for alert in _top_alerts:
            try:
                end_date = datetime.now(timezone.utc).replace(hour=0, minute=0, second=0, microsecond=0)
                start_date = end_date - timedelta(weeks=self.weeks_ago)
                new_count = PagerDuty.objects.all().filter(description=alert['description'], created_on__range=(start_date, end_date)).count()
                print(alert['description'], alert['count'], new_count)
            except Exception as err:
                print(err, alert)

    def main(self):
        if self.first_sprint_of_month():
            qs, top_alerts, start_date, end_date = self.get_top_alerts()
            top_alerts = self.filter_duplicates(top_alerts)
            self.create_jira_ticket(qs, top_alerts, start_date, end_date)
