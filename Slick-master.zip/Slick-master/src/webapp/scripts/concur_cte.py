import re
import json
import requests


class ConcurCteAPI(object):

    def __init__(self, base_url, username, password):
        self.base_url = base_url
        self.username = username
        self.password = password
        self.session = requests.Session()
        self.session.headers.update({
            'Content-Type': 'application/json',
            'Accept': '*/*',
            'Accept-Language': 'en-us',
            'Accept-Encoding': 'gzip, deflate, br',
            'Cache-Control': 'no-cache',
            'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/14.1.1 Safari/605.1.15',
            'Connection': 'keep-alive',
            'x-csrf-token': 'MbmfCO8CGduxtjkwL1R5ho6TbrIScBSCKVcH2wLHYuKUUVNMQM8oLuHBc7KvR/6rL7PymoVqgWCeCB5pJQ=='
        })

    def login(self):
        try:
            response = self.session.get(self.base_url)
            correlation_id = re.search('correlationId\":\".+?\"', response.text).group().split(':')[-1].replace('"', '').strip()
            relay_state = re.search('relayState\":\".+?\"', response.text).group().split(':')[-1].replace('"', '').strip()
            data = {
                "attempt": 0,
                "rememberUserName": False,
                "userName": self.username,
                "password": self.password,
                "relayState": relay_state
            }
            params = {'correlationid': correlation_id}
            response = self.session.post(f'{self.base_url}/nui/signin/nui-auth/api/authorize', params=params, data=json.dumps(data))
            code = response.json()['code']

            data = {
              'lang': 'en-us',
              'no307': 'Y',
              'code': code,
              'redirect_uri': f'{self.base_url}/nui/signin/setsession'
            }
            params['code'] = code
            response = self.session.post(f'{self.base_url}/nui/signin/nui-auth/api/setsession', params=params, data=json.dumps(data))
            ottcode = response.json()['ottcode']

            data['ottcode'] = ottcode
            params['forsession'] = 1
            self.session.post(f'{self.base_url}/nui/signin/nui-auth/api/setsession', params=params, data=json.dumps(data))
            return self.session.get(f'{self.base_url}/ui/shared/proxylookup/List?searchPattern=*').json()
        except Exception as err:
            return err

    def update_password(self, new_password):
        try:
            logged_in = self.login()
            if isinstance(logged_in, Exception):
                raise Exception(logged_in)

            response = self.session.get(f'{self.base_url}/profile/ProfileUserChangePassword.asp')
            back_url = re.search('name=backurl value=\".*\"', response.text).group().split('=')[-1].replace('"', '').strip()
            data = {
              'backurl': back_url,
              'UpdateStatus': 'Y',
              'txtOldPassword': self.password,
              'txtNewPassword1': new_password,
              'txtNewPassword2': new_password
            }
            self.session.headers.update({
                'content-type': 'application/x-www-form-urlencoded',
            })
            response = self.session.post(f'{self.base_url}/Profile/profileUserChangePassword_sub.asp', data=data)
            self.logout()
            if re.search('Your password has been changed', response.text):
                return True
            raise Exception(response.reason)
        except Exception as err:
            return err

    def logout(self):
        self.session.get(f'{self.base_url}/nui/signin/nui-auth/api/signout')
        self.session.cookies.clear()
