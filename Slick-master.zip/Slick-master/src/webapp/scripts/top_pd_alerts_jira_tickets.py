import pytz
import json
from jira import JIRA
from datetime import datetime, timedelta

from webapp.scripts import logger
from webapp.models import *
from django.db.models import Count
from webapp.scripts.pagerduty_analysis import parse_dc


class PdTopAlerts(object):

    def __init__(self):
        self.top_alerts_count = 3
        self.user = SRER.objects.get(user__username='admin')
        self.jira = JIRA('https://jira.concur.com', token_auth=self.user.jira_token)
        self.epic = None
        self.channel_id = 'C02HK75HWBH'  # srer-top-alerts
        self.headers = {
            'Content-type': 'application/json',
            'Authorization': f'Bearer {self.user.slack_api_token}'
        }

    def create_epic(self):
        date = datetime.today().strftime('%b %Y')
        description = f'''
*Objective:*

 # *Review and Understand the Alerts threshold in reference to past P1s/P2 incidents. * We must have an understanding of how our alerts perform when there is a known P2/P1 outage. Ensure the alerts are tuned in such a way that we can detect an impact in 5-10 minutes before an outage.
 # *Review and Understand why identified alerts are firing even without an outage P2/P1*. Could it be a performance issue at the infra level or application level? How is this alert firing more in one DC than the other?
 # *Create action items for relevant teams to help improve service and minimize Alerts firing due to performance issues* e.g db performance etc.


*Instructions on how to tune Alerts:*
 # Search the alert assigned and update the Violation description of that alert to indicate the ticket raised to tune the specific alert. Be reminded of the correct practice in updating Violation description to not cause impact to observability slo dashboard. [Incident Management Process - SRE CTE Documentation (concur.com).|https://pages.github.concur.com/SRE-CTE-Docs/Docs/incident%20management%20process/#alert-and-dashboard-tuning-process]
 # If the Alert is in ELK, update the Remediation part in Elastic Watcher to include the ticket of the alert tuning.
 # Review occurrence of the alert identified against any P1 or P2 during the time period. If the alert fired during a known incident, then leave the alert threshold the same. If the alert fired falsely meaning, there is no ongoing P2 or P1, then investigate why the Alert has fired and create action items for relevant/owner teams to take action e.g DB, SRE-SE, etc. *[See Objectives of this ticket]*
 # Identify a P1/P2 incident that the service is affected and compare the performance of the alert threshold during that time.
 # Adjust the Alert threshold to ensure we can detect P2/P1 within 10-15 minutes before start of actual outage.
 # Review the similar alert in other DCs and Ensure the threshold is standard. If the trend and threshold should be different for other DC, please document and create an action item for RnD to have our data checked and verified correct.
 # Update the ticket with all the results of the investigation and changes implemented in the alert.  
        '''
        data = {
            "project": {"key": "SRER"},
            "issuetype": {"name": "Epic"},
            "summary": f'[{date}] Review, Understand and Create Action Items for top Noisy Alerts for {date.upper().replace(" ", "")}',
            "description": description,
            "components": [{'name': 'SRE Runtime'}],
            "assignee": {"name": "__Unassigned"},
            "customfield_11004": "[Alert Tuning] Review, Understand and Create Action Items for top Noisy Alerts"
        }
        epic = self.jira.create_issue(**data)
        return epic

    def previous_alerts(self):
        date = datetime.today().strftime('%b %Y')
        epic = self.jira.search_issues(f'project = "SRER" AND issuetype = Epic AND summary ~ "Review, Understand and Create Action Items for top Noisy Alerts for {date.upper().replace(" ", "")}"')
        if epic:
            self.epic = epic[0].key
        else:
            self.epic = self.create_epic().key
        logging.info(f'Epic: {self.epic}')

        offset, limit, issues, alerts = 0, 100, [], []
        while True:
            result = self.jira.search_issues(f'project = "SRER" AND issuetype = Task AND "Epic Link" = {self.epic}', offset, limit)
            issues.extend(result)
            offset += limit
            if len(result) == 0:
                break

        for issue in issues:
            if '[Alert Tuning] ' in issue.fields.summary:
                description = issue.fields.summary.replace('[Alert Tuning] ', '').strip()
                alerts.append(description)
        return alerts

    def filter_duplicates(self, top_alerts):
        _top_alerts = self.previous_alerts()

        duplicate = True
        while duplicate:
            duplicate = False
            for i in top_alerts[:self.top_alerts_count][:]:
                for j in _top_alerts:
                    if j == i['description']:
                        duplicate = True
                        try:
                            top_alerts.remove(i)
                        except ValueError:
                            logging.warning(i)
                            pass

        return top_alerts[:self.top_alerts_count]

    def filter_p1(self, top_alerts):
        issues = self.jira.search_issues('project = "OPI" AND issuetype = Incident AND priority = "1 - Very High" AND created > startOfDay(-0d)')
        for issue in issues:
            datacenters = [i.value for i in issue.fields.customfield_10836]
            for i in top_alerts:
                dc = parse_dc(i['description']).lower()
                dc = 'EU2 (EMEA COM 2)' if dc == 'eu2' else 'US2 (US COM 2)' if dc == 'us2' else \
                    'US Gov West' if dc == 'uspscc' else 'China' if dc == 'bei' else 'Paris - Com' if dc == 'par' else 'Lynnwood - Com'
                if dc in datacenters:
                    top_alerts.remove(i)
        return top_alerts

    def get_top_alerts(self):
        qs = PagerDuty.objects.all().filter(created_on__date__gte=(datetime.utcnow() - timedelta(hours=8)),
                                            created_on__date__lte=datetime.now())
        top_alerts = list(qs.values('description').annotate(count=Count('description')).filter(count__gte=5).order_by('count').reverse())
        return qs, top_alerts

    def create_jira_ticket(self, qs, top_alerts):
        results = {}
        try:
            for i in top_alerts:
                try:
                    pd_alert = qs.filter(description=i['description']).last().id
                    jira_description = f'''
*Tune Alert:* [{i['description']}|https://sap.pagerduty.com/incidents/{pd_alert}]

*Count:* {i['count']} alerts generated

*Objective:*
 # *Review and Understand the Alerts threshold in reference to past P1s/P2 incidents.* We must have an understanding of how our alerts perform when there is a known P2/P1 outage. Ensure the alerts are tuned in such a way that we can detect an impact in 5-10 minutes before an outage.
 # *Review and Understand why identified alerts are firing even without an outage P2/P1*. Could it be a performance issue at the infra level or application level? How is this alert firing more in one DC than the other? 
 # *Create action items for relevant teams to help improve service and minimize Alerts firing due to performance issues* e.g db performance etc. 

*Instructions on how to tune Alerts:* 
 # Search the alert assigned and update the Violation description of that alert to indicate the ticket raised to tune the specific alert. Be reminded of the correct practice in updating Violation description to not cause impact to observability slo dashboard. [Incident Management Process - SRE CTE Documentation (concur.com).|https://pages.github.concur.com/SRE-CTE-Docs/Docs/incident%20management%20process/#alert-and-dashboard-tuning-process]
 # If the Alert is in ELK, update the Remediation part in Elastic Watcher to include the ticket of the alert tuning. 
 # Review occurrence of the alert identified against any P1 or P2 during the time period. If the alert fired during a known incident, then leave the alert threshold the same. If the alert fired falsely meaning, there is no ongoing P2 or P1, then investigate why the Alert has fired and create action items for relevant/owner teams to take action e.g DB, SRE-SE, etc. *[See Objectives of this ticket]*
 # Identify a P1/P2 incident that the service is affected and compare the performance of the alert threshold during that time.
 # Adjust the Alert threshold to ensure we can detect P2/P1 within 10-15 minutes before start of actual outage. 
 # Review the similar alert in other DCs and Ensure the threshold is standard. If the trend and threshold should be different for other DC, please document and create an action item for RnD to have our data checked and verified correct. 
 # Update the ticket with all the results of the investigation and changes implemented in the alert.
                '''
                    data = {
                        "project": {"key": "SRER"},
                        "issuetype": {"name": "Task"},
                        "summary": f'[Alert Tuning] {i["description"]}',
                        "description": jira_description,
                        "components": [{'name': 'SRE Runtime'}],
                        "assignee": {"name": "__Unassigned"},
                        "customfield_11003": self.epic
                    }
                    issue = self.jira.create_issue(**data)
                    logging.info(f'{issue.key} - {i["description"]}')
                    results[issue.key] = i['description']
                except Exception as err:
                    raise Exception(err, i)
            return results
        except Exception as err:
            logging.error(str(err))
            return err

    def slack_message(self, tickets):
        print(tickets)
        messages = []
        for key, value in tickets.items():
            jira_url = f'https://jira.concur.com/browse/{key}'
            messages.append(f'• <{jira_url}|{value.replace(" ", "-")[:70]}...>')
        data = {
            'channel': self.channel_id,
            'blocks': [
                {
                    "type": "section",
                    "text": {
                        "type": "mrkdwn",
                        "text": '\n'.join(messages)
                    }
                }
            ]
        }
        if messages:
            response = requests.post('https://slack.com/api/chat.postMessage', headers=self.headers, data=json.dumps(data))
            return response

    @staticmethod
    def shift_change():
        cst_now = pytz.utc.localize(datetime.utcnow()).astimezone(pytz.timezone('America/Chicago'))
        if cst_now.minute != 0:
            return False
        if cst_now.hour in [1, 9, 17]:
            return True
        return False


def main():
    try:
        pd = PdTopAlerts()
        if pd.shift_change():
            qs, top_alerts = pd.get_top_alerts()
            top_alerts = pd.filter_p1(top_alerts)
            top_alerts = pd.filter_duplicates(top_alerts)
            tickets = pd.create_jira_ticket(qs, top_alerts)
            pd.slack_message(tickets)
        else:
            logging.info('skipped')
    except Exception as err:
        logging.error(str(err))


logging = logger.config(__file__)
if __name__ == '__main__':
    main()
