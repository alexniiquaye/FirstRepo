import sys
import json
import time
import requests
from datetime import datetime
from django.db import IntegrityError
from webapp.models import *
from webapp.scripts import pagerduty_analysis
from webapp.scripts import multitasking
from webapp.scripts import logger


class PagerDutyData(object):

    def __init__(self):
        self.services = ['PWOPSSU', 'PSC1RD4', 'PZKAT4H', 'PN85W7D', 'PDWLTH7', 'PP2DR0E', 'P9Y06EO', 'P0LCA3Q', 'PQ7O7TB',
                    'PDV9X60', 'PTGZ861', 'PS68G9Y', 'P8Y9BQQ', 'PVZH9QS', 'PS0W8B2', 'PZ95N2F', 'PKDIYXD', 'PCITNF5',
                    'POR87LC', 'PXMB8LG', 'PBYM9B6', 'PXW3MGB', 'PF8NNQW', 'P0WO5HZ', 'PJSX64G', 'P45Z6WM', 'PZILWTA',
                    'P7EK79P', 'PFG95ST', 'POFXWDT', 'P869W13', 'PSRIXSG', 'PUN5106', 'PW16Y56', 'P4WLVOD', 'PC22P01',
                    'PR759IL', 'PYSEONB', 'P6LW8U8', 'PUGTNYO', 'PNXH96Y', 'P17GOJB', 'PK42P6I', 'P4H4PZ1', 'PH4XXIQ',
                    'P8TSQOR', 'PGUEOUV']
        self.session = requests.Session()
        self.user = SRER.objects.get(user__username='admin')
        self.session.headers = {
            'content-type': 'application/json',
            'authorization': f'Token token={self.user.pagerduty_token}'
        }
        # self.session.headers = {
        #     'Content-Type': 'application/json',
        #     'Accept': 'application/vnd.pagerduty+json;version=2'
        # }
        # self.session.cookies.update({
        #     '_pagerduty_session': 'BAh7CkkiD3Nlc3Npb25faWQGOgZFVEkiJWU2YjY0NzE2ODY3ODA3OWRkMTQ4YmI3YmQ0MzkxNmY2BjsAVEkiGXdhcmRlbi51c2VyLnVzZXIua2V5BjsAVFsHWwZpA9FBoEkiIiQyYSQxMyRldWlKdVN2VEZJeVdsRUNEQ0l0VmwuBjsAVEkiEnBkX3Nlc3Npb25faWQGOwBUSSIlMjYyNWNjOWE0ZDg1ZjE5MTNkZDMxMzMzZWFkZWY2ZmQGOwBGSSIedXNlci5zYW1sLmxvZ2luX3RpbWVzdGFtcAY7AFRsKwdqTblgSSIQX2NzcmZfdG9rZW4GOwBGSSIxamRYNlJnSDhtNUpsTHQ3NWJYWWVPVTZpTVhsTS9yMkFPQVpJMnVjbXd2OD0GOwBG--e5b5e25311efcb8a82fea97f85bf0766785e4781'
        # })
        self.base_url = 'https://sap.pagerduty.com'
        self.qs = PagerDuty.objects.all()
        self.since = self.qs.order_by('created_on').last().created_on
        self.until = datetime.utcnow()

    def fetch_pagerduty_data(self):
        offset, limit, more, entries = 0, 100, True, []
        try:
            while more:
                data = {
                    "since": self.since.strftime('%Y-%m-%dT%H:%M:%S.00Z'),
                    "until": self.until.strftime('%Y-%m-%dT%H:%M:%S.00Z'),
                    "limit": limit,
                    "offset": offset,
                    "time_zone": "UTC",
                    "sort_by_direction": "asc",
                    "filters": {"service_ids": self.services, "resolved":True},
                }
                response = self.session.post(f'{self.base_url}/api/v1/reports/raw/incidents', data=json.dumps(data))
                if response.reason != 'OK':
                    raise Exception(response.reason)
                entries.extend(response.json()['data'])
                offset += limit
                more = response.json()['more']
                time.sleep(0.2)
            return entries
        except Exception as error:
            return error

    @multitasking.task
    def _fetch_log_entries_data(self, offset, entries):
        start = time.time()
        while True:
            params = (
                ('since', self.since.strftime('%Y-%m-%dT%H:%M:%S.00Z')),
                ('until', self.until.strftime('%Y-%m-%dT%H:%M:%S.00Z')),
                ('limit', 100),
                ('offset', offset),
                ('time_zone', 'UTC'),
                ('sort_by_direction', 'asc'),
                ('statuses[]', ['resolved']),
                ('service_ids[]', self.services),
                ('include[]', ['first_trigger_log_entries']),
                ('total', 'true')
            )
            response = self.session.get(f'{self.base_url}/api/v1/incidents', params=params)
            if response.reason == 'OK':
                entries.extend(response.json()['incidents'])
                break
            elif (time.time() - start) > 10:
                break
            time.sleep(1)

    def fetch_log_entries_data(self, pd_entries):
        log_entries = []
        try:
            for i in range(int((len(pd_entries) / 100)) + 2):
                offset = i * 100
                self._fetch_log_entries_data(offset, log_entries)
                time.sleep(0.2)

            start = time.time()
            while len(log_entries) < len(pd_entries) and (time.time() - start) < 300:
                time.sleep(0.2)
            return log_entries
        except Exception as err:
            return err

    @staticmethod
    def add_pagerduty_data(pd_entries):
        for item in pd_entries:
            try:
                kwargs = {}
                for field in PagerDuty._meta.fields:
                    kwargs[field.name] = item[field.name]
                PagerDuty.objects.create(**kwargs)
            except IntegrityError as e:
                pass
            except Exception as e:
                logging.error(str(e))

    @staticmethod
    def add_incident_data(log_entries):
        for item in log_entries:
            try:
                qs = PagerDuty.objects.get(incident_number=item['incident_number'])
                incident_details = item['first_trigger_log_entry']['channel']['details']
                if qs.service_name == 'CNQR-SM-CTE [Watcher]':
                    if incident_details and 'alert_id' in incident_details:
                        Incidents.objects.filter(pagerduty_id=qs).update(watcher_alert_id=incident_details['alert_id'])
                elif qs.service_name == 'CNQR-SM-CTE [New Relic]' or qs.service_name == 'CNQR-SM-CTE':
                    if type(incident_details) is dict and incident_details.keys() >= {'condition_name', 'policy_name', 'account_name', 'targets'}:
                        condition_name = incident_details['condition_name']
                        policy_name = incident_details['policy_name']
                        account_name = incident_details['account_name']
                        account_id = incident_details['account_id']
                        incident_id = incident_details['incident_id']
                        targets = incident_details['targets']
                        Incidents.objects.filter(pagerduty_id=qs).update(
                            nr_account_name=account_name, nr_account_id=account_id,
                            nr_condition_name=condition_name, nr_incident_id=incident_id,
                            nr_policy_name=policy_name, nr_targets=targets
                        )
                    else:
                        alert_type = item['first_trigger_log_entry']['channel']['type']
                        if alert_type == 'email':
                            email_body = item['first_trigger_log_entry']['channel']['body']
                            Incidents.objects.filter(pagerduty_id=qs).update(email_body=email_body)
            except IntegrityError as e:
                pass
            except Exception as e:
                logging.warning(f'{item["id"]} {item["description"]} {str(e)}')
            except PagerDuty.DoesNotExist:
                logging.warning(f'DoesNotExist {item["id"]}')

    @staticmethod
    def parse_pagerduty_data(pd_entries):
        for item in pd_entries:
            try:
                query = Incidents.objects.filter(pagerduty_id__id=item['id'])
                if not query:
                    continue
                kwargs = pagerduty_analysis.parse_manager(query[0].pagerduty_id)
                query.update(**kwargs)
            except Exception as e:
                logging.error(str(e))


def main():
    pd = PagerDutyData()
    logging.info(f'Downloading PagerDuty data since: {pd.since.strftime("%c")}')
    pd_entries = pd.fetch_pagerduty_data()
    if isinstance(pd_entries, Exception):
        logging.error(pd_entries)
        sys.exit(1)

    log_entries = pd.fetch_log_entries_data(pd_entries)
    if isinstance(log_entries, Exception):
        logging.error(pd_entries)
        sys.exit(1)

    pd.add_pagerduty_data(pd_entries)
    pd.parse_pagerduty_data(pd_entries)
    pd.add_incident_data(log_entries)
    logging.info(f'Total number of new incidents added: {len(pd_entries)}')


logging = logger.config(__file__)
if __name__ == '__main__':
    main()
