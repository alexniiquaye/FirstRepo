# Change log
#   o 2021-09-30:
#     o Added more role types for imaging, emt, auitrv, auiexp, sessioninit, actint
#     o In parse description, made one big if then else

import re
from webapp.models import *

rms = {
    "abwex": {
        "product": "cte_common"
    },
    "actint": {
        "product": "spend"
    },
    "ams": {
        "product": "spend"
    },
    "apigwf": {
        "product": "core"
    },
    "appmgt": {
        "product": "shared_platform"
    },
    "aui": {
        "product": "shared"
    },
    "auiexp": {
        "product": "shared"
    },
    "auitrv": {
        "product": "shared"
    },
    "bspool": {
        "product": "travel"
    },
    "cbatw": {
        "product": "spend"
    },
    "cappw": {
        "product": "spend"
    },
    "cbatw": {
        "product": "spend"
    },
    "cb4c": {
        "product": "integration"
    },
    "ccapi": {
        "product": "spend"
    },
    "ces": {
        "product": "spend"
    },
    "classicpay": {
        "product": "spend"
    },
    "clq": {
        "product": "travel"
    },
    "cognos": {
        "product": "analytics"
    },
    "cogwb": {
        "product": "analytics"
    },
    "cogwi": {
        "product": "analytics"
    },
    "couchbase": {
        "product": "integration"
    },
    "css": {
        "product": "shared"
    },
    "email2db": {
        "product": "spend"
    },
    "emt": {
        "product": "spend"
    },
    "ers": {
        "product": "spend"
    },
    "expense": {
        "product": "spend"
    },
    "eui": {
        "product": "spend"
    },
    "euiasp": {
        "product": "spend"
    },
    "euidef": {
        "product": "spend"
    },
    "expnui": {
        "product": "spend"
    },
    "dis": {
        "product": "shared"
    },
    "f5": {
        "product": "shared"
    },
    "fis": {
        "product": "spend"
    },
    "gds": {
        "product": "travel"
    },
    "gls": {
        "product": "core"
    },
    "gtin": {
        "product": "travel"
    },
    "gui": {
        "product": "shared"
    },
    "guiasp": {
        "product": "shared"
    },
    "gwspro": {
        "product": "travel"
    },
    "hmc": {
        "product": "spend"
    },
    "hrd": {
        "product": "core_services"
    },
    "imaging": {
        "product": "imaging"
    },
    "imgel": {
        "product": "imaging"
    },
    "imgws": {
        "product": "imaging"
    },
    "imgiws": {
        "product": "imaging"
    },
    "img3ws": {
        "product": "imaging"
    },
    "img4ws": {
        "product": "imaging"
    },
    "invoice": {
        "product": "spend"
    },
    "invcap": {
        "product": "spend"
    },
    "invsrv": {
        "product": "spend"
    },
    "itin": {
        "product": "travel"
    },
    "itinjb": {
        "product": "travel"
    },
    "iui": {
        "product": "spend"
    },
    "iuiasp": {
        "product": "spend"
    },
    "list": {
        "product": "spend"
    },
    "lui": {
        "product": "shared"
    },
    "mui": {
        "product": "shared"
    },
    "nui": {
        "product": "spend"
    },
    "nuiset": {
        "product": "shared"
    },
    "nuisgn": {
        "product": "core_services"
    },
    "oauth2": {
        "product": "core_services"
    },
    "ocrotk": {
        "product": "cte_common"
    },
    "oui": {
        "product": "concur_open"
    },
    "password": {
        "product": "shared_platform"
    },
    "paycl": {
        "product": "pay"
    },
    "profile": {
        "product": "shared_platform"
    },
    "prs": {
        "product": "shared_platform"
    },
    "pws": {
        "product": "spend"
    },
    "raas": {
        "product": "spend"
    },
    "report": {
        "product": "spend"
    },
    "saml": {
        "product": "shared_platform"
    },
    "sessioninit": {
        "product": "shared_platform"
    },
    "srer": {
        "product": "monitoring"
    },
    "tap": {
        "product": "travel"
    },
    "tmt": {
        "product": "travel"
    },
    "tui": {
        "product": "travel"
    },
    "tvlcnf": {
        "product": "travel"
    },
    "tws": {
        "product": "travel"
    },
    "ui": {
        "product": "travel"
    },
    "bssf": {
        "product": "travel"
    },
    "r2rs": {
        "product": "travel"
    },
    "qes": {
        "product": "expense"
    },
    "paymgr": {
        "product": "expense"
    },
    "expcfg": {
        "product": "expense"
    },
    "t2sync": {
        "product": "travel"
    },
    "srer_sea_auitrv": {
        "product": "travel"
    },
    "srer_par_guiasp": {
        "product": "shared"
    }
}

regex_dict = {
    'srer_outtask_error_warning': {
        'regex': re.compile(r'\[watcher\] (?P<trans>SRER_Outtask_Errors_(WARNING|CRITICAL) - Monitor Outtask Errors)', re.IGNORECASE),
        'fields': ['trans']
    },
    'apigateway_client_cert_expired': {
        'regex': re.compile('\\[watcher\\] (?P<trans>.*-apigateway-client-cert-expired)', re.IGNORECASE),
        'fields': ['trans']
    },
    'slos_obsfw': {
        'regex': re.compile('(?P<dc>sea|par|bei|uspscc|eu2|us2)(-pr|-pr1|-prod|-parpr1|-seapr1)*-(?P<tier>\\w+)-(?P<sli_trans>\\w+)-slos-obsfw \\((?P<trans>.*-slos-obsfw)-(?P<alert_type>(avail|rpm|error|rt))\\)', re.IGNORECASE),
        'fields': ['dc', 'tier', 'sli_trans', 'trans', 'alert_type']
    },
    'sli_no_product': {
        'regex': re.compile('(?P<dc>sea|par|bei|uspscc|eu2|us2)-(?P<tier>profile|invoice|appmgt|mui)-(?P<sli_trans>[a-z0-9_/]+)(-web)*-(?P<alert_type>avail|availability|error|rpm|rt) \\((?P<trans>.*)\\)', re.IGNORECASE),
        'fields': ['dc', 'tier', 'sli_trans', 'alert_type', 'trans']
    },
    'sli': {
        'regex': re.compile('(?P<dc>sea|par|bei|uspscc|eu2|us2)-(?P<product>\\w+)-(?P<tier>\\w+)-(?P<sli_trans>[a-z0-9_/]+)(-web)*-(?P<alert_type>avail|availability|error|rpm|rt) \\((?P<trans>.*)\\)', re.IGNORECASE),
        'fields': ['dc', 'product', 'tier', 'sli_trans', 'alert_type', 'trans']
    },
    'srer_tier_slo_alerts': {
        'regex': re.compile('(?P<tier>\\w+)-(USPSCC-)*SLO-alerts \\((?P<trans>.*-SLO)-(?P<alert_type>(avail|rpm|error|rt)).*\\)', re.IGNORECASE),
        'fields': ['tier', 'trans', 'alert_type']
    },
    'srer_uspscc_eui_tier_slo_alerts': {
        'regex': re.compile('USPSCC-PROD-(?P<tier>\\w+)-SLO \\((?P<trans>.*)-(?P<alert_type>(avail|rpm|error|rt))\\)', re.IGNORECASE),
        'fields': ['tier', 'trans', 'alert_type']
    },
    'srer_cognos_synthetic': {
        'regex': re.compile('SRER_.*(?P<tier>COGNOS).*_(?P<alert_type>Synthetic)s \\((?P<trans>.*)\\)', re.IGNORECASE),
        'fields': ['tier', 'alert_type', 'trans']
    },
    'srer_web_login_synthetic_eu2': {
        'regex': re.compile('SRER_Web_EU2_Login \\((?P<trans>.*)\\)', re.IGNORECASE),
        'fields': ['trans']
    },
    'srer_expense_synthetic_eu2_web': {
        'regex': re.compile('SRER_(REQUEST|EXPENSE|IMPL|INVOICE)_EU2_Web \\((?P<trans>.*)\\)', re.IGNORECASE),
        'fields': ['trans']
    },
    'srer_travel_synthetic_eu2_web': {
        'regex': re.compile('SRER_Travel_EU2_Web \\((?P<trans>.*)\\)', re.IGNORECASE),
        'fields': ['trans']
    },
    'srer_expense_synthetic': {
        'regex': re.compile('SRER_(REQUEST|EXPENSE|IMPL|INVOICE).*_(?P<alert_type>Synthetic)s \\((?P<trans>.*)\\)', re.IGNORECASE),
        'fields': ['alert_type', 'trans']
    },
    'srer_travel_synthetic': {
        'regex': re.compile('SRER_TRAVEL_.*_(?P<alert_type>Synthetic)s \\((?P<trans>.*)\\)', re.IGNORECASE),
        'fields': ['alert_type', 'trans']
    },
    'srer_login_synthetic': {
        'regex': re.compile('SRER_LOGIN_(?P<alert_type>Synthetic)s \\((?P<trans>.*)\\)', re.IGNORECASE),
        'fields': ['alert_type', 'trans']
    },
    'aui_policy': {
        'regex': re.compile('\\[SRER\\] AUI Policy \\((?P<trans>.*)\\)', re.IGNORECASE),
        'fields': ['trans']
    },
    'auitrv': {
        'regex': re.compile('\\[SRER\\]-(?P<tier>AUITRV) \\((?P<trans>.*)\\)', re.IGNORECASE),
        'fields': ['tier', 'trans']
    },
    'auitrv2': {
        'regex': re.compile('(?P<tier>AUITRV) \\((?P<trans>.*)\\)', re.IGNORECASE),
        'fields': ['tier', 'trans']
    },
    'auiexp': {
        'regex': re.compile('.*-(?P<tier>AUIEXP) \\((?P<trans>.*)\\)', re.IGNORECASE),
        'fields': ['tier', 'trans']
    },
    'invoice_policy': {
        'regex': re.compile('\\[SRER\\] Invoice Policy \\((?P<trans>.*)\\)', re.IGNORECASE),
        'fields': ['trans']
    },
    'tier_alerts': {
        'regex': re.compile('\\[SRER\\] (?P<tier>\\w+) Tier (?P<trans>.*)', re.IGNORECASE),
        'fields': ['tier', 'trans']
    },
    'cesclassic': {
        'regex': re.compile('SM-Expense_(?P<dc>sea|par|bei|eu2|us2)_(?P<trans>CESClassic_Errors_WARN)', re.IGNORECASE),
        'fields': ['dc', 'trans']
    },
    'synthetic_policy_expense': {
        'regex': re.compile('\\[SRER\\] Synthetics Policy \\((?P<trans>.*)\\)', re.IGNORECASE),
        'fields': ['trans']
    },
    'travel_baselines': {
        'regex': re.compile('\\[*SRER\\]*[ _]Travel[ _]Baselines \\((?P<dc>sea|par)-PR1-(?P<tier>\\w+) (?P<trans>violated.*)\\)', re.IGNORECASE),
        'fields': ['dc', 'tier', 'trans']
    },
    'sitedown': {
        'regex': re.compile('\\[watcher\\] (?P<dc>sea|par|eu2|us2)-SRER-1418.*', re.IGNORECASE),
        'fields': ['dc']
    },
    'expense_uspscc_drop_watcher': {
        'regex': re.compile('\\[watcher\\] SM-(?P<product>Expense)_(?P<dc>uspscc)_(?P<trans>Metrics_Drop_Too_Fast_CRITICAL)', re.IGNORECASE),
        'fields': ['product', 'dc', 'trans']
    },
    'expense_uspscc_submit_reports_latency': {
        'regex': re.compile('\\[watcher\\] SM-(?P<product>Expense)_(?P<dc>uspscc)_(?P<trans>SubmitReports-Latency_WARN)', re.IGNORECASE),
        'fields': ['product', 'dc', 'trans']
    },
    'outtask_error': {
        'regex': re.compile('\\[watcher\\] SM_CTE_(?P<dc>sea|par|eu2|us2)_(Outtask|Travel)_Errors.*', re.IGNORECASE),
        'fields': ['dc']
    },
    'analytics_nr': {
        'regex': re.compile(r'SRER_(?P<dc>SEA|PAR|BEI)PR1_(?P<tier>Cognos)_.*Lifecheck \((?P<trans>.*)\)', re.IGNORECASE),
        'fields': ['dc','tier','trans']
    },
    'outtask_deadlock': {
        'regex': re.compile('\\[watcher\\] SM_CTE_(?P<dc>sea|par|eu2|us2)_Outtask_(timeout-)*deadlock.*', re.IGNORECASE),
        'fields': ['dc']
    },
    'analytics': {
        'regex': re.compile('\\[watcher\\] SM-Analytics_(?P<dc>sea|par|bei|eu2|us2)_(?P<trans>.*)', re.IGNORECASE),
        'fields': ['dc', 'trans']
    },
    'analytics_bei': {
        'regex': re.compile('Watcher Alert \\[CRITICAL\\] : SM-Analytics_(?P<dc>BEI)_(?P<trans>.*)', re.IGNORECASE),
        'fields': ['dc', 'trans']
    },
    'srer_couchbase': {
        'regex': re.compile('SRER_PLATFORM_COUCHBASE \\((?P<trans>.*)\\)', re.IGNORECASE),
        'fields': ['trans']
    },
    'expense_imaging': {
        'regex': re.compile('(?P<trans>SM-Expense_.*Imaging-.*)', re.IGNORECASE),
        'fields': ['trans']
    },
    'expense_imaging_upload': {
        'regex': re.compile('(?P<trans>SM_.*_Imaging_Upload_Count.*)', re.IGNORECASE),
        'fields': ['trans']
    },
    'expense': {
        'regex': re.compile('.*SM-Expense_(?P<dc>sea|par|bei|eu2|us2)_(?P<trans>.*)', re.IGNORECASE),
        'fields': ['dc']
    },
    'cognos_login': {
        'regex': re.compile('Cognos\\s*Login \\((?P<trans>.*)\\)', re.IGNORECASE),
        'fields': ['trans']
    },
    'couchbase': {
        'regex': re.compile('Couchbase_Colo_Pager \\((?P<trans>.*)\\)', re.IGNORECASE),
        'fields': ['trans']
    },
    'uspscc_prod': {
        'regex': re.compile('(?P<dc>USPSCC)-PROD-Travel-(?P<tier>\\w+) \\((?P<trans>.*)\\)', re.IGNORECASE),
        'fields': ['dc', 'tier', 'trans']
    },
    'uspscc_sm': {
        'regex': re.compile('(?P<dc>USPSCC)-SM-Expense-(?P<tier>\\w+) \\((?P<trans>.*)\\)', re.IGNORECASE),
        'fields': ['dc', 'tier', 'trans']
    },
    'uspscc_synthetic': {
        'regex': re.compile('CCPS-SRERE-(?P<product>Travel|Spend)-(?P<alert_type>Synthetic)s \\((?P<trans>.*)\\)', re.IGNORECASE),
        'fields': ['product', 'alert_type', 'trans']
    },
    'uspscc_synthetic_2': {
        'regex': re.compile('USPSCC-SM-(?P<product>Spend)-(?P<alert_type>Synthetic)s \\((?P<trans>.*)\\)', re.IGNORECASE),
        'fields': ['product', 'alert_type', 'trans']
    },
    'shared_aui_lui_mui': {
        'regex': re.compile('Shared - (?P<dc>PAR|SEA|EU2|US2)-PR1-(?P<tier>\\w+) \\((?P<trans>.*)\\)', re.IGNORECASE),
        'fields': ['dc', 'tier', 'trans']
    },
    'tui': {
        'regex': re.compile('(?P<product>Travel) - (?P<dc>SEA|PAR|EU2|US2) - (?P<tier>TUI) \\((?P<trans>.*)\\)', re.IGNORECASE),
        'fields': ['product', 'dc', 'tier', 'trans']
    },
    'lui': {
        'regex': re.compile('SRER-SM-LOGIN-(?P<tier>LUI) \\((?P<trans>.*)\\)', re.IGNORECASE),
        'fields': ['tier', 'trans']
    },
    'beilui': {
        'regex': re.compile('BEI-SM-(?P<tier>LUI) \\((?P<trans>.*)\\)', re.IGNORECASE),
        'fields': ['tier', 'trans']
    },
    'srer_active_batch': {
        'regex': re.compile('SRER_Active_Batch_(?P<trans>.*)', re.IGNORECASE),
        'fields': ['trans']
    },
    'srer_login_mobile': {
        'regex': re.compile('srer_shared_login_mobile \\((?P<trans>.*)\\)', re.IGNORECASE),
        'fields': ['trans']
    },
    'srer_mobile_report': {
        'regex': re.compile('SRER-(?P<dc>SEA|PAR|EU2|US2)_Mobile_Report_Submits \\((?P<trans>.*)\\)', re.IGNORECASE),
        'fields': ['dc', 'trans']
    },
    'srer_request_synthetic': {
        'regex': re.compile('SRER_Request_(EU2|US2)_Web \\((?P<trans>.*)\\)', re.IGNORECASE),
        'fields': ['trans']
    },
    'srer_travel_request_synthetic': {
        'regex': re.compile('SRER_Travel_Request \\((?P<trans>.*)\\)', re.IGNORECASE),
        'fields': ['trans']
    },
    'srer_mobile_synthetic_eu2': {
        'regex': re.compile('SRER_Mobile_(?P<dc>EU2)_(?P<product>Travel|Login|Expense) \\((?P<trans>.*)\\)', re.IGNORECASE),
        'fields': ['dc', 'product', 'trans']
    },
    'srer_spend_invoice': {
        'regex': re.compile('SRER_(?P<product>SPEND)_(?P<tier>Invoice) (?P<trans>.*)', re.IGNORECASE),
        'fields': ['product', 'tier', 'trans']
    },
    'expense_tab': {
        'regex': re.compile('Expense Tab Check \\((?P<trans>.*)\\)', re.IGNORECASE),
        'fields': ['trans']
    },
    'srer_expense_tab': {
        'regex': re.compile('SRER_SPEND_ExpenseTabCheck (?P<trans>.*)', re.IGNORECASE),
        'fields': ['trans']
    },
    'srer_spend': {
        'regex': re.compile('SRER_(?P<product>SPEND)_(?P<tier>\\w{3}) (?P<trans>.*)', re.IGNORECASE),
        'fields': ['product', 'tier', 'trans']
    },
    'srer_spend_eui': {
        'regex': re.compile('SRER_(?P<product>SPEND)_(BEI_)*(?P<tier>EUI)[-_]\\w+ \\((?P<trans>.*)\\)', re.IGNORECASE),
        'fields': ['product', 'tier', 'trans']
    },
    'srer_spend_eui_2': {
        'regex': re.compile('\\[SRER\\] (?P<tier>EUI) Policy \\((?P<trans>.*)\\)', re.IGNORECASE),
        'fields': ['tier', 'trans']
    },
    'srer_spend_mgmt_eui': {
        'regex': re.compile('SRER_(?P<product>SPEND)MANAGEMENT_(?P<tier>EUI) \\((?P<trans>.*)\\)', re.IGNORECASE),
        'fields': ['product', 'tier', 'trans']
    },
    'itin': {
        'regex': re.compile('(SRER_)*(?P<tier>ITIN)[_ ]Policies \\((?P<trans>.*)\\)', re.IGNORECASE),
        'fields': ['tier', 'trans']
    },
    'srer_tui': {
        'regex': re.compile('SRER_(?P<product>TRAVEL)_(?P<dc>SEA|PAR|BEI|EU2|US2)_(?P<tier>TUI) \\((?P<trans>.*)\\)', re.IGNORECASE),
        'fields': ['product', 'dc', 'tier', 'trans']
    },
    'srer_euiasp': {
        'regex': re.compile('(?P<tier>EUI)-Prod \\((?P<trans>.*)\\)', re.IGNORECASE),
        'fields': ['tier', 'trans']
    },
    'srer_tui_uspscc': {
        'regex': re.compile('SRER-(?P<dc>USPSCC)-(?P<product>Travel)-(?P<tier>TUI) \\((?P<trans>.*)\\)', re.IGNORECASE),
        'fields': ['dc', 'product', 'tier', 'trans']
    },
    'spend_synthetic': {
        'regex': re.compile('SRER_SPEND_Synthetics \\((?P<trans>.*)\\)', re.IGNORECASE),
        'fields': ['trans']
    },
    'car_hotel_search': {
        'regex': re.compile('SRER - Travel (Car|Hotel) Search \\((?P<trans>.*)\\)', re.IGNORECASE),
        'fields': ['trans']
    },
    'sabre_search_uspscc': {
        'regex': re.compile('SRER - CCPS/PSCC Travel Sabre (Air|Car|Hotel) search \\((?P<trans>.*)\\)', re.IGNORECASE),
        'fields': ['trans']
    },
    'f5': {
        'regex': re.compile('(?P<trans>FAILURE: Connection to (par|seaext|seaint)f5.concurasp.com.*)', re.IGNORECASE),
        'fields': ['trans']
    },
    'f5_pool': {
        'regex': re.compile('(?P<trans>.*Pool available.*)', re.IGNORECASE),
        'fields': ['trans']
    },
    'f5_pool_diff': {
        'regex': re.compile('(?P<dc>PAR) - There are.*F5 pools (?P<trans>.*)', re.IGNORECASE),
        'fields': ['dc', 'trans']
    },
    'f5_pool_availability': {
        'regex': re.compile('SRER_(?P<dc>SEA|PAR|BEI)(IM1|PR1)_F5_Pool(_BRAVO)*_Availability \\((?P<trans>).*\\)', re.IGNORECASE),
        'fields': ['dc', 'trans']
    },
    'f5_china': {
        'regex': re.compile('(?P<trans>FAILURE: Connection to chif500.*)', re.IGNORECASE),
        'fields': ['trans']
    },
    'travel_synthetic_failure': {
        'regex': re.compile('.*(?P<product>Travel)[_ ](?P<alert_type>Synthetic)[_ ]Failure .*\\((?P<trans>.*)\\)', re.IGNORECASE),
        'fields': ['product', 'alert_type', 'trans']
    },
    'uspscc_bspool': {
        'regex': re.compile('\\[SRER\\] (?P<dc>USPSCC) (?P<tier>BSPOOL) \\((?P<trans>.*)\\)', re.IGNORECASE),
        'fields': ['dc', 'tier', 'trans']
    },
    'srer_cogwi': {
        'regex': re.compile('SRER_ANALYTICS_Cog_Disk_Space \\((?P<trans>.*)\\)', re.IGNORECASE),
        'fields': ['trans']
    },
    'srer_cogwb': {
        'regex': re.compile('CNQR-SM-CTE_Critical \\[PD\\] \\((?P<trans>.*)\\)', re.IGNORECASE),
        'fields': ['trans']
    },
    'api_gateway_5xx': {
        'regex': re.compile('Watcher Alert \\[(?P<dc>bei|par|sea|eu2|us2)pr1\\]: (?P<trans>.*)', re.IGNORECASE),
        'fields': ['dc', 'trans']
    },
    'email2db': {
        'regex': re.compile('(?P<trans>EMAIL2DB|em2db)', re.IGNORECASE),
        'fields': ['trans']
    },
    'data_insights': {
        'regex': re.compile('(?P<trans>.*Insights - Queue)', re.IGNORECASE),
        'fields': ['trans']
    },
    'reboot': {
        'regex': re.compile('Completed reboot pool: (?P<trans>.*)', re.IGNORECASE),
        'fields': ['trans']
    },
    'reboot_2': {
        'regex': re.compile('(?P<trans>There is only 1 node.*)', re.IGNORECASE),
        'fields': ['trans']
    },
    'reboot_3': {
        'regex': re.compile('(?P<trans>FAILURE (DIS|EN)ABLED .*)', re.IGNORECASE),
        'fields': ['trans']
    },
    'healthy_nodes': {
        'regex': re.compile('(?P<trans>The healthy nodes number.*)', re.IGNORECASE),
        'fields': ['trans']
    },
    'ui_diskspace': {
        'regex': re.compile('UI-DiskSpaceLow \\((?P<trans>.*)\\)', re.IGNORECASE),
        'fields': ['trans']
    },
    'submit_report_count': {
        'regex': re.compile('(?P<trans>SubmitReport count.*)', re.IGNORECASE),
        'fields': ['trans']
    },
    'travel_booking': {
        'regex': re.compile('.*(?P<trans>TravelBookingAttempts.*)', re.IGNORECASE),
        'fields': ['trans']
    },
    'srer_login': {
        'regex': re.compile('SRER_(?P<alert_type>Login)_(?P<dc>PAR|SEA|BEI) \\((?P<trans>.*)\\)', re.IGNORECASE),
        'fields': ['alert_type', 'dc', 'trans']
    },
    'expense_login_drop': {
        'regex': re.compile('.* (?P<trans>PAR|SEA|BEI|EU2|US2)pr1_SM_ExpenseLogins_.*', re.IGNORECASE),
        'fields': ['trans']
    },
    'flight_searches_drop': {
        'regex': re.compile('.* (?P<trans>PAR|SEA|EU2|US2)pr1_SM_FlightSearches_.*', re.IGNORECASE),
        'fields': ['trans']
    },
    'tws': {
        'regex': re.compile('Travel .*(?P<dc>PAR|SEA|EU2|US2) - (?P<tier>TWS) \\((?P<trans>.*)\\)', re.IGNORECASE),
        'fields': ['dc', 'tier', 'trans']
    },
    'tmt': {
        'regex': re.compile('Travel .*(?P<dc>PAR|SEA|EU2|US2) - (?P<tier>TMT) \\((?P<trans>.*)\\)', re.IGNORECASE),
        'fields': ['dc', 'tier', 'trans']
    },
    'srer_tws': {
        'regex': re.compile('SRER_TRAVEL_(?P<dc>PAR|SEA|EU2|US2)_(?P<tier>TWS) \\((?P<trans>.*)\\)', re.IGNORECASE),
        'fields': ['dc', 'tier', 'trans']
    },
    'srer_tmt': {
        'regex': re.compile('SRER_TRAVEL_(?P<dc>PAR|SEA|EU2|US2|BEI)_(?P<tier>TMT) \\((?P<trans>.*)\\)', re.IGNORECASE),
        'fields': ['dc', 'tier', 'trans']
    },
    'sre_db': {
        'regex': re.compile('(SRE: |SRE_)PagerDuty Alert Policy \\((?P<trans>.*)\\)', re.IGNORECASE),
        'fields': ['trans']
    },
    'srer_db': {
        'regex': re.compile('SRER_TRAVEL_PagerDuty_Alert \\((?P<trans>.*)\\)', re.IGNORECASE),
        'fields': ['trans']
    },
    'srer_clq': {
        'regex': re.compile('SRER_TRAVEL_(?P<tier>CLQ) \\((?P<trans>.*)\\)', re.IGNORECASE),
        'fields': ['tier', 'trans']
    },
    'concur_open': {
        'regex': re.compile('Concur Open Page Views \\((?P<trans>.*)\\)', re.IGNORECASE),
        'fields': ['trans']
    },
    'iuiasp': {
        'regex': re.compile('SRER_SPEND_(?P<dc>PAR|SEA|EU2|US2)_(?P<tier>IUIASP) \\((?P<trans>.*)\\)', re.IGNORECASE),
        'fields': ['dc', 'tier', 'trans']
    },
    'iuiasp_2': {
        'regex': re.compile('(?P<dc>PAR|SEA|EU2|US2)-PR1-(?P<tier>IUIASP) \\((?P<trans>.*)\\)', re.IGNORECASE),
        'fields': ['dc', 'tier', 'trans']
    },
    'classicpay': {
        'regex': re.compile('.*(?P<trans>classicpay.*)', re.IGNORECASE),
        'fields': ['trans']
    },
    'mobile': {
        'regex': re.compile('Watcher Alert \\[ERROR\\] : (?P<trans>Mobile.*)', re.IGNORECASE),
        'fields': ['trans']
    },
    'ccapi': {
        'regex': re.compile('.*cardsapi.* \\((?P<trans>.*\\))', re.IGNORECASE),
        'fields': ['trans']
    },
    'eui_imp_synthetic': {
        'regex': re.compile('EUI-Implementation \\((?P<trans>.*\\))', re.IGNORECASE),
        'fields': ['trans']
    },
    'eui_anomalies': {
        'regex': re.compile('EUI-Anomalies \\((?P<trans>.*\\))', re.IGNORECASE),
        'fields': ['trans']
    },
    'srer_nuisgn': {
        'regex': re.compile('SRER-Coreservices-(?P<tier>NUISGN) \\((?P<trans>.*\\))', re.IGNORECASE),
        'fields': ['tier', 'trans']
    },
    'srer_nuisgn_2': {
        'regex': re.compile('SRER_PLATFORM_(?P<tier>NUISGN) \\((?P<trans>.*\\))', re.IGNORECASE),
        'fields': ['tier', 'trans']
    },
    'cognos_jenkins': {
        'regex': re.compile('(?P<trans>.*jenkins.*cognos.*)', re.IGNORECASE),
        'fields': ['trans']
    },
    'cognos_jenkins_deployment': {
        'regex': re.compile('.*(?P<trans>Deploying Cognos packages).*', re.IGNORECASE),
        'fields': ['trans']
    },
    'cognos_jenkins_dispatcher': {
        'regex': re.compile('(?P<trans>.*Cognos Maintenance.*)', re.IGNORECASE),
        'fields': ['trans']
    },
    'cognos_opi': {
        'regex': re.compile('(?P<trans>.*OPI-[0-9]+)', re.IGNORECASE),
        'fields': ['trans']
    },
    'slo_poc': {
        'regex': re.compile('slo-poc.* \\((?P<trans>.*)\\)', re.IGNORECASE),
        'fields': ['trans']
    },
    'ces_prod': {
        'regex': re.compile('CES - Production \\((?P<trans>.*)\\)', re.IGNORECASE),
        'fields': ['trans']
    },
    'srer_testing': {
        'regex': re.compile('(?P<trans>.*(testttest|test|tesr|test NR)+)', re.IGNORECASE),
        'fields': ['trans']
    },
    'firedrill': {
        'regex': re.compile('(?P<trans>.*fire[ ]*drill.*)', re.IGNORECASE),
        'fields': ['trans']
    },
    'gls_couchbase_error': {
        'regex': re.compile('(?P<dc>SEA)PR1-(?P<tier>GLS)-(?P<trans>couchbase-.*)', re.IGNORECASE),
        'fields': ['dc', 'tier', 'trans']
    },
    'css': {
        'regex': re.compile('Watcher Alert \\[CRITICAL\\] : SM-Expense_(?P<trans>.*css.*)', re.IGNORECASE),
        'fields': ['trans']
    },
    'hmc': {
        'regex': re.compile('\\[watcher\\] SM-Expense_(?P<dc>USPSCC)_(?P<tier>HMC)-(?P<trans>.*)', re.IGNORECASE),
        'fields': ['dc', 'tier', 'trans']
    },
    'imgws': {
        'regex': re.compile('(?P<dc>PAR|SEA|BEI)-PR1-(?P<tier>IMGWS) SRER-US High CPU Alert \\((?P<trans>.*)\\)', re.IGNORECASE),
        'fields': ['dc', 'tier', 'trans']
    },
    '___no-matches___': {
        'regex': re.compile('(?P<trans>.*)', re.IGNORECASE),
        'fields': ['trans']
    }
}


def parse_dc(trans):
    if re.search(r"(par|emea)", trans, re.IGNORECASE):
        dc = 'par'
    elif re.search(r"(ccps|pscc|uspscc)", trans, re.IGNORECASE):
        dc = 'uspscc'
    elif re.search(r"(bei|china)", trans, re.IGNORECASE):
        dc = 'bei'
    elif re.search("eu2", trans, re.IGNORECASE):
        dc = 'eu2'
    elif re.search("us2", trans, re.IGNORECASE):
        dc = 'us2'
    elif re.search("dfw", trans, re.IGNORECASE):
        dc = 'dfw'
    elif re.search("ams", trans, re.IGNORECASE):
        dc = 'ams'
    else:
        # Default to sea if no matches found
        dc = 'sea'
    return dc


def parse_dc_jira(kwargs):
    dc_jira = {
        'par': 'Paris - Com',
        'uspscc': 'US Gov West',
        'bei': 'China',
        'dfw': 'Dallas - Com DR',
        'ams': 'Amsterdam - Com DR',
        'sea': 'Lynnwood - Com',
        'eu2': 'EU2 (EMEA COM 2)',
        'us2': 'US2 (US COM 2)',
        'fabian_us': 'Fabian US',
        'fabian_emea': 'Fabian EMEA'
    }

    # Return the formal data center name to match JIRA
    if 'dc' in kwargs and dc_jira[kwargs['dc']]:
        kwargs['jira_dc'] = dc_jira[kwargs['dc']]
        return kwargs


def get_region(kwargs, query):
    if query.created_on.hour in range(0, 7):
        kwargs['region'] = 'apac'
    elif query.created_on.hour in range(8, 15):
        kwargs['region'] = 'emea'
    elif query.created_on.hour in range(16, 23):
        kwargs['region'] = 'amers'
    return kwargs


def parse_description(kwargs, description, service_name):
    for cur_incident in regex_dict.keys():
        # Get the regular expression to search
        regex = regex_dict[cur_incident]['regex']

        # We need the data in the series to search the correct column
        match = regex.search(description)
        if match:
            kwargs['regex_key'] = cur_incident
            # print(f"    [MATCH] {cur_incident}")

            alert_type = ""
            for field in regex_dict[cur_incident]['fields']:
                # print(f"      [FIELD][{field}] {match.group(field)}")
                kwargs[field] = (match.group(field)).lower()
                if field == 'alert_type':
                    alert_type = (match.group(field)).lower()

            if cur_incident in ['srer_tier_slo_alerts','srer_uspscc_eui_tier_slo_alerts']:
                alert_type =  (match.group('alert_type')).lower()
                kwargs['alert_type'] = alert_type
                tier = match.group('tier').lower()
                kwargs['product'] = rms[tier]['product']
                kwargs['dc'] = parse_dc(match.group('trans'))
            elif cur_incident == 'slos_obsfw':
                tier = match.group('tier').lower()
                # Override for kraken type for FIS in April 2021
                if tier == 'kraken':
                    tier = 'fis'
                kwargs['alert_type'] = alert_type
                kwargs['product'] = rms[tier]['product']
            elif cur_incident == 'sli':
                alert_type =  (match.group('alert_type')).lower()
                if alert_type == 'availability':
                    alert_type = 'avail'
                kwargs['alert_type'] = alert_type
                product = (match.group('product')).lower()
                if product == 'expense':
                    kwargs['product'] = 'spend'
            elif cur_incident in ['srer_outtask_error_warning']:
                tier = 'tui'
                alert_type = 'outtask_error'
                kwargs['alert_type'] = alert_type
                kwargs['tier'] = tier
                kwargs['product'] = rms[tier]['product']
                kwargs['dc'] = 'eu2'
            elif cur_incident == 'srer_cognos_synthetic':
                tier = match.group('tier').lower()
                kwargs['product'] = rms[tier]['product']
                kwargs['dc'] = parse_dc(match.group('trans'))
            elif cur_incident in ['srer_mobile_synthetic_eu2']:
                product = (match.group('product')).lower()
                tiers = {
                    "travel": "tui",
                    "login": "lui",
                    "expense": "ers",
                }
                tier = tiers[product]
                alert_type = 'synthetic'
                kwargs['alert_type'] = alert_type
                kwargs['tier'] = tier
            elif cur_incident in ['srer_request_synthetic','srer_travel_request_synthetic']:
                tier = 'raas'
                alert_type = 'synthetic'
                kwargs['alert_type'] = alert_type
                kwargs['tier'] = tier
                kwargs['product'] = rms[tier]['product']
                kwargs['dc'] = parse_dc(match.group('trans'))
            elif cur_incident in ['srer_web_login_synthetic_eu2']:
                tier = 'lui'
                alert_type = 'synthetic'
                kwargs['alert_type'] = alert_type
                kwargs['tier'] = tier
                kwargs['product'] = rms[tier]['product']
                kwargs['dc'] = parse_dc(match.group('trans'))
            elif cur_incident in ['srer_expense_synthetic','srer_expense_synthetic_eu2_web']:
                tier = 'ers'
                alert_type = 'synthetic'
                kwargs['alert_type'] = alert_type
                kwargs['tier'] = tier
                kwargs['product'] = rms[tier]['product']
                kwargs['dc'] = parse_dc(match.group('trans'))
            elif cur_incident in ['travel_synthetic_failure','travel_synthetic','srer_travel_synthetic','srer_travel_synthetic_eu2_web']:
                tier = 'tui'
                alert_type = 'synthetic'
                kwargs['alert_type'] = alert_type
                kwargs['tier'] = tier
                kwargs['product'] = rms[tier]['product']
                kwargs['dc'] = parse_dc(match.group('trans'))
            elif cur_incident == 'srer_login_synthetic':
                tier = 'lui'
                alert_type = 'synthetic'
                kwargs['alert_type'] = alert_type
                kwargs['tier'] = tier
                kwargs['product'] = rms[tier]['product']
                kwargs['dc'] = parse_dc(match.group('trans'))
            elif cur_incident == 'apigateway_client_cert_expired':
                tier = 'apigwf'
                kwargs['tier'] = tier
                kwargs['product'] = rms[tier]['product']
                kwargs['dc'] = parse_dc(match.group('trans'))
                kwargs['alert_type'] = 'apigw_client_cert_expired'
            elif cur_incident in ['sre_db', 'srer_db']:
                tier = "dbsql"
                kwargs['tier'] = tier
                kwargs['product'] = 'infrastructure'
                alert_type = 'dbsql'
                kwargs['alert_type'] = alert_type
                kwargs['dc'] = parse_dc(match.group('trans'))
            elif cur_incident == 'sli_no_product':
                tier = match.group('tier').lower()
                kwargs['tier'] = tier
                kwargs['product'] = rms[tier]['product']
                alert_type = (match.group('alert_type')).lower()
                if alert_type == 'availability':
                    alert_type = 'avail'
                kwargs['alert_type'] = alert_type
            elif cur_incident == 'slo_poc':
                tier = "saml"
                kwargs['tier'] = tier
                kwargs['dc'] = 'sea'
                kwargs['product'] = rms[tier]['product']
                alert_type = 'metric'
                kwargs['alert_type'] = alert_type
            elif cur_incident == 'api_gateway_5xx':
                tier = "apigwf"
                kwargs['tier'] = tier
                kwargs['product'] = 'core'
                alert_type = 'api_gateway_error'
                kwargs['alert_type'] = alert_type
            elif cur_incident == 'sli_invoice':
                kwargs['product'] = 'spend'
            elif cur_incident in ['cognos_jenkins', 'cognos_jenkins_dispatcher', 'cognos_jenkins_deployment']:
                tier = "cognos"
                kwargs['tier'] = tier
                kwargs['product'] = rms[tier]['product']
                alert_type = 'cognos_jenkins'
                kwargs['alert_type'] = alert_type
                kwargs['dc'] = parse_dc(match.group('trans'))
            elif cur_incident == 'eui_anomalies':
                tier = "eui"
                kwargs['tier'] = tier
                kwargs['product'] = rms[tier]['product']
                alert_type = 'baseline'
                kwargs['alert_type'] = alert_type
                kwargs['dc'] = parse_dc(match.group('trans'))
            elif cur_incident == 'eui_imp_synthetic':
                tier = "eui"
                alert_type = 'synthetic'
                kwargs['alert_type'] = alert_type
                kwargs['tier'] = tier
                kwargs['product'] = rms[tier]['product']
                if re.search("US", match.group('trans'), re.IGNORECASE):
                    dc = 'seaim1'
                else:
                    dc = 'parim1'
                kwargs['dc'] = dc
            elif cur_incident == 'travel_baselines':
                kwargs['product'] = rms[match.group('tier').lower()]['product']
                alert_type = "baseline"
                kwargs['alert_type'] = alert_type
            elif cur_incident == 'uspscc_bspool':
                kwargs['product'] = rms[match.group('tier').lower()]['product']
                alert_type = "baseline"
                kwargs['alert_type'] = alert_type
            elif cur_incident == 'sli_appmgt':
                kwargs['product'] = rms[match.group('tier').lower()]['product']
            elif cur_incident in ['mobile','srer_mobile_report']:
                tier = 'mui'
                kwargs['tier'] = tier
                kwargs['product'] = rms[tier]['product']
                alert_type = 'mobile'
                kwargs['alert_type'] = alert_type
                kwargs['dc'] = parse_dc(match.group('trans'))
            elif cur_incident == 'sli_profile':
                tier = 'profile'
                kwargs['tier'] = tier
                kwargs['product'] = rms[tier]['product']
            elif cur_incident == 'uspscc_prod':
                tier = match.group('tier').lower()
                kwargs['tier'] = tier
                kwargs['product'] = rms[tier]['product']
            elif cur_incident in ['uspscc_synthetic', 'uspscc_synthetic_2']:
                product = match.group('product').lower()
                if product == 'travel':
                    tier = 'tui'
                else:
                    tier = 'eui'
                alert_type = 'synthetic'
                kwargs['alert_type'] = alert_type
                kwargs['tier'] = tier
            elif cur_incident in ['auitrv','auitrv2']:
                tier = match.group('tier').lower()
                kwargs['tier'] = tier
                kwargs['product'] = rms[tier]['product']
                kwargs['dc'] = parse_dc(match.group('trans'))
                kwargs['alert_type'] = 'infrastructure'
            elif cur_incident in ['aui_policy']:
                tier = 'aui'
                kwargs['tier'] = tier
                kwargs['product'] = rms[tier]['product']
                kwargs['dc'] = parse_dc(match.group('trans'))
                kwargs['alert_type'] = 'infrastructure'
            elif cur_incident in ['auiexp']:
                kwargs['product'] = rms[match.group('tier').lower()]['product']
                kwargs['dc'] = parse_dc(match.group('trans'))
                kwargs['alert_type'] = 'infrastructure'
            elif cur_incident == 'firedrill':
                tier = "srer"
                kwargs['tier'] = tier
                alert_type = 'firedrill'
                kwargs['alert_type'] = alert_type
                kwargs['product'] = rms[tier]['product']
                kwargs['dc'] = 'sea'
            elif cur_incident == 'srer_testing':
                tier = "srer"
                kwargs['tier'] = tier
                alert_type = 'srer_testing'
                kwargs['alert_type'] = alert_type
                kwargs['product'] = rms[tier]['product']
                kwargs['dc'] = 'sea'
            elif cur_incident in ['ccapi']:
                tier = "ccapi"
                kwargs['tier'] = tier
                kwargs['product'] = rms[tier]['product']
                alert_type = 'infrastructure'
                kwargs['alert_type'] = alert_type
                kwargs['dc'] = 'sea'
            elif cur_incident in ['iuiasp', 'iuiasp_2']:
                kwargs['product'] = rms[match.group('tier').lower()]['product']
                alert_type = 'infrastructure'
                kwargs['alert_type'] = alert_type
            elif cur_incident in ['tui', 'tui_srer', 'srer_tui', 'srer_tui_uspscc']:
                alert_type = 'infrastructure'
                kwargs['alert_type'] = alert_type
            elif cur_incident == 'flight_searches_drop':
                tier = "tui"
                kwargs['tier'] = tier
                kwargs['product'] = rms[tier]['product']
                alert_type = 'flight_searches_drop'
                kwargs['alert_type'] = alert_type
                kwargs['dc'] = parse_dc(match.group('trans'))
            elif cur_incident == 'expense_login_drop':
                tier = "eui"
                kwargs['tier'] = tier
                kwargs['product'] = rms[tier]['product']
                alert_type = 'expense_login_drop'
                kwargs['alert_type'] = alert_type
                kwargs['dc'] = parse_dc(match.group('trans'))
            elif cur_incident in ['srer_nuisgn', 'srer_nuisgn_2']:
                kwargs['product'] = rms[match.group('tier').lower()]['product']
                alert_type = 'k8s_pod_sample'
                kwargs['alert_type'] = alert_type
                kwargs['dc'] = parse_dc(match.group('trans'))
            elif cur_incident == 'synthetic_policy_expense':
                tier = "eui"
                kwargs['tier'] = tier
                kwargs['product'] = rms[tier]['product']
                alert_type = 'synthetic'
                kwargs['alert_type'] = alert_type
                kwargs['dc'] = parse_dc(match.group('trans'))
            elif cur_incident in ['tws', 'srer_tws']:
                kwargs['product'] = rms[match.group('tier').lower()]['product']
                alert_type = 'infrastructure'
                kwargs['alert_type'] = alert_type
            elif cur_incident in ['srer_tmt', 'tmt']:
                kwargs['product'] = rms[match.group('tier').lower()]['product']
                alert_type = 'infrastructure'
                kwargs['alert_type'] = alert_type
            elif cur_incident == 'submit_report_count':
                tier = 'eui'
                kwargs['tier'] = tier
                kwargs['product'] = rms[tier]['product']
                alert_type = 'submit_report'
                kwargs['alert_type'] = alert_type
                kwargs['dc'] = parse_dc(match.group('trans'))
            elif cur_incident == 'travel_booking':
                tier = 'tui'
                kwargs['tier'] = tier
                kwargs['dc'] = 'sea'
                kwargs['product'] = rms[tier]['product']
                alert_type = 'travel_booking'
                kwargs['alert_type'] = alert_type
            elif cur_incident == 'srer_login':
                tier = 'lui'
                kwargs['tier'] = tier
                kwargs['product'] = rms[tier]['product']
            elif cur_incident == 'ui_diskspace':
                tier = 'ui'
                kwargs['tier'] = tier
                kwargs['product'] = rms[tier]['product']
                alert_type = 'infrastructure'
                kwargs['alert_type'] = alert_type
                kwargs['dc'] = parse_dc(match.group('trans'))
            elif cur_incident == 'cesclassic':
                tier = 'ces'
                kwargs['tier'] = tier
                kwargs['product'] = rms[tier]['product']
                alert_type = 'ces_classic_error'
                kwargs['alert_type'] = alert_type
            elif cur_incident == 'sitedown':
                tier = 'ui'
                kwargs['tier'] = tier
                kwargs['product'] = rms[tier]['product']
                alert_type = 'sitedown'
                kwargs['alert_type'] = alert_type
                kwargs['trans'] = 'service_health'
            elif cur_incident == 'outtask_error':
                tier = 'ui'
                kwargs['tier'] = tier
                kwargs['product'] = rms[tier]['product']
                alert_type = 'outtask_error'
                kwargs['alert_type'] = alert_type
                kwargs['trans'] = 'outtask_error'
            elif cur_incident in ['car_hotel_search', 'sabre_search_uspscc']:
                tier = 'gds'
                kwargs['tier'] = tier
                kwargs['product'] = rms[tier]['product']
                alert_type = 'synthetic'
                kwargs['alert_type'] = alert_type
                kwargs['dc'] = parse_dc(match.group('trans'))
            elif cur_incident in ['f5', 'f5_pool_diff', 'f5_china', 'reboot', 'healthy_nodes', 'reboot_2', 'reboot_3', 'f5_pool', 'f5_pool_availability']:
                tier = 'f5'
                kwargs['tier'] = tier
                kwargs['product'] = rms[tier]['product']
                alert_type = 'f5'
                kwargs['alert_type'] = alert_type
                kwargs['alert_source'] = 'jenkins'
                try:
                    kwargs['dc'] = match.group('dc').lower()
                except:
                    kwargs['dc'] = parse_dc(match.group('trans'))
            elif cur_incident in ['email2db']:
                tier = 'email2db'
                kwargs['tier'] = tier
                kwargs['product'] = rms[tier]['product']
                alert_type = 'email2db'
                kwargs['alert_type'] = alert_type
                kwargs['dc'] = parse_dc(match.group('trans'))
            elif cur_incident == 'shared_aui_lui_mui':
                kwargs['product'] = rms[match.group('tier').lower()]['product']
                alert_type = 'ui_error'
                kwargs['alert_type'] = alert_type
            elif cur_incident in ['srer_expense_tab', 'expense_tab']:
                alert_type = 'synthetic'
                kwargs['alert_type'] = alert_type
                tier = 'eui'
                kwargs['tier'] = tier
                kwargs['product'] = rms[tier]['product']
                kwargs['dc'] = parse_dc(match.group('trans'))
            elif cur_incident == 'srer_active_batch':
                alert_type = 'infrastructure'
                kwargs['alert_type'] = alert_type
                kwargs['product'] = 'cte_common'
                kwargs['tier'] = 'abwex'
                kwargs['dc'] = parse_dc(match.group('trans'))
            elif cur_incident in ['expense_uspscc_drop_watcher']:
                tier = 'ers'
                alert_type = 'expense_metrics_drop'
                kwargs['tier'] = tier
                kwargs['product'] = rms[tier]['product']
                kwargs['dc'] = parse_dc(match.group('dc'))
            elif cur_incident in ['expense_uspscc_submit_reports_latency']:
                tier = 'ers'
                alert_type = 'expense_submit_reports_latency'
                kwargs['tier'] = tier
                kwargs['product'] = rms[tier]['product']
                kwargs['dc'] = parse_dc(match.group('dc'))
            elif cur_incident in ['uspscc_sm']:
                kwargs['alert_type'] = 'infrastructure'
                tier = match.group('tier').lower()
                kwargs['tier'] = tier
                kwargs['product'] = rms[tier]['product']
            elif cur_incident in ['srer_euiasp']:
                kwargs['alert_type'] = 'infrastructure'
                tier = 'euiasp'
                kwargs['tier'] = tier
                kwargs['product'] = rms[tier]['product']
                kwargs['dc'] = parse_dc(match.group('trans'))
            elif cur_incident in ['srer_spend', 'srer_spend_eui', 'srer_spend_eui_2', 'srer_spend_mgmt_eui']:
                kwargs['alert_type'] = 'infrastructure'
                kwargs['product'] = rms[match.group('tier').lower()]['product']
                kwargs['dc'] = parse_dc(match.group('trans'))
            elif cur_incident in ['lui','beilui']:
                kwargs['product'] = rms[match.group('tier').lower()]['product']
                alert_type = 'infrastructure'
                kwargs['alert_type'] = alert_type
                kwargs['dc'] = parse_dc(match.group('trans'))
            elif cur_incident in ['srer_couchbase', 'couchbase']:
                tier = "cb4c"
                kwargs['tier'] = tier
                kwargs['product'] = rms[tier]['product']
                alert_type = 'couchbase'
                kwargs['alert_type'] = alert_type
                kwargs['dc'] = parse_dc(match.group('trans'))
            elif cur_incident == 'data_insights':
                tier = "dis"
                kwargs['tier'] = tier
                kwargs['product'] = rms[tier]['product']
                alert_type = 'data_insights_queue'
                kwargs['alert_type'] = alert_type
                kwargs['dc'] = parse_dc(match.group('trans'))
            elif cur_incident == 'cogwi':
                tier = "cogwi"
                kwargs['tier'] = tier
                kwargs['product'] = rms[tier]['product']
                alert_type = 'infrastructure'
                kwargs['alert_type'] = alert_type
                kwargs['dc'] = parse_dc(match.group('trans'))
            elif cur_incident == 'cogwb':
                tier = "cogwb"
                kwargs['tier'] = tier
                kwargs['product'] = rms[tier]['product']
                alert_type = 'infrastructure'
                kwargs['alert_type'] = alert_type
                kwargs['dc'] = parse_dc(match.group('trans'))
            elif cur_incident == 'srer_login_mobile':
                tier = "mui"
                kwargs['tier'] = tier
                kwargs['product'] = rms[tier]['product']
                alert_type = 'infrastructure'
                kwargs['alert_type'] = alert_type
                kwargs['dc'] = parse_dc(match.group('trans'))
            elif cur_incident == 'itin':
                kwargs['product'] = rms[match.group('tier').lower()]['product']
                alert_type = 'infrastructure'
                kwargs['alert_type'] = alert_type
                kwargs['dc'] = parse_dc(match.group('trans'))
            elif cur_incident == 'spend_synthetic':
                if re.search("Invoice", match.group('trans'), re.IGNORECASE):
                    tier = 'invoice'
                else:
                    tier = 'eui'
                kwargs['tier'] = tier
                kwargs['product'] = 'spend'
                alert_type = 'synthetic'
                kwargs['alert_type'] = alert_type
                kwargs['dc'] = parse_dc(match.group('trans'))
            elif cur_incident == 'srer_spend_invoice':
                alert_type = 'submit_duration'
                kwargs['alert_type'] = alert_type
                kwargs['dc'] = parse_dc(match.group('trans'))
            elif cur_incident == 'invoice_policy':
                tier = 'invoice'
                kwargs['tier'] = tier
                kwargs['product'] = rms[tier]['product']
                alert_type = 'infrastructure'
                kwargs['alert_type'] = alert_type
                kwargs['dc'] = parse_dc(match.group('trans'))
            elif cur_incident in ['srer_spend', 'srer_spend_eui', 'srer_spend_mgmt_eui', 'srer_clq']:
                kwargs['product'] = rms[match.group('tier').lower()]['product']
                alert_type = 'infrastructure'
                kwargs['alert_type'] = alert_type
                kwargs['dc'] = parse_dc(match.group('trans'))
            elif cur_incident == 'lui':
                kwargs['product'] = rms[match.group('tier').lower()]['product']
                alert_type = 'infrastructure'
                kwargs['alert_type'] = alert_type
                kwargs['dc'] = parse_dc(match.group('trans'))
            elif cur_incident == 'srer_itin':
                kwargs['product'] = rms[match.group('tier').lower()]['product']
                alert_type = 'infrastructure'
                kwargs['alert_type'] = alert_type
                kwargs['dc'] = parse_dc(match.group('trans'))
            elif cur_incident in ['analytics_nr']:
                tier = match.group('tier').lower()
                kwargs['tier'] = tier
                kwargs['product'] = rms[tier]['product']
                kwargs['dc'] = parse_dc(match.group('dc'))
                alert_type = 'cognos'
                kwargs['alert_type'] = alert_type
            elif cur_incident in ['analytics','analytics_bei']:
                tier = 'cognos'
                kwargs['tier'] = tier
                kwargs['product'] = rms[tier]['product']
                alert_type = 'cognos'
                kwargs['alert_type'] = alert_type
            elif cur_incident == 'cognos_opi':
                tier = 'cognos'
                kwargs['tier'] = tier
                kwargs['product'] = rms[tier]['product']
                alert_type = 'opi'
                kwargs['alert_type'] = alert_type
                kwargs['dc'] = "sea"
            elif cur_incident in ['srer_cogwi', 'srer_cogwb']:
                tier = 'cognos'
                kwargs['tier'] = tier
                kwargs['product'] = rms[tier]['product']
                alert_type = 'infrastructure'
                kwargs['alert_type'] = alert_type
                kwargs['dc'] = parse_dc(match.group('trans'))
            elif cur_incident == 'cognos_login':
                tier = 'cognos'
                kwargs['tier'] = tier
                kwargs['product'] = rms[tier]['product']
                alert_type = 'synthetic'
                kwargs['alert_type'] = alert_type
                kwargs['trans'] = match.group('trans')
                kwargs['dc'] = parse_dc(match.group('trans'))
            elif cur_incident in ['expense_imaging', 'expense_imaging_upload']:
                tier = 'imaging'
                kwargs['tier'] = tier
                kwargs['product'] = rms[tier]['product']
                alert_type = 'imaging'
                kwargs['alert_type'] = alert_type
                kwargs['dc'] = parse_dc(match.group('trans'))
            elif cur_incident == 'concur_open':
                tier = 'oui'
                kwargs['tier'] = tier
                kwargs['dc'] = 'usw2'
                kwargs['product'] = rms[tier]['product']
                alert_type = 'page_view'
                kwargs['alert_type'] = alert_type
            elif cur_incident == 'expense':
                tier = 'expense'
                kwargs['tier'] = tier
                kwargs['product'] = rms[tier]['product']
                alert_type = 'expense_error'
                kwargs['alert_type'] = alert_type
                kwargs['trans'] = match.group('trans')
            elif cur_incident == 'outtask_deadlock':
                tier = 'ui'
                kwargs['tier'] = tier
                kwargs['product'] = rms[tier]['product']
                alert_type = 'db'
                kwargs['alert_type'] = alert_type
                kwargs['trans'] = 'outtask_deadlock'
            elif cur_incident == 'tier_alerts':
                kwargs['dc'] = parse_dc(match.group('trans'))
                kwargs['product'] = rms[match.group('tier').lower()]['product']
            elif cur_incident == 'classicpay':
                tier = 'paycl'
                kwargs['tier'] = tier
                kwargs['product'] = rms[tier]['product']
                alert_type = 'healthcheck'
                kwargs['alert_type'] = alert_type
            elif cur_incident == 'css':
                tier = 'css'
                kwargs['tier'] = tier
                kwargs['product'] = rms[tier]['product']
                alert_type = 'infrastructure'
                kwargs['alert_type'] = alert_type
                kwargs['dc'] = parse_dc(match.group('trans'))
            elif cur_incident == 'hmc':
                tier = match.group('tier').lower()
                kwargs['tier'] = tier
                kwargs['product'] = rms[tier]['product']
                alert_type = 'infrastructure'
                kwargs['alert_type'] = alert_type
                kwargs['dc'] = parse_dc(match.group('trans'))
            elif cur_incident == 'imgws':
                tier = match.group('tier').lower()
                kwargs['tier'] = tier
                kwargs['product'] = rms[tier]['product']
                alert_type = 'infrastructure'
                kwargs['alert_type'] = alert_type
                kwargs['dc'] = match.group('dc').lower()
            elif cur_incident == 'ces_prod':
                tier = 'cbatw'
                kwargs['tier'] = tier
                kwargs['product'] = rms[tier]['product']
                alert_type = 'infrastructure'
                kwargs['alert_type'] = alert_type
                kwargs['dc'] = parse_dc(match.group('trans'))
            elif cur_incident == 'gls_couchbase_error':
                kwargs['product'] = rms[match.group('tier').lower()]['product']
                alert_type = 'couchbase_error'
                kwargs['alert_type'] = alert_type
            elif cur_incident == '___no-matches___':
                alert_type = '___no-matches___'
                kwargs['alert_type'] = alert_type
                kwargs['dc'] = parse_dc(match.group('trans'))


            # Classify type of alert: sli, synthetic, watcher, or new_relic
            # Set the appropriate counter base on the alert type for data analysis
            alert_source = 'new_relic'
            if alert_type in ['rpm', 'rt', 'avail', 'error']:
                counter = 'sli_alert_count'
                alert_category = 'sli'
            elif alert_type == 'synthetic':
                counter = 'synthetic_alert_count'
                alert_category = 'synthetic'
            elif service_name == 'CNQR-SM-CTE [Watcher]' or re.search("watcher", service_name, re.IGNORECASE) or re.search("watcher", description, re.IGNORECASE):
                counter = 'watcher_alert_count'
                alert_category = 'watcher'
                alert_source = 'watcher'
            else:
                counter = 'new_relic_alert_count'
                alert_category = 'new_relic'
            kwargs['alert_source'] = alert_source

            # Set the alert classification counter correctly
            # print(f"   [COUNTER] {counter}")
            kwargs[counter] = 1
            kwargs['alert_category'] = alert_category
            break
        # else:
        # print(f"    [NO MATCH] {cur_incident}")
    return kwargs


def parse_manager(query):
    kwargs = {'dow': query.created_on.isoweekday()}
    kwargs = get_region(kwargs, query)
    kwargs = parse_description(kwargs, query.description, query.service_name)
    kwargs = parse_dc_jira(kwargs)
    return kwargs


def main():
    for i in PagerDuty.objects.all():
        query = Incidents.objects.filter(pagerduty_id=i.id)
        if not query:
            continue
        kwargs = parse_manager(query[0].pagerduty_id)
        query.update(**kwargs)


if __name__ == '__main__':
    main()
