import re
import pytz
import json
import requests
from dateutil import parser, relativedelta
from datetime import datetime
from django.utils import timezone
from webapp.models import SRER
from webapp.scripts.add_pagerduty_data import PagerDutyData
from webapp.scripts import logger


class OutstandingAlerts(object):

    def __init__(self):
        self.user = SRER.objects.get(user__username='admin')
        self.headers = {
            'Content-type': 'application/json',
            'Authorization': f'Bearer {self.user.slack_api_token}'
        }
        self.channel_id = 'C0336PD55UG'  # srer-handovers
        self.pd = PagerDutyData()
        self.since = 1

    def nr_incident_status(self, account_id, incident_id):
        url = f'https://frame-alerts.newrelic.com/internal_api/1/accounts/{account_id}/incidents/{incident_id}/violations'
        params = (
            ('only_muted', False),
            ('only_open', False),
            ('per_page_size', 10),
        )
        nr_api_key = getattr(self.user, [ i for i in dir(self.user) if i.split('_')[-1] == account_id][0])
        response = requests.get(url, headers={'Api-Key': nr_api_key}, params=params)
        return response

    def watcher_status(self, datacenter, alert_id):
        pass

    def get_outstanding_alerts(self):
        self.pd.since = timezone.now() - timezone.timedelta(hours=self.since)
        pd_entries = self.pd.fetch_pagerduty_data()
        log_entries = self.pd.fetch_log_entries_data(pd_entries)
        outstanding_alerts = []
        for item in log_entries:
            service = item['first_trigger_log_entry']['agent']['summary']
            incident_details = item['first_trigger_log_entry']['channel']['details']
            if service == 'Watcher':
                if incident_details and 'alert_id' in incident_details:
                    alert_id = incident_details['alert_id']
                    datacenter = None
                    if re.search('sea', alert_id, re.IGNORECASE):
                        datacenter = 'sea'
                    elif re.search('bei', alert_id, re.IGNORECASE):
                        datacenter = 'bei'
                    elif re.search('par', alert_id, re.IGNORECASE):
                        datacenter = 'par'
                    self.watcher_status(datacenter, alert_id)
            elif service == 'New Relic':
                if not incident_details:
                    continue
                account_id = str(incident_details["account_id"])
                incident_id = incident_details["incident_id"]
                nr_status_response = self.nr_incident_status(account_id, incident_id)
                if nr_status_response.reason != 'OK':
                    logging.info(f'{item["id"]} - {nr_status_response.reason}')
                    continue
                if not nr_status_response.json()['violations']:
                    continue
                if nr_status_response.json()['violations'][0]['violationEndTimestamp']:
                    continue
                created_at = pytz.utc.localize(parser.parse(item['created_at']).replace(tzinfo=None))
                outstanding_alerts.append({'id': item['id'], 'title':item['title'], 'created_at': created_at})
        return outstanding_alerts

    def slack_message(self, outstanding_alerts):
        messages = []
        for item in outstanding_alerts:
            pd_url = f'https://sap.pagerduty.com/incidents/{item["id"]}'
            delta = relativedelta.relativedelta(timezone.now(), item['created_at'])
            if delta.minutes:
                created_at = f'{delta.minutes} minutes ago'
            else:
                created_at = f'{delta.seconds} seconds ago'
            messages.append(f'• <{pd_url}|{item["title"].replace(" ", "-")[:60]}>  -  _{created_at}_')

        data = {
            'channel': self.channel_id,
            'text': 'Outstanding Alerts',
            'blocks': [
                {
                    "type": "header",
                    "text": {
                        "type": "plain_text",
                        "text": 'Outstanding Alerts'
                    }
                },
                {
                    "type": "section",
                    "text": {
                        "type": "mrkdwn",
                        "text": '\n'.join(messages)
                    }
                }
            ]
        }
        if not messages:
            data = {
                'channel': self.channel_id,
                'text': 'No Outstanding Alerts :thumbsup:'
            }
        response = requests.post('https://slack.com/api/chat.postMessage', headers=self.headers, data=json.dumps(data))
        return response

    @staticmethod
    def shift_change():
        cst_now = pytz.utc.localize(datetime.utcnow()).astimezone(pytz.timezone('America/Chicago'))
        if cst_now.minute != 0:
            return False
        if cst_now.hour in [2, 10, 18]:
            return True
        return False


def main():
    try:
        alerts = OutstandingAlerts()
        if alerts.shift_change():
            outstanding_alerts = alerts.get_outstanding_alerts()
            alerts.slack_message(outstanding_alerts)
    except Exception as err:
        logging.error(str(err))


logging = logger.config(__file__)
if __name__ == '__main__':
    main()
