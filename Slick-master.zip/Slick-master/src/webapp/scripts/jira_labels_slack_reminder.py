import pytz
import json
import codecs
import requests
from jira import JIRA
from datetime import datetime
from webapp.models import SRER


class OutstandingTickets(object):

    def __init__(self):
        self.channel_id = 'C0124PSGG0Z'  # srer-global
        self.jira_url = 'https://jira.concur.com'
        self.user = SRER.objects.get(user__username='admin')
        self.jira = JIRA(self.jira_url, token_auth=self.user.jira_token)

    def get_jira_tickets(self):
        try:
            return self.jira.search_issues('project = OPI AND issuetype = Incident AND Urgency = P1 '
                                           'AND component = "SRE Runtime" AND created > startOfWeek("-14d") '
                                           'AND (labels not in (QSRER-1-DETECT-SRE-YES, QSRER-1-DETECT-SRE-NO) '
                                           'OR labels is EMPTY)')
        except Exception as err:
            return err

    def get_oncall_user(self, issue):
        created = issue.fields.created.replace('+0000', 'Z')
        headers = {
            'Content-type': 'application/json',
            'Authorization': f'Token token={self.user.pagerduty_token}',
        }
        params = (
            ('since', created),
            ('until', created),
        )
        response = requests.get('https://sap.pagerduty.com/api/v1/schedules/PBW8XDW', headers=headers, params=params)
        user = response.json()['schedule']['final_schedule']['rendered_schedule_entries'][0]['user']['summary']
        return self.jira.search_users(user)[0].emailAddress

    def slack_message(self, tickets):
        headers = {
            'Content-type': 'application/json',
            'Authorization': f'Bearer {self.user.slack_api_token}'
        }
        messages = []
        for item in tickets:
            email = self.get_oncall_user(item)
            _id = requests.get(f'https://slack.com/api/users.lookupByEmail?email={email}', headers=headers).json()['user']['id']
            jira_url = f'https://jira.concur.com/browse/{item.key}'
            messages.append(f'• <{jira_url}| {item.fields.summary[:50]}...> - <@{_id}>')

        data = {
            'channel': self.channel_id,
            'text': 'Friendly Reminder: Tickets without SRER Labels',
            'blocks': [
                {
                    "type": "header",
                    "text": {
                        "type": "plain_text",
                        "text": 'Friendly Reminder: Tickets without SRER Labels'
                    }
                },
                {
                    "type": "section",
                    "text": {
                        "type": "mrkdwn",
                        "text": '\n'.join(messages)
                    }
                }
            ]
        }
        response = requests.post('https://slack.com/api/chat.postMessage', headers=headers, data=json.dumps(data))
        return response

    @staticmethod
    def shift_change():
        cst_now = pytz.utc.localize(datetime.utcnow()).astimezone(pytz.timezone('America/Chicago'))
        if cst_now.minute != 0:
            return False
        if cst_now.hour in [1, 9, 17]:
            return True
        return False


def main():
    alerts = OutstandingTickets()
    if alerts.shift_change():
        tickets = alerts.get_jira_tickets()
        if not isinstance(tickets, Exception) and tickets:
            alerts.slack_message(tickets)


if __name__ == '__main__':
    main()
