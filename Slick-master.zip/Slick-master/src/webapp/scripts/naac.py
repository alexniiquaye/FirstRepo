#!/usr/bin/python3
# -*- coding: utf-8 -*-
# Author: Chen Ye<chen.ye@sap.com>
# Initial Release: 2020/07/28
# NAAC version 2.0 release on 2020/09/28
# NAAC version 2.5 release on 2020/11/27 for Great Performance Boost

import time
import sys
import ssl
import urllib.request
import urllib.parse
import re
import json
import os
import base64
import hashlib
import random
import asyncio

POLICYNAMES = []
POLICYALERTCONDITIONS = {}


class RestAPIOps:

    def formURL(self, url, *args):
        forgedurl = ""
        if len(args) == 1:
            forgedurl = url + '/' + re.sub(r'\s', '%20', args[0])
        elif len(args) == 2:
            if len(args[1].split()) == 1:
                forgedurl = url + "?" + args[0] + args[1]
            else:
                filter = args[0]
                pattern = re.sub(r'\s', '%20', args[1])
                forgedurl = url + "?" + filter + pattern
        elif len(args) == 4:
            forgedurl = url + "?" + args[0] + args[1] + "&" + args[2] + args[3]
        else:
            print("more parameters than expected are provided to function formURL()")
            exit(1)
        return forgedurl

    def composeContent(self, objname, theJSON):
        return json.dumps({objname: theJSON}).encode('utf-8')

    def getRequest(self, url, cred, ops, post_data=None):
        if ops in ["GET", "POST", "PUT", "DELETE"]:
            if post_data is None:
                req = urllib.request.Request(url, method=ops)
            else:
                req = urllib.request.Request(url, method=ops, data=post_data)
                req.add_header('Content-Type', 'application/json')
        else:
            print('Invalid input request method {}, should be "GET", "POST", "PUT", "DELETE"'.format(ops))
            exit(1)
        return req

    def getInsecureResponse(self, req):
        ctx = ssl._create_unverified_context()
        res = urllib.request.urlopen(req, context=ctx)
        return res

    def getReturn(self, url, cred, ops, post_data=None):
        attemps = 0
        success = False
        req = self.getRequest(url, cred, ops, post_data)
        while attemps < 3 and not success:
            try:
                res = self.getInsecureResponse(req)
                success = True
            except:
                returnvalue = sys.exc_info()
                attemps += 1
                time.sleep(random.randrange(5))
                if attemps == 3:
                    print("Error - '{}'".format(returnvalue[1]))
                    break
        strings = res.read().decode('utf-8')
        theJSON = self.loadJSON(strings)
        return theJSON

    def loadJSON(self, strings):
        theJSON = {}
        try:
            theJSON = json.loads(strings)
        except:
            print("Unable to load the file as JSON format, please ensure get and pass the expected strings")
            exit(1)
        return theJSON

    def dumpJSON(self, theJSON, name):
        output = json.dumps(theJSON, indent=2)
        fn = name + '.json'
        with open(fn, 'w') as filehandle:
            for line in output.split('\n'):
                filehandle.write(line + "\n")
        print("From Newrelic site dump alert policy '{}' as file '{}' to localdisk".format(name, fn))

    def refineIndex(self, source, target, theJSON):
        if source != target:
            theJSON[target] = theJSON[source]
        purgelist = list(theJSON.keys())
        purgelist.remove(target)
        while len(purgelist) > 0:
            del theJSON[purgelist[0]]
            purgelist.remove(purgelist[0])

    def consistentOrder(self, theJSON, srtindx, srtstr=''):
        if srtindx in theJSON[list(theJSON.keys())[0]][0]:
            elements = theJSON[list(theJSON.keys())[0]]
            if isinstance(theJSON[list(theJSON.keys())[0]][0][srtindx], list):
                for i in range(len(elements)):
                    listlen = len(theJSON[list(theJSON.keys())[0]][i][srtindx])
                    if srtindx in theJSON[list(theJSON.keys())[0]][i] and listlen > 1:
                        if listlen == len([unit for unit in theJSON[list(theJSON.keys())[0]][i][srtindx] if
                                           isinstance(unit, str) and unit.isdigit() == True]):
                            theJSON[list(theJSON.keys())[0]][i][srtindx] = sorted(
                                theJSON[list(theJSON.keys())[0]][i][srtindx], key=lambda num: int(num))
                        else:
                            theJSON[list(theJSON.keys())[0]][i][srtindx] = sorted(
                                theJSON[list(theJSON.keys())[0]][i][srtindx], key=lambda k: k[srtstr])
            elif isinstance(theJSON[list(theJSON.keys())[0]][0][srtindx], str):
                theJSON[list(theJSON.keys())[0]] = sorted(theJSON[list(theJSON.keys())[0]], key=lambda k: k[srtindx])
            else:
                msg = 'unknown data type neither list nor str, need further debugging might schema changed'
                print(msg)
                exit(1)
        else:
            msg = 'unable to retrive the element ' + srtindx + ' in the json data'
            print(msg)
            exit(1)

    def aggDict(self, srcdict, key, value):
        if len(key) == len(value):
            for i in range(len(key)):
                srcdict[key[i]] = value[i]
        return srcdict

    def shaContent(self, binaryoutput):
        shastr = hashlib.sha1()
        shastr.update(binaryoutput)
        return shastr.hexdigest()

    def parseDiff(self, dict1, dict2):
        diffelement = []
        if list(dict1.keys()) != list(dict2.keys()):
            for key in (dict1.keys() | dict2.keys()) - (dict1.keys() & dict2.keys()):
                if len(dict1.keys()) < len(dict2.keys()):
                    diffelement.append(['+', key])
                else:
                    diffelement.append(['-', key])
        for key in (dict1.keys() & dict2.keys()):
            if dict1[key] != dict2[key]:
                diffelement.append(['', key])
        return diffelement


class AlertPolicy(RestAPIOps):
    tmpstore = []
    idtable = {}

    keyindex = {'policy': {'defname': 'policy', 'nrname': 'policy', 'opsname': 'policy'},
                'channel': {'defname': 'channel', 'nrname': 'channel', 'opsname': 'channel'},
                'apm': {'defname': 'apm_conditions', 'nrname': 'conditions', 'opsname': 'condition'},
                'nrql': {'defname': 'nrql_conditions', 'nrname': 'nrql_conditions', 'opsname': 'nrql_condition'},
                'infra': {'defname': 'infra_conditions', 'nrname': 'data', 'opsname': 'data',
                          'prgattr': ['policy_id', 'created_at_epoch_millis', 'updated_at_epoch_millis']}}

    newrelicurl = {'policy': {'list': {'url': {'https://api.newrelic.com/v2/alerts_policies.json'}, 'ops': {'GET'}},
                              'create': {'url': {'https://api.newrelic.com/v2/alerts_policies.json'}, 'ops': {'POST'}},
                              'update': {'url': {'https://api.newrelic.com/v2/alerts_policies'}, 'ops': {'PUT'}}},
                   'channel': {'list': {'url': {'https://api.newrelic.com/v2/alerts_channels.json'}, 'ops': {'GET'}},
                               'create': {'url': {'https://api.newrelic.com/v2/alerts_policy_channels.json'},
                                          'ops': {'PUT'}},
                               'delete': {'url': {'https://api.newrelic.com/v2/alerts_policy_channels.json'},
                                          'ops': {'DELETE'}}},
                   'apm': {'list': {'url': {'https://api.newrelic.com/v2/alerts_conditions.json'}, 'ops': {'GET'}},
                           'create': {'url': {'https://api.newrelic.com/v2/alerts_conditions/policies'},
                                      'ops': {'POST'}},
                           'delete': {'url': {'https://api.newrelic.com/v2/alerts_conditions'}, 'ops': {'DELETE'}}},
                   'nrql': {
                       'list': {'url': {'https://api.newrelic.com/v2/alerts_nrql_conditions.json'}, 'ops': {'GET'}},
                       'create': {'url': {'https://api.newrelic.com/v2/alerts_nrql_conditions/policies'},
                                  'ops': {'POST'}},
                       'delete': {'url': {'https://api.newrelic.com/v2/alerts_nrql_conditions'}, 'ops': {'DELETE'}}},
                   'infra': {'list': {'url': {'https://infra-api.newrelic.com/v2/alerts/conditions'}, 'ops': {'GET'}},
                             'create': {'url': {'https://infra-api.newrelic.com/v2/alerts/conditions'},
                                        'ops': {'POST'}},
                             'delete': {'url': {'https://infra-api.newrelic.com/v2/alerts/conditions'},
                                        'ops': {'DELETE'}}}}

    def __init__(self, plcname, creds):
        self.plcname = plcname
        self.creds = creds

    def __str__(self):
        return 'Loading Newrelic alert policy "{}"'.format(plcname)

    def getTokens(self):
        pst_index, pst = [], []
        pst_index = [i.start() for i in re.finditer('NR', self.creds)]
        for i in range(len(pst_index)):
            if i < len(pst_index) - 1:
                pst.append(self.creds[pst_index[i]:pst_index[i + 1]])
            else:
                pst.append(self.creds[pst_index[i]:])
        return pst

    def getRequest(self, url, cred, ops, post_data=None):
        self.cred = cred
        req = super().getRequest(url, cred, ops, post_data)
        if re.search(r".*api.newrelic.com.*", url):
            req.add_header('X-Api-Key', self.cred)
        return req

    def getPolicyStuff(self, pst):
        res = (False, '', '', '')
        params = ['filter[name]=', self.plcname, 'filter[exact_match]=', 'true']
        url = self.formURL(list(self.newrelicurl['policy']['list']['url'])[0], *params)
        for st in pst:
            try:
                theJSON = self.getReturn(url, st, ops='GET')
            except:
                continue
            if 'policies' in theJSON and len(theJSON['policies']) != 0:
                res = (True, st, theJSON['policies'][0]['id'], theJSON['policies'][0]['incident_preference'])
                return res
            else:
                continue
        if res[0] == False:
            print("Non exist token provided match with policy name '{}'".format(self.plcname))
        return res

    def detectPolicyExistence(self, defJSONdump):
        existence = False
        defJSON = json.loads(defJSONdump)
        reva = self.probeAPEnv(defJSON)
        if reva[0] == True:
            res = self.getPolicyStuff(reva[1])
        if res[0] == True:
            existence = True
        return existence

    def recrtAlertPolicy(self, defJSONdump):
        defJSON = json.loads(defJSONdump)
        reva = self.probeAPEnv(defJSON)
        if reva[0] == True:
            self.recrtPolicy(reva[1][0], defJSON)
        else:
            print("Non-Exist Mapping for envhash, please ensure the newrelic keys provided are intact")

    def probeAPEnv(self, defJSON):
        reva = (False, '')
        sts = self.getTokens()
        for st in sts:
            if self.shaContent(st.encode('utf-8')) == defJSON['envhash']:
                reva = (True, [st])
        return reva

    def recrtPolicy(self, cred, defJSON):
        key, item, ops, idtable = "policy", "incident_preference", "POST", {}
        diffJSON = self.parseDiff({'envhash': self.shaContent(cred.encode('utf-8'))}, defJSON)
        url = list(self.newrelicurl[key]['create']['url'])[0]
        paddings = {'name': self.plcname, item: defJSON[item]}
        data = self.composeContent(self.keyindex[key]['opsname'], paddings)
        req = self.getRequest(url, cred, ops, data)
        res = self.getInsecureResponse(req)
        rc = res.status
        if not re.search(r'^2\d\d', str(rc)):
            print("Failed to complete {} request for policy create, error code {}".format(ops, rc))
            exit(1)
        theJSON = self.loadJSON(res.read().decode('utf-8'))
        if 'policy' in theJSON and len(theJSON['policy']) != 0:
            idtable['plcid'] = theJSON['policy']['id']
        self.initCreation(cred, idtable, diffJSON, defJSON)
        print("Policy {} creation completed!!!".format(self.plcname))

    def getConditionID(self, theJSON):
        keylist = [self.keyindex['apm']['nrname'], self.keyindex['nrql']['nrname'], self.keyindex['infra']['nrname']]
        for key in keylist:
            if theJSON is not None and key in theJSON:
                self.idtable[key] = []
                for i in range(len(theJSON[key])):
                    if 'id' in theJSON[key][i]:
                        self.idtable[key].append(theJSON[key][i]['id'])

    def getConditions(self, st, plcid, source):
        '''
        Traverse all the indexes and values of JSON outputs to evaluate whether
        there are key:value pairs exist, if there are, return JSON, else return None.
        '''
        theJSON = {}
        if source == self.keyindex['apm']['nrname']:
            url = self.formURL(list(self.newrelicurl['apm']['list']['url'])[0], 'policy_id=', str(plcid))
        elif source == self.keyindex['nrql']['nrname']:
            url = self.formURL(list(self.newrelicurl['nrql']['list']['url'])[0], 'policy_id=', str(plcid))
        elif source == self.keyindex['infra']['nrname']:
            url = self.formURL(list(self.newrelicurl['infra']['list']['url'])[0], 'policy_id=', str(plcid))
        theJSON = self.getReturn(url, st, ops='GET')
        if len(theJSON[list(theJSON.keys())[0]]) == 0:
            theJSON = None
        return theJSON

    def callPageReturns(self, pagenum):
        url = self.formURL(list(self.newrelicurl['channel']['list']['url'])[0], 'page=', str(pagenum))
        theJSON = self.getReturn(url, self.cred, ops='GET')
        for i in range(len(theJSON['channels'])):
            self.tmpstore.append(theJSON['channels'][i])

    @asyncio.coroutine
    def fetchPageCalls(self, loop, item):
        yield from loop.run_in_executor(None, lambda: self.callPageReturns(item))

    def threadingProcess(self, items):
        loop = asyncio.get_event_loop()
        loop.run_until_complete(
            asyncio.wait(
                [self.fetchPageCalls(loop, item) for item in items]
            )
        )

    def getChannelID(self, st, plcid):
        req = self.getRequest(list(self.newrelicurl['channel']['list']['url'])[0], st, ops='GET')
        res = self.getInsecureResponse(req)
        paginationsec = [i[1] for i in res.getheaders() if i[0] == 'Link'][0]
        term = [i for i in re.finditer(r'(?!page=)\d+', paginationsec)][-1]
        lastpage = int(paginationsec[term.start():term.end()])
        channelid = []
        pagelist = [i + 1 for i in range(lastpage)]
        self.threadingProcess(pagelist)
        for channel_entity in self.tmpstore:
            if plcid in channel_entity['links']['policy_ids']:
                channelid.append(channel_entity['id'])
        self.tmpstore.clear()
        channelid = sorted(channelid)
        return channelid

    def refineIndex(self, source, target, theJSON):
        super().refineIndex(source, target, theJSON)
        for i in range(len(theJSON[target])):
            if 'id' in theJSON[target][i]:
                del theJSON[target][i]['id']
        if target == self.keyindex['infra']['defname']:
            for i in range(len(theJSON[self.keyindex['infra']['defname']])):
                for attr in self.keyindex['infra']['prgattr']:
                    if attr in theJSON[target][i]:
                        del theJSON[target][i][attr]

    def parModStore(self, theJSON, index):
        if theJSON is None:
            return
        for key in [k for k in self.keyindex.keys() if self.keyindex[k]['nrname'] == index]:
            if len(theJSON[self.keyindex[key]['nrname']]) != 0:
                self.refineIndex(self.keyindex[key]['nrname'], self.keyindex[key]['defname'], theJSON)
                self.consistentOrder(theJSON, 'name')
                if key == 'apm':
                    self.consistentOrder(theJSON, 'entities')
                if key != 'infra':
                    self.consistentOrder(theJSON, 'terms', 'priority')

    def opsChannelID(self, cred, plcid, channelist, ops):
        for channel in channelist:
            if ops == 'DELETE':
                params = ['policy_id=', str(plcid), 'channel_id=', str(channel)]
                url = self.formURL(list(self.newrelicurl['channel']['delete']['url'])[0], *params)
                req = self.getRequest(url, cred, ops)
            elif ops == 'PUT':
                params = ['policy_id=', str(plcid), 'channel_ids=', str(channel)]
                url = self.formURL(list(self.newrelicurl['channel']['create']['url'])[0], *params)
                req = self.getRequest(url, cred, ops)
                req.add_header('Content-Type', 'application/json')
            res = self.getInsecureResponse(req)
            rc = res.status
            if not re.search(r'^2\d\d', str(rc)):
                print("Failed to complete {} request for channel {} in policyid {}, error code {}".format(ops, channel,
                                                                                                          plcid, rc))

    def initDeletion(self, cred, idtable, diffJSON):
        ops = 'DELETE'
        excptelement = 'incident_preference'
        items = [item[1] for item in diffJSON if item[0] == '-' or item[0] == '']
        # Consider exception for 'incident_preference'
        if len([item for item in items if item == excptelement]) > 0:
            items.remove(excptelement)
        if len(items) > 0:
            for item in items:
                key = [key for key in self.keyindex.keys() if self.keyindex[key]['defname'] == item][0]
                nritem = self.keyindex[key]['nrname']
                if key == 'channel':
                    self.opsChannelID(cred, idtable['plcid'], idtable['channel'], ops)
                    continue
                for cid in idtable[nritem]:
                    if key == 'apm' or key == 'nrql':
                        params = [str(cid) + '.json']
                    elif key == 'infra':
                        params = [str(cid)]
                    url = self.formURL(list(self.newrelicurl[key]['delete']['url'])[0], *params)
                    req = self.getRequest(url, cred, ops)
                    res = self.getInsecureResponse(req)
                    rc = res.status
                    if not re.search(r'^2\d\d', str(rc)):
                        print(
                            "Failed to complete {} request for conditionid {} in policyid {}, error code {}".format(ops,
                                                                                                                    cid,
                                                                                                                    idtable[
                                                                                                                        'plcid'],
                                                                                                                    rc))

    def initCreation(self, cred, idtable, diffJSON, defJSON):
        items = [item[1] for item in diffJSON if item[0] == '+' or item[0] == '-' or item[0] == '']
        if len(items) > 0:
            for item in items:
                ops = 'POST'
                if item == 'incident_preference':
                    key = 'policy'
                else:
                    key = [key for key in self.keyindex.keys() if self.keyindex[key]['defname'] == item][0]
                if key == 'policy':
                    params = [str(idtable['plcid']) + '.json']
                    url = self.formURL(list(self.newrelicurl[key]['update']['url'])[0], *params)
                    paddings = {'name': self.plcname, item: defJSON[item]}
                    data = self.composeContent(self.keyindex[key]['opsname'], paddings)
                    ops = 'PUT'
                    req = self.getRequest(url, cred, ops, data)
                    res = self.getInsecureResponse(req)
                elif key == 'channel':
                    self.opsChannelID(cred, idtable['plcid'], defJSON['channel'], 'PUT')
                    continue
                elif key == 'apm' or key == 'nrql' or key == 'infra':
                    if key == 'apm' or key == 'nrql':
                        params = [str(idtable['plcid']) + '.json']
                        url = self.formURL(list(self.newrelicurl[key]['create']['url'])[0], *params)
                    elif key == 'infra':
                        url = list(self.newrelicurl[key]['create']['url'])[0]
                    for i in range(len(defJSON[item])):
                        if key == 'apm' or key == 'nrql':
                            data = self.composeContent(self.keyindex[key]['opsname'], defJSON[item][i])
                        elif key == 'infra':
                            defJSON['infra_conditions'][i]['policy_id'] = idtable['plcid']
                            data = self.composeContent(self.keyindex[key]['opsname'], defJSON[item][i])
                        req = self.getRequest(url, cred, ops, data)
                        res = self.getInsecureResponse(req)
                        rc = res.status
                        if not re.search(r'^2\d\d', str(rc)):
                            print("Failed to complete {} request for {} in policyid {}, error code {}".format(ops, item,
                                                                                                              idtable[
                                                                                                                  'plcid'],
                                                                                                              rc))


class GitRepo(RestAPIOps):
    githuburl = "https://api.github.concur.com"
    abspath = "repos/SRER/NewrelicAlertsasCode/contents/alertpolicy/"

    def __init__(self, cred, plcname=''):
        self.cred = cred
        self.plcname = plcname

    def getRequest(self, url, cred, ops, post_data=None):
        cred = "token {}".format(cred)
        req = super().getRequest(url, cred, ops, post_data)
        if re.search(r".*api.github.*com.*", url):
            req.add_header('Authorization', cred)
        return req

    def getJSON(self):
        theJSON = {}
        res = (False, theJSON)
        if self.plcname == '':
            abspath = self.abspath
        else:
            abspath = self.abspath + self.plcname + '.json'
        url = self.formURL(self.githuburl, abspath)
        try:
            theJSON = self.getReturn(url, self.cred, ops='GET')
        except:
            print("Unable to find the path your provided '{}' or token provided is invalid, please try again".format(
                self.abspath))
            exit(1)
        if 'content' in theJSON and len(theJSON['content']) != 0:
            res = (True, theJSON)
            return res
        elif len(theJSON) > 0 and 'name' in theJSON[0]:
            res = (True, theJSON)
            return res
        else:
            print("Unable to locate key 'content' in the dict")
            exit(1)

    def dump2file(self, policylist):
        fn = 'alertpolices.txt'
        with open(fn, 'w') as filehandle:
            for policy in policylist:
                filehandle.write(policy + "\n")
        print("Dump all alert policies within Github Repo as file '{}' to localdisk".format(fn))

    def getDecoding(self, theJSON):
        subraw, subtext = r"\n", r"\r|\n$"
        gitcontent = base64.b64decode(re.sub(subraw, '', theJSON['content']))
        raw2text = gitcontent.decode()
        textescp = re.sub(subtext, '', raw2text)
        return textescp


def initateGitClass(cred, plcname=''):
    gits = GitRepo(cred, plcname)
    defJSONRaw = gits.getJSON()[1]
    return defJSONRaw, gits


def initateAPClass(plcname, nrcrd, defJSONdump=None):
    global POLICYALERTCONDITIONS
    ap = AlertPolicy(plcname, nrcrd)
    if defJSONdump is not None and not ap.detectPolicyExistence(defJSONdump):
        print("No Policy {} found creating in progress...".format(ap.plcname))
        ap.recrtAlertPolicy(defJSONdump)
    sts = ap.getTokens()
    reval = ap.getPolicyStuff(sts)
    if reval[0] == False:
        exit(1)
    token, plcid, incpref = reval[1], reval[2], reval[3]
    credboutput = token.encode('utf-8')
    envhash = ap.shaContent(credboutput)
    POLICYALERTCONDITIONS['envhash'] = envhash
    POLICYALERTCONDITIONS['incident_preference'] = incpref
    POLICYALERTCONDITIONS['channel'] = ap.getChannelID(token, plcid)
    keyindex = ap.keyindex
    aplist = [keyindex['apm']['nrname'], keyindex['nrql']['nrname'], keyindex['infra']['nrname']]
    for val in aplist:
        theJSON = ap.getConditions(token, plcid, val)
        ap.getConditionID(theJSON)
        ap.parModStore(theJSON, val)
        if theJSON is not None:
            POLICYALERTCONDITIONS = {**POLICYALERTCONDITIONS, **theJSON}
    ap.aggDict(ap.idtable, ['plcid', 'channel'], [plcid, POLICYALERTCONDITIONS['channel']])
    newrelicdump = json.dumps(POLICYALERTCONDITIONS, indent=2)
    nrboutput = newrelicdump.encode('utf-8')
    newrelicsha = ap.shaContent(nrboutput)
    return newrelicsha, token, ap.idtable, ap


args = sys.argv

if len(args) == 2:
    # Get Policy Name from GitRepo filename
    gitcrd = args[1]
    defJSONRaw, gitobj = initateGitClass(gitcrd)
    for index in range(len(defJSONRaw)):
        name = re.sub(r'\.json$', '', defJSONRaw[index]['name'])
        POLICYNAMES.append(name)
    gitobj.dump2file(sorted(POLICYNAMES))
elif len(args) == 3:
    # Get JSON file from Newrelic site
    plcname, nrcrd = args[1], args[2]
    reval = initateAPClass(plcname, nrcrd)
    reval[3].dumpJSON(POLICYALERTCONDITIONS, plcname)
elif len(args) == 4:
    # Compare and Action based on compare result
    start_time = time.time()
    plcname, nrcrd, gitcrd = args[1], args[2], args[3]

    defJSONRaw, gitobj = initateGitClass(gitcrd, plcname)
    defJSONdump = gitobj.getDecoding(defJSONRaw)
    gitsha = gitobj.shaContent(defJSONdump.encode('utf-8'))
    defJSON = json.loads(defJSONdump)

    reval = initateAPClass(plcname, nrcrd, defJSONdump)
    newrelicsha, token, idtable, apobj = reval[0], reval[1], reval[2], reval[3]
    diffJSON = apobj.parseDiff(POLICYALERTCONDITIONS, defJSON)

    if newrelicsha == gitsha:
        print('Alert policy {} configuration is consistent between Github and Newrelic'.format(plcname))
    else:
        print('Alert policy {} configuration is inconsistent between Github and Newrelic'.format(plcname))
        apobj.initDeletion(token, idtable, diffJSON)
        apobj.initCreation(token, idtable, diffJSON, defJSON)
        print('Alert policy {} configuration successfully reverted to original state'.format(plcname))
    duration = time.time() - start_time
    print(f"Run policy {plcname} completed in {duration} seconds")
else:
    print("Too few or many parameters as inputs only expect 'one', 'two' or 'three' arguments")
    exit(1)
