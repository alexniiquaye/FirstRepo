import os
import random
import string
import argparse
from datetime import datetime, timedelta

from webapp.models import SyntheticAccounts, SRER

from webapp.scripts import logger
from webapp.scripts.synthetics import SyntheticsAPI
from webapp.scripts.concur_cte import ConcurCteAPI
from webapp.scripts.thycotic import ThycoticAPI

from django.utils.timezone import now

synthetics = SyntheticsAPI()
token = secret_id = launcher_id = None
user = SRER.objects.get(user__username='admin')
thycotic = ThycoticAPI(f'concurasp.com\\admin', f'concurasp\\admin', '61646D696E')


def set_newrelic_api(item):
    api_key = getattr(user, f'{item.account.name.lower()}_{item.account.account_id}')
    synthetics.session.headers['Api-Key'] = api_key


def update_synthetics(item, status):
    for monitor in item.monitors.all():
        synthetics.update_monitor_status(monitor.monitor_id, status)
        logging.info(f'{status} synthetic {monitor.name}')


def update_password_cte(item, new_password):
    results = {}
    for email in item.monitors.all().values_list('email', flat=True).distinct():
        try:
            thycotic.command = f'python3 ~/device42.py -u {user.device42_username} -p {user.device42_password} -e {email}'
            current_password = thycotic.ssh(token, secret_id, launcher_id)
            # current_password = device42.get_password(email)
            logging.info(f'current password in device42 for {email} is: {current_password}')
            url = item.monitors.filter(email=email).first().url
            concur_cte = ConcurCteAPI(url, email, current_password)
            try:
                logging.info(f'updating password in {url} for {email} with new password: {new_password}')
                updated = concur_cte.update_password(new_password)
                if isinstance(updated, Exception):
                    results[email] = False
                    logging.warning(f'something went wrong updating password for {email}!', updated)
                elif updated:
                    results[email] = True
                    logging.info(f'password updated successfully in CTE')
                else:
                    results[email] = False
                    logging.warning(f'something went wrong updating password for {email}!')
            except Exception as err:
                results[email] = False
                raise Exception(err)
            finally:
                concur_cte.logout()
        except Exception as err:
            return Exception(str(err), item.name, email)
    return results


def generate_random_password():
    return ''.join(random.sample(string.ascii_letters + string.digits + '!@#$%^&*()_', 16))


def update_password_device42(item, results, new_password):
    for email in item.monitors.all().values_list('email', flat=True).distinct():
        if email in results and results[email]:
            try:
                logging.info(f'updating password in device42 for {email} with new password: {new_password}')
                thycotic.command = f'python3 ~/device42.py -u {user.device42_username} -p {user.device42_password} -e {email} -n {new_password.encode("utf-8").hex()}'
                thycotic.ssh(token, secret_id, launcher_id)
                # device42.update_password(email, new_password)
            except Exception as err:
                logging.error(err, email, new_password)


def update_secure_credential(item, results, new_password):
    for email in item.monitors.all().values_list('email', flat=True).distinct():
        if email in results and not results[email]:
            logging.warning(f'skipped updating secure credential in NewRelic for: {item.name}')
            raise Exception('error!')
    logging.info(f'updating secure credential in synthetics for {item.name} with new password: {new_password}')
    synthetics.set_api_key(item.account.name, item.account.account_id)
    synthetics.update_secure_cred(item.name, new_password)
    item.last_updated = now()
    item.save()


def main(username=None):
    try:
        global token, secret_id, launcher_id, user
        global thycotic
        user = SRER.objects.get(user__username=username)
        thycotic = ThycoticAPI(f'concurasp.com\\{user.device42_username}', f'concurasp\\{user.i_number}', user.device42_password)
        token, secret_id, launcher_id = thycotic.login()
        thycotic.scp(token, secret_id, launcher_id, f'{os.path.dirname(os.path.realpath(__file__))}/device42.py', '~/')

        qs = SyntheticAccounts.objects.all().filter(rotate=True, last_updated__lte=datetime.today() - timedelta(days=1))
        print('\n{:<40s} {:<40s} {}\n{:<40s} {:<40s} {:<25s}\n{:<40s} {:<40s} {}'.format(
            '-'*40, '-'*40, '-'*25, 'SECURE_CRED', 'EMAIL', 'LAST_UPDATED', '-'*40, '-'*40, '-'*25)
        )
        for i in qs:
            for e in i.monitors.all().values_list('email', flat=True).distinct():
                print(f'{i.name[:40]:<40s} {e[:40]:<40s} {i.last_updated.strftime("%c")[:25]:<25s}')

        answer = input("\nWARNING: This will reset password in CTE for above accounts, are you sure you want to continue? (Y/N): ")
        if answer != 'Y':
            logging.warning('Quitting!')
            return None

        for item in qs:
            set_newrelic_api(item)
            update_synthetics(item, 'disabled')

            new_password = generate_random_password()
            results = update_password_cte(item, new_password)
            if isinstance(results, Exception):
                raise Exception(results)

            update_secure_credential(item, results, new_password)
            update_password_device42(item, results, new_password)

            update_synthetics(item, 'enabled')
            logging.info('-' * 100)
    except Exception as err:
        logging.error(err)


def usage():
    parser = argparse.ArgumentParser()
    parser.add_argument('-u', '--username', help='concurasp username. E.g: zain.mohammed')
    args = parser.parse_args()
    return args


logging = logger.config(__file__)
if __name__ == '__main__':
    args = usage()
    main(args.username)
