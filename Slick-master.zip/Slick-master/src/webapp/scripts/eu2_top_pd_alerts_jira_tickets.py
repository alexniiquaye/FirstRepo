import pytz
from jira import JIRA
from datetime import datetime

from webapp.models import *
from django.db.models import Count


class PdTopAlerts(object):

    def __init__(self):
        self.top_alerts_count = 12
        self.jira_url = 'https://jira.concur.com'
        self.user = SRER.objects.get(user__username='admin')
        self.jira = JIRA(self.jira_url, token_auth=self.user.jira_token)
        self.epic = 'SRER-4975'

    def previous_alerts(self):
        offset, limit, issues, alerts = 0, 100, [], []
        while True:
            result = self.jira.search_issues(f'project = "SRER" AND issuetype = Task AND "Epic Link" = {self.epic}', offset, limit)
            issues.extend(result)
            offset += limit
            if len(result) == 0:
                break

        for issue in issues:
            if issue.fields.resolution and issue.fields.resolution.name == 'Canceled':
                continue
            if '[Alert Tuning] ' in issue.fields.summary:
                description = issue.fields.summary.replace('[Alert Tuning] ', '').strip()
                alerts.append(description)
        return alerts

    def filter_duplicates(self, top_alerts):
        _top_alerts = self.previous_alerts()

        duplicate = True
        while duplicate:
            duplicate = False
            for i in top_alerts[:self.top_alerts_count][:]:
                for j in _top_alerts:
                    if j == i['description']:
                        duplicate = True
                        try:
                            top_alerts.remove(i)
                        except ValueError:
                            print(i)
                            pass

        return top_alerts[:self.top_alerts_count]

    def get_top_alerts(self):
        qs = PagerDuty.objects.all().filter(description__icontains='eu2')
        top_alerts = list(qs.values('description').annotate(count=Count('description')).order_by('count').reverse())
        return qs, top_alerts

    def create_jira_ticket(self, qs, top_alerts):
        try:
            for i in top_alerts:
                try:
                    pd_alert = qs.filter(description=i['description']).last().id
                    jira_description = f'''
*Tune Alert:* [{i['description']}|https://sap.pagerduty.com/incidents/{pd_alert}]

*Count:* {i['count']} alerts generated

*Objective:*
 # *Review and Understand the Alerts threshold in reference to past P1s/P2 incidents.* We must have an understanding of how our alerts perform when there is a known P2/P1 outage. Ensure the alerts are tuned in such a way that we can detect an impact in 5-10 minutes before an outage.
 # *Review and Understand why identified alerts are firing even without an outage P2/P1*. Could it be a performance issue at the infra level or application level? How is this alert firing more in one DC than the other? 
 # *Create action items for relevant teams to help improve service and minimize Alerts firing due to performance issues* e.g db performance etc. 

*Instructions on how to tune Alerts:* 
 # Search the alert assigned and update the Violation description of that alert to indicate the ticket raised to tune the specific alert. Be reminded of the correct practice in updating Violation description to not cause impact to observability slo dashboard. [Incident Management Process - SRE CTE Documentation (concur.com).|https://pages.github.concur.com/SRE-CTE-Docs/Docs/incident%20management%20process/#alert-and-dashboard-tuning-process]
 # If the Alert is in ELK, update the Remediation part in Elastic Watcher to include the ticket of the alert tuning. 
 # Review occurrence of the alert identified against any P1 or P2 during the time period. If the alert fired during a known incident, then leave the alert threshold the same. If the alert fired falsely meaning, there is no ongoing P2 or P1, then investigate why the Alert has fired and create action items for relevant/owner teams to take action e.g DB, SRE-SE, etc. *[See Objectives of this ticket]*
 # Identify a P1/P2 incident that the service is affected and compare the performance of the alert threshold during that time.
 # Adjust the Alert threshold to ensure we can detect P2/P1 within 10-15 minutes before start of actual outage. 
 # Review the similar alert in other DCs and Ensure the threshold is standard. If the trend and threshold should be different for other DC, please document and create an action item for RnD to have our data checked and verified correct. 
 # Update the ticket with all the results of the investigation and changes implemented in the alert.
                '''
                    data = {
                        "project": {"key": "SRER"},
                        "issuetype": {"name": "Task"},
                        "summary": f'[Alert Tuning] {i["description"]}',
                        "description": jira_description,
                        "components": [{'name': 'SRE Runtime'}],
                        "assignee": {"name": "__Unassigned"},
                        "customfield_11003": self.epic
                    }
                    issue = self.jira.create_issue(**data)
                    print(issue.key, i["description"])
                except Exception as err:
                    raise Exception(err, i)
        except Exception as err:
            print(err)
            return err

    @staticmethod
    def shift_change():
        cst_now = pytz.utc.localize(datetime.utcnow()).astimezone(pytz.timezone('America/Chicago'))
        if cst_now.minute != 0:
            return False
        if cst_now.hour in [1, 9, 17]:
            return True
        return False


def main():
    pd = PdTopAlerts()
    if pd.shift_change():
        qs, top_alerts = pd.get_top_alerts()
        top_alerts = pd.filter_duplicates(top_alerts)
        pd.create_jira_ticket(qs, top_alerts)


if __name__ == '__main__':
    main()
