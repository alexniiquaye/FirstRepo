from datetime import datetime, timezone
from dateutil.relativedelta import relativedelta
from jira import JIRA
from webapp.models import SRER
from webapp.scripts import logger



class Srer:
    '''Class for creating of srer jira ticket'''
    def __init__(self):
        self.user = SRER.objects.get(user__username='admin')
        self.jira = JIRA('https://jira.concur.com', token_auth=self.user.jira_token)
        self.date_after_month = ((datetime.now(timezone.utc) + relativedelta(months=1))
            .strftime('%Y-%m-%dT%H:%M:%S.000%z'))

    def make_srer_ticket(self,component):
        '''Call jira to create a jira ticket'''
        hops_dict = {
            'project': {'id': 22012},
            'components': [{'name': component}],
            'summary': 'Periodical tools/access checklist',
            'description': '''
Please test a validate the following accesses and ability to operate the respective tools:

BRB, Big Red Button - access and functionality
AWS consoles access - all environments
China VPN access
HMC acess - all environments
Ability to login to AWS US2 and EU2 nodes''',
            'issuetype': {'name': 'Story'},
            'customfield_10572': 0.125
        }
        return self.jira.create_issue(fields=hops_dict)

    def main(self):
        '''Main function for jira ticket creation'''
        teams = {
            'region':[
                {
                    'name': 'SRE Runtime - US',
                    'persons': [ 'ashna.gupta@sap.com','troy.campbell@sap.com',
                        'y.trinh@sap.com','pat.closson@sap.com','zain.mohammed@sap.com' ]
                },
                {
                    'name':'SRE Runtime - EMEA',
                    'persons': [ 'ondrej.baranek@sap.com','juraj.panak@sap.com',
                        'ales.randa@sap.com','j.cizek@sap.com','simon.anderson@sap.com' ]
                },
                {
                    'name':'SRE Runtime - APAC',
                    'persons': [ 'cecil.han@sap.com','chen.ye@sap.com',
                        'mon.jahrenel.placido@sap.com','troy.joseph.emmanuel.raymond.roman@sap.com']
                }
            ]
        }
        logging.info("Creating SRER Story tickets")
        for region in teams['region']:
            for person in region['persons']:
                logging.info(person)
                srer = self.make_srer_ticket(region['name'])
                self.jira.assign_issue(srer, person)
                logging.info(srer.key)
        logging.info('completed!')

def main():
    '''Main :)'''
    srer = Srer()
    srer.main()

logging = logger.config(__file__)
if __name__ == '__main__':
    main()
