#!/usr/bin/env python3

import json
import argparse
import urllib.parse
import urllib.request
from http import cookiejar
from html import unescape


class Device42API(object):

    def __init__(self, username, password, email):
        self.request = urllib.request
        self.username = username
        self.password = password
        self.email = email
        self.base_url = 'https://seadevice4200.concurasp.com'

    def login(self):
        request = self.request.Request(self.base_url)
        response = self.request.urlopen(request)
        data = urllib.parse.urlencode({
            'username': self.username,
            'password': self.password,
            'this_is_the_login_form': 1,
            'csrfmiddlewaretoken': response.info()['Set-Cookie'].split(';')[0].split('=')[1],
            'next': '/admin/',
            'language': 'en'
        }).encode('utf-8')
        request = self.request.Request(f'{self.base_url}/admin/', data, headers={'Referer': self.base_url})
        response = self.request.urlopen(request)
        if 'Log in' in response.read().decode('utf-8'):
            raise Exception('device42 login failed')

    def get_user(self, username):
        try:
            self.request.urlopen(self.request.Request(f'{self.base_url}/api/1.0/get_password_devices'))
        except:
            self.login()

        q = urllib.parse.urlencode({'username': self.email})
        request = self.request.Request(f'{self.base_url}/api/1.0/passwords/?{q}')
        response = self.request.urlopen(request)
        for item in json.loads(response.read().decode('utf-8'))['Passwords']:
            if item['username'] == username:
                return item
        return None

    def get_password(self, username):
        user = self.get_user(username)
        if not user:
            return None
        request = self.request.Request(f'{self.base_url}/admin/rowmgmt/password/passget/{user["id"]}/')
        response = self.request.urlopen(request)
        return unescape(response.read().decode('utf-8'))

    def update_password(self, username, password):
        user = self.get_user(username)
        if not user:
            return None
        print(user['id'])
        data = urllib.parse.urlencode({
            'id': user['id'],
            'password': password
        }).encode('utf-8')
        request = self.request.Request(f'{self.base_url}/api/1.0/passwords/', data)
        response = self.request.urlopen(request)
        return json.loads(response.read().decode('utf-8'))

    def logout(self):
        self.request.urlopen(self.request.Request(f'{self.base_url}/admin/logout/'))


def usage():
    parser = argparse.ArgumentParser()
    parser.add_argument('-u', '--username', required=True, help='device42 username')
    parser.add_argument('-p', '--password', required=True, help='device42 password')
    parser.add_argument('-e', '--email', required=True, help='target email')
    parser.add_argument('-n', '--new_password')
    args = parser.parse_args()
    return args


def main(username, password, email, new_password):
    password = bytes.fromhex(password).decode('utf-8')
    device42 = Device42API(username, password, email)
    try:
        if not new_password:
            print(device42.get_password(email))
        else:
            new_password = bytes.fromhex(new_password).decode('utf-8')
            device42.update_password(email, new_password)
    except Exception as err:
        print(err)
    finally:
        device42.logout()


cookie_jar = cookiejar.CookieJar()
opener = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(cookie_jar))
urllib.request.install_opener(opener)
if __name__ == '__main__':
    args = usage()
    main(args.username, args.password, args.email, args.new_password)
