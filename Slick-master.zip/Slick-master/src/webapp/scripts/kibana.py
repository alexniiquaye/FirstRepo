import json
import urllib3
import requests
from datetime import datetime
from webapp.models import SRER


class KibanaAPI(object):

    def __init__(self):
        urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
        self.user = SRER.objects.get(user__username='admin')
        self.session = requests.Session()
        self.session.headers.update({
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
            'Accept-Encoding': 'gzip, deflate, br',
            'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_6) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/14.0.3 Safari/605.1.15',
            'Accept-Language': 'en-us',
            'Connection': 'keep-alive',
            'kbn-version': '5.6.15',
        })

    def m_search(self, datacenter, query):
        self.session.cookies.update({
            'rack.session': getattr(self.user, f'watcher_session_{datacenter.lower()}'),
        })
        _index = 'main:data-*' if datacenter == 'sea' else '*'
        utc_now = int(datetime.utcnow().timestamp())*1000
        arr = [{
            "index": [_index],
            "ignore_unavailable": True,
        }, {
            "version": True,
            "size": 500,
            "sort": [{
                "@timestamp": {
                    "order": "desc",
                    "unmapped_type": "boolean"
                }
            }],
            "query": {
                "bool": {
                    "must": [{
                        "query_string": {
                            "query": "%s" % query,
                            "analyze_wildcard": True
                        }
                    }, {
                        "range": {
                            "@timestamp": {
                                "gte": utc_now - (3600*1000),
                                "lte": utc_now,
                                "format": "epoch_millis"
                            }
                        }
                    }],
                    "must_not": []
                }
            },
            "_source": {
                "excludes": ["ebs_core_data"]
            },
            "aggs": {
                "2": {
                    "date_histogram": {
                        "field": "@timestamp",
                        "interval": "10s",
                        "time_zone": "UTC",
                        "min_doc_count": 1
                    }
                }
            },
            "stored_fields": ["*"],
            "script_fields": {},
            "docvalue_fields": ["@timestamp", "job_data.end_time", "job_data.start_time", "metric.time", "start_time", "timestamp"],
        }]
        data = ""
        for d in arr:
            data += json.dumps(d) + "\n"

        response = self.session.post(f'https://lp-search-{datacenter}.concur.com/elasticsearch/_msearch', verify=False, data=data)
        return response
