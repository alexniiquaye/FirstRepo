import argparse
import codecs
import json
import requests

from datetime import datetime, timezone
from dateutil.parser import parse
from dateutil.relativedelta import relativedelta

from webapp.models import SRER
from webapp.scripts import logger
from jira import JIRA


class RcaRa(object):

    def __init__(self):
        self.user = SRER.objects.get(user__username='admin')
        self.jira = JIRA('https://jira.concur.com', token_auth=self.user.jira_token)
        self.date_after_month = (datetime.now(timezone.utc) + relativedelta(months=1)).strftime('%Y-%m-%dT%H:%M:%S.000%z')
        self.session = requests.Session()
        self.session.headers = {
            'Content-Type': 'application/json',
            'Accept': 'application/vnd.pagerduty+json;version=2',
            'Authorization': f'Token token={self.user.pagerduty_token}'
        }
        self.pd_base_url = 'https://api.pagerduty.com'
        self.pd_schedule_id = 'PUGQSO5' # CNQR-CTE-SRER-Manager

    def make_rca_ticket(self, p1_ticket):
        hops_dict = {
            'project': {'id': 10570},
            'summary': f'RCA for {p1_ticket.key}: {p1_ticket.fields.summary}',
            'description': 'Please refer to the linked RA ticket for detailed information on the Root Cause Investigation and Corrective/Preventative Actions.\n'
                           'Please contact the assigned Area Principal (RA ticket assignee) directly with any questions.',
            'issuetype': {'name': 'Root-Cause-Analysis'},
            'customfield_10495': self.date_after_month,
            'customfield_12906': {'value': 'Yes'},
        }
        return self.jira.create_issue(fields=hops_dict)

    def make_ra_ticket(self, p1_ticket):
        comp = []
        for i in range(len(p1_ticket.fields.components)):
            name = p1_ticket.fields.components[i].name
            _id = p1_ticket.fields.components[i].id
            comp.append({'id': _id, 'name': name})
        hops_dict = {
            'project': {'id': 10570},
            'components': comp,
            'summary': f'RA: Identify Root Cause for {p1_ticket.key}: {p1_ticket.fields.summary}',
            'description': '''
*Questions:*
1. What is the root cause of the incident? (Dig deep and be as specific/detailed as possible. If unknown, what obstacle(s) prevented you from determining the root cause? A corrective action should be created for each obstacle identified so the root cause may be determined during future incident recurrence.)


2. Provide a *5-Why* analysis below. (The first *why* was created by the Incident Commander to help you get started)


3. What Corrective Action(s)(CA) are necessary for a permanent fix action or temporary workaround to reduce/eliminate the likelihood of incident recurrence? (A CA is expected to be completed within 2 weeks from identification)

[Provide your answer here and use the format below for each CA]

*Action:*
*Reference:* [This is the Jira ticket reference / If one is not available please state and the PM will create one]
*Problem:*
*Due Date:*
*Assignee:*


4. What Preventative Action(s) are necessary because of the incident to improve monitoring, procedures, playbook, incident response, adherence to change process, testing, resource availability, etc.? (Completed within 30-90 days from identification)

[Provide your answer here and use the format below for each PA]

*Action:*
*Reference:*
*Problem:*
*Due Date:*
*Assignee:*


5. Have any single points of failure (SPOF) been identified because of the incident which have not already been identified above? (Technology/People/Process/etc.)

[Provide your answer here. If SPOFs exist, what preventative actions are required to correct the SPOF?]''',
            'issuetype': {'name': 'Service-Request'},
            'customfield_10495': self.date_after_month
        }
        return self.jira.create_issue(fields=hops_dict)

    def main(self, p1_ticket_nr):
        # Reads P1 ticket and returnes dict of this ticket
        # OPI-5221065 - sample P1
        print(f'Reading {p1_ticket_nr}')
        p1_ticket = self.jira.issue(p1_ticket_nr)

        # Get the username of manager from PD that was scheduled at P1 resolution date and use it as RCA assignee.
        # Throw an error if the field is not populated.
        # There should be exactly one unless there was a scheduling error.
        # If none is found then the RCA assignee will be __Unassigned.
        logging.info("Getting currently scheduled Managers from PD ...")
        rca_assignee = '__Unassigned'
        if p1_ticket.fields.resolutiondate is None:
            logging.error('* ERROR: P1 ticket does not have a Resolution date filled')
            return
        p1_resolutiondate = parse(p1_ticket.fields.resolutiondate)
        pd_schedule_since = p1_resolutiondate.strftime('%Y-%m-%dT%H:%M:%S.00Z')
        pd_schedule_until = (p1_resolutiondate + relativedelta(seconds = 1)).strftime('%Y-%m-%dT%H:%M:%S.00Z')
        response = self.session.get(f'{self.pd_base_url}/schedules/{self.pd_schedule_id}/users?since={pd_schedule_since}&until={pd_schedule_until}')
        if response.status_code != requests.codes.ok:
            logging.info(response.text)
            raise Exception(response.reason)
        users = json.loads(response.text)['users']
        if len(users) == 0:
            logging.info("* No users found")
        for user in users:
            logging.info(f'* Found user {user["name"]} ({user["email"]})')
            rca_assignee = user['email']
        logging.info(f'* Using username {rca_assignee}')

        # 2. Create RCA ticket
        logging.info("Creating RCA ticket")
        rca = self.make_rca_ticket(p1_ticket)
        self.jira.assign_issue(rca, rca_assignee)
        logging.info(rca.key)

        # 3. Create RA ticket
        logging.info("Creating RA ticket")
        ra = self.make_ra_ticket(p1_ticket)
        self.jira.assign_issue(ra, '__Unassigned')
        logging.info(ra.key)

        # 4. Link all those tickets together
        #    - P1 causes RCA and RCA is blocked by RA
        logging.info("Linking Issues")
        self.jira.create_issue_link(type='Causes', inwardIssue=p1_ticket.key, outwardIssue=rca.key)
        self.jira.create_issue_link(type='Requires', inwardIssue=rca.key, outwardIssue=ra.key)
        logging.info('completed!')


def usage():
    parser = argparse.ArgumentParser()
    parser.add_argument('-t', '--ticket', help="Provide P1 ticket", required=True, dest='t')
    return parser.parse_args()


def main(p1_ticket_nr):
    rca_ra = RcaRa()
    rca_ra.main(p1_ticket_nr)


logging = logger.config(__file__)
if __name__ == '__main__':
    args = usage()
    main(args.ticket)
