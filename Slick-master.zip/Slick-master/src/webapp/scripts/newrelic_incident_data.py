import re
import pytz
import json
import requests
from datetime import datetime, timedelta

from webapp.models import *
from django.db.models import Max
from django.db import IntegrityError

from webapp.scripts import logger


class NrAiIncidentData(object):

    def __init__(self):
        self.user = SRER.objects.get(user__username='admin')
        self.url = 'https://chartdata.service.newrelic.com/v3/nrql'
        self.headers = {
            'Content-Type': 'application/json',
            'Api-Key': SRER.objects.get(user__username='admin').concur_shared_1280715,
        }
        self.accounts = {
            'Concur_Spend_Management': 1301883,
            'Concur_Travel': 1301884,
            'Concur_Analytics': 1301885,
            'Shared_Platform_Services': 1301887,
            'Concur_Shared': 1280715,
            'Concur_ExpenseIt': 1585757,
            'Concur_Imaging': 1301886,
            'concur_eu2': 3111938,
        }
        self.fields = [i.name for i in NrAiIncident._meta.fields]

    @staticmethod
    def add_to_db(kwargs):
        try:
            NrAiIncident.objects.create(**kwargs)
        except IntegrityError:
            pass
        except Exception as err:
            logging.error(str(err))
            return err

    def get_data(self, since, account_id):
        start = datetime.fromtimestamp(since).strftime('%Y-%m-%d %H:%M:%S')
        end = (datetime.fromtimestamp(since) + timedelta(hours=6)).strftime('%Y-%m-%d %H:%M:%S')
        data = {
            'account_id': account_id,
            'nrql': f"SELECT * FROM NrAiIncident SINCE '{start}' UNTIL '{end}'"
        }
        try:
            response = requests.post(self.url, headers=self.headers, data=json.dumps(data))
            if response.reason != 'OK':
                raise Exception(response.reason)
            total = 0
            if response.json()[0]['series']:
                total = len(response.json()[0]['series'][0]['data'])
                logging.info(f'{data["nrql"]} total')
                if total > 0:
                    since = int(datetime.fromtimestamp(response.json()[0]['series'][0]['data'][-1][0] / 1000).timestamp()) + 1
                else:
                    since = int((datetime.fromtimestamp(since) + timedelta(hours=6)).timestamp())
                columns = response.json()[0]['series'][0]['columns']
                columns = [re.sub('[.\-/]', '_', i) for i in columns]
                for row in response.json()[0]['series'][0]['data']:
                    kwargs = dict(zip(columns, row))
                    for k in list(kwargs.keys()):
                        if k not in self.fields:
                            del kwargs[k]
                    kwargs['timestamp'] = pytz.utc.localize(datetime.fromtimestamp(kwargs['timestamp'] / 1000))
                    if 'aggregationDuration' in kwargs:
                        kwargs['aggregationDuration'] = int(kwargs['aggregationDuration']) if kwargs['aggregationDuration'] else None
                    if 'closeTime' in kwargs:
                        kwargs['closeTime'] = int(kwargs['closeTime']) if kwargs['closeTime'] else None
                    if 'closeViolationsOnExpiration' in kwargs:
                        kwargs['closeViolationsOnExpiration'] = False if kwargs['closeViolationsOnExpiration'] == 'false' else True if kwargs['closeViolationsOnExpiration'] == 'true' else None
                    if 'conditionId' in kwargs:
                        kwargs['conditionId'] = int(kwargs['conditionId']) if kwargs['conditionId'] else None
                    if 'degradationTime' in kwargs:
                        kwargs['degradationTime'] = pytz.utc.localize(datetime.fromtimestamp(kwargs['degradationTime'] / 1000)) if kwargs['degradationTime'] else None
                    if 'durationSeconds' in kwargs:
                        kwargs['durationSeconds'] = int(kwargs['durationSeconds']) if kwargs['durationSeconds'] else None
                    if 'expirationDuration' in kwargs:
                        kwargs['expirationDuration'] = int(kwargs['expirationDuration']) if kwargs['expirationDuration'] else None
                    if 'recoveryTime' in kwargs:
                        kwargs['recoveryTime'] = int(kwargs['recoveryTime']) if kwargs['recoveryTime'] else None
                    if 'violationTimeLimitSeconds' in kwargs:
                        kwargs['violationTimeLimitSeconds'] = int(kwargs['violationTimeLimitSeconds']) if kwargs['violationTimeLimitSeconds'] else None
                    kwargs['incidentId'] = kwargs['incidentId']
                    kwargs['openTime'] = pytz.utc.localize(datetime.fromtimestamp(kwargs['openTime'] / 1000)) if kwargs['openTime'] else None
                    kwargs['openViolationOnExpiration'] = False if kwargs['openViolationOnExpiration'] == 'false' else True if kwargs['openViolationOnExpiration'] == 'true' else None
                    kwargs['policyId'] = int(kwargs['policyId']) if kwargs['policyId'] else None
                    self.add_to_db(kwargs)
            else:
                logging.info(f'{data["nrql"]} total')
                since = int((datetime.fromtimestamp(since) + timedelta(hours=6)).timestamp())
            return since
        except Exception as err:
            return err

    def initial_dump(self):
        NrAiIncident.objects.all().delete()

        for account_name, account_id in self.accounts.items():
            logging.info(account_name)
            data = {
                'account_id': account_id,
                'nrql': 'SELECT count(*) FROM NrAiIncident TIMESERIES SINCE 12 months ago'
            }
            response = requests.post(self.url, headers=self.headers, data=json.dumps(data))
            since, until = None, None
            for i in response.json()[0]['series'][0]['data']:
                if i[1] != 0:
                    since = int(i[0]/1000)
                    until = int(response.json()[0]['series'][0]['data'][-1][0]/1000)
                    break
            if not since or not until:
                continue

            while datetime.fromtimestamp(until) > datetime.fromtimestamp(since):
                data = self.get_data(since, account_id)
                if isinstance(data, Exception):
                    logging.error(str(data))
                    since = since + 1000
                else:
                    since = data

    def update(self):
        until = int(datetime.now().timestamp())
        qs = NrAiIncident.objects.all()
        for account_name, account_id in self.accounts.items():
            logging.info(account_name)
            since = int(qs.filter(account_id=account_id).aggregate(Max('timestamp'))['timestamp__max'].timestamp())
            while datetime.fromtimestamp(until) > datetime.fromtimestamp(since):
                data = self.get_data(since, account_id)
                if isinstance(data, Exception):
                    logging.error(str(data))
                    since = since + 100
                else:
                    since = data


def main():
    nr = NrAiIncidentData()
    nr.update()


logging = logger.config(__file__)
if __name__ == '__main__':
    main()
