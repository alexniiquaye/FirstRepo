import time
import requests

from webapp.scripts import logger
from webapp.scripts import multitasking

from webapp.models import *
from django.db import IntegrityError
from webapp.models import NrAccounts


class NrAlertPolicyChannel(object):

    def __init__(self):
        self.accounts = NrAccounts.objects.all()
        self.base_url = 'https://frame-alerts.newrelic.com/internal_api/1/accounts'
        self.session = requests.Session()
        self.session.headers = {'Api-Key': SRER.objects.get(user__username='admin').concur_shared_1280715}
        self.shared = {}
        self.channel = 'CNQR-SM-CTE'

    @multitasking.task
    def get_request(self, _id, url):
        try:
            response = self.session.get(url)
            if response.reason != 'OK':
                raise Exception(response.reason)
            self.shared[_id] = response.json()
        except Exception as e:
            self.shared[_id] = str(e)

    def get_all_alert_policies(self):
        all_alert_policies = {}
        for item in self.accounts:
            logging.info(f'fetching alert policy summaries for account: {item.name}')
            all_alert_policies[item.account_id] = []
            page = 0
            while True:
                url = f'{self.base_url}/{item.account_id}/policy_summaries?size=50&page={page}&text=&direction=ASC&column=name'
                page += 1
                response = self.session.get(url)
                if response.reason != 'OK':
                    logging.info(response.reason)
                    break
                policies = response.json()['policySummaries']
                if not policies:
                    break
                all_alert_policies[item.account_id].extend(policies)
        return all_alert_policies

    def get_srer_alert_policies(self, all_alert_policies):
        srer_alert_policies = {}
        for item in self.accounts:
            logging.info(f'fetching srer alert policies for account: {item.name}')
            self.shared = {}
            for policy in all_alert_policies[item.account_id]:
                url = f'{self.base_url}/{item.account_id}/policies/{policy["id"]}/load_channels'
                self.get_request(policy["id"], url)
                time.sleep(0.1)
            while len(self.shared.keys()) != len(all_alert_policies[item.account_id]):
                time.sleep(0.1)

            srer_alert_policies[item.account_id] = []
            for policy in all_alert_policies[item.account_id]:
                if isinstance(self.shared[policy['id']], Exception):
                    logging.info(self.shared[policy['id']])
                    continue
                for channel in self.shared[policy['id']]:
                    if channel['name'] == self.channel:
                        srer_alert_policies[item.account_id].append(policy)
                        break
        return srer_alert_policies

    def get_alert_conditions(self, srer_alert_policies):
        for account_id, policies in srer_alert_policies.items():
            self.shared = {}
            for policy in policies:
                url = f'{self.base_url}/{account_id}/policies/{policy["id"]}/conditions?offset=0&size=50'
                self.get_request(policy["id"], url)
                time.sleep(0.1)
            while len(self.shared.keys()) != len(policies):
                time.sleep(0.1)

    def add_to_db(self, srer_alert_policies):
        for item in self.accounts:
            account = NrAccounts.objects.get(account_id=item.account_id)
            logging.info(f'adding to database srer alert policies for account: {item.name}')
            for policy in srer_alert_policies[item.account_id]:
                try:
                    NrAlertPolicies.objects.create(**{
                        'policy_id': policy['id'],
                        'name': policy['name'],
                        'account': account,
                        'channels': self.channel
                    })
                except IntegrityError:
                    pass
                except Exception as err:
                    logging.error(str(err))

    def main(self):
        all_alert_policies = self.get_all_alert_policies()
        srer_alert_policies = self.get_srer_alert_policies(all_alert_policies)
        self.add_to_db(srer_alert_policies)


def main():
    nr = NrAlertPolicyChannel()
    nr.main()


logging = logger.config(__file__)
if __name__ == '__main__':
    main()
