#!/usr/bin/env python3

import os
import sys
import django
import pexpect
import requests
import argparse

proj_path = f'{os.path.dirname(os.path.realpath(__file__))}/../../'
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'Slick.settings')
sys.path.append(proj_path)
django.setup()

from webapp.scripts import logger


class ThycoticAPI(object):

    def __init__(self, username, secret_name, password, thycotic_url=None, dest_server=None, command=None):
        self.username = username
        self.secret_name = secret_name
        self.password = bytes.fromhex(password).decode('utf-8')
        self.base_url = thycotic_url if thycotic_url else 'https://seapr1thycotic.concurasp.com'
        self.machine_name = dest_server if dest_server else 'seapr1bast.concurasp.com'
        self.command = command
        self.session = requests.Session()
        self.session.trust_env = False

    def get_token(self):
        auth_url = f'{self.base_url}/oauth2/token'
        payload = {
            'username': self.username,
            'password': self.password,
            'grant_type': 'password'
        }
        headers = {'Content-Type': 'application/x-www-form-urlencoded'}
        logging.info(f'Authenticating ...')
        response = self.session.post(auth_url, data=payload, headers=headers)
        if response.reason != 'OK':
            logging.error(f'{response.text}')
            sys.exit(1)
        access_token = response.json()['access_token']
        return access_token

    def get_secret_id(self, token):
        auth_header = {'Authorization': 'Bearer ' + token}
        find_url = f'{self.base_url}/api/v1/secrets?filter.includeRestricted=true&filter.searchText={self.secret_name}'
        response = self.session.get(find_url, headers=auth_header)
        if response.reason != 'OK':
            logging.error(f'{response.text}')
            sys.exit(1)
        secret_id = response.json()['records'][0]['id']
        return secret_id

    def secret_checked_in(self, token, secret_id):
        auth_header = {'Authorization': 'Bearer ' + token}
        secret_url = f'{self.base_url}/api/v1/secrets/{str(secret_id)}'
        response = self.session.get(secret_url, headers=auth_header)
        if response.reason != 'OK':
            logging.error(f'Unable to Find Secret. {response.text}')
        checked_out = response.json()['checkedOut']
        return checked_out

    def checout_secret(self, token, secret_id):
        auth_header = {'Authorization': 'Bearer ' + token}
        checkin_url = f'{self.base_url}/api/v1/secrets/{str(secret_id)}/check-in'
        payload = {
            'forceCheckIn': True
        }
        logging.info('Checking out Secret...')
        self.session.post(checkin_url, data=payload, headers=auth_header)

    def get_launcher_id(self, token):
        auth_header = {'Authorization': 'Bearer ' + token}
        launcher_url = f'{self.base_url}/api/v1/launchers'
        response = self.session.get(launcher_url, headers=auth_header)
        if response.reason != 'OK':
            logging.error(f'{response.text}')
            sys.exit(1)
        launcher_id = [i['id'] for i in response.json()['records'] if i['name'] == 'PuTTY'][0]
        return launcher_id

    def get_proxy_info(self, token, secret_id, launcher_id):
        auth_header = {'Authorization': 'Bearer ' + token}
        ssh_proxy_url = f'{self.base_url}/api/v1/secrets/sshproxy'
        payload = {
            'launcherType': launcher_id,
            'machine': self.machine_name,
            'secretId': secret_id
        }
        response = self.session.post(ssh_proxy_url, data=payload, headers=auth_header)
        if response.reason != 'OK':
            logging.error(f'{response.text}')
            sys.exit(1)
        ssh_server, ssh_login, ssh_password = response.json()['host'], response.json()['username'], response.json()['password']
        return ssh_server, ssh_login, ssh_password

    def get_secret_password(self, token, secret_id):
        auth_header = {'Authorization': 'Bearer ' + token}
        secret_url = f'{self.base_url}/api/v1/secrets/{str(secret_id)}'
        response = self.session.get(secret_url, headers=auth_header)
        if response.reason != 'OK':
            logging.error(f'{response.text}')
            sys.exit(1)
        secret_password = [i['itemValue'] for i in response.json()['items'] if i['fieldName'] == 'Password'][0]
        return secret_password

    def scp(self, token, secret_id, launcher_id, source, destination):
        ssh_server, ssh_login, ssh_password = self.get_proxy_info(token, secret_id, launcher_id)
        options = '-F /dev/null -o PreferredAuthentications=keyboard-interactive -o PubkeyAuthentication=no ' \
                  '-oHostKeyAlgorithms=+ssh-rsa -oStrictHostKeyChecking=no -oUserKnownHostsFile=/dev/null'
        scp_cmd = f'scp {options} {source} {ssh_login}@{ssh_server}:{destination}'
        p = pexpect.spawn(scp_cmd, timeout=30)
        p.expect([f"{ssh_login}'s password:"])
        p.sendline(ssh_password)
        p.sendline("\r")
        p.expect(pexpect.EOF)

    def ssh(self, token, secret_id, launcher_id):
        ssh_server, ssh_login, ssh_password = self.get_proxy_info(token, secret_id, launcher_id)
        options = '-F /dev/null -o PreferredAuthentications=keyboard-interactive -o PubkeyAuthentication=no ' \
                  '-oHostKeyAlgorithms=+ssh-rsa -oStrictHostKeyChecking=no -oUserKnownHostsFile=/dev/null'
        if self.command:
            options = f'{options} {self.command}'
        ssh_cmd = f'ssh {ssh_login}@{ssh_server} {options}'
        p = pexpect.spawn(ssh_cmd, timeout=30)
        p.expect([f"{ssh_login}'s password:"])
        p.sendline(ssh_password)
        p.sendline("\r")
        if self.command:
            output = ' '.join(p.read().decode('utf-8').strip().splitlines()[2:]).strip()
            print(output)
            return output
        logging.info('To break the session hit CTRL+D')
        while True:
            p.interact()
            if not p.isalive():
                break

    def login(self):
        token = self.get_token()
        secret_id = self.get_secret_id(token)
        if not self.secret_checked_in(token, secret_id):
            self.checout_secret(token, secret_id)
        launcher_id = self.get_launcher_id(token)
        return token, secret_id, launcher_id


def usage():
    parser = argparse.ArgumentParser()
    parser.add_argument('-u', '--username', help='concurasp username. E.g: concurasp.com\\zain.mohammed')
    parser.add_argument('-s', '--secret_name', help='concurasp secret name. E.g: concurasp\\I541573-u')
    parser.add_argument('-p', '--password', help='Hex encoded password for Device42')
    parser.add_argument('-t', '--thycotic_url', help='Thycotic Server URL', default='https://seapr1thycotic.concurasp.com')
    parser.add_argument('-d', '--dest', help='destination server', default='seapr1bast.concurasp.com')
    parser.add_argument('-c', '--command', help='command', default=None)
    args = parser.parse_args()
    return args


def main(username, secret_name, password, thycotic_url, dest_server, command):
    logging.info(f'thycotic username: {username}')
    logging.info(f'thycotic secret_name: {secret_name}')
    thycotic = ThycoticAPI(username, secret_name, password, thycotic_url, dest_server, command)
    token, secret_id, launcher_id = thycotic.login()
    thycotic.ssh(token, secret_id, launcher_id)


logging = logger.config(__file__)
if __name__ == '__main__':
    args = usage()
    main(args.username, args.secret_name, args.password, args.thycotic_url, args.dest, args.command)
