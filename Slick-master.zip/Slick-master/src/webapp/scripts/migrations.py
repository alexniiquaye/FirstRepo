import os
import gzip
import json
from django.conf import settings
from django.core.management import call_command
from webapp.models import *
from django.db.models import ManyToManyField
from django.core.serializers.json import Serializer


class CustomSerializer(Serializer):
    def end_object(self, obj):
        for field in self.selected_fields:
            if field == 'pk':
                continue
            elif field in self._current.keys():
                continue
            else:
                try:
                    if '__' in field:
                        fields = field.split('__')
                        value = obj
                        for f in fields:
                            value = getattr(value, f)
                        if value != obj:
                            self._current[field] = value
                    else:
                        self._current[field] = getattr(obj, field)
                except AttributeError:
                    pass
        for field in self._current:
            if '__' in field:
                continue
            if isinstance(obj._meta.get_field(field), ManyToManyField):
                self._current[field] = list(getattr(obj, field).all().values_list('name', flat=True))
        super(CustomSerializer, self).end_object(obj)


class Migrations(object):

    def __init__(self):
        self.serializers = CustomSerializer()
        self.serialized_dir = os.path.join(settings.BASE_DIR.parent, 'data/serialized')
        self.limits = {
            'pagerduty': 100
        }
        self.models = [{
            'model': PagerDuty, 'fields': tuple([i.name for i in PagerDuty._meta.fields])
        }, {
            'model': Sources, 'fields': ('name',)
        }, {
            'model': Services, 'fields': ('name', 'product')
        }, {
            'model': Datacenters, 'fields': ('name', 'acronym')
        }, {
            'model': NrAccounts, 'fields': ('account_id', 'name')
        }, {
            'model': NrAlertPolicies, 'fields': ('policy_id', 'name', 'account__acount_id', 'account__name', 'conditions', 'channels')
        }, {
            'model': NrAlertConditions, 'fields': ('name', 'policy__policy_id', 'created_at', 'product', 'description')
        }, {
            'model': NrDashboards, 'fields': ('name', 'datacenter__name', 'account__name', 'role_type', 'url', 'mobile', 'keywords', 'query', 'presentation')
        }, {
            'model': SyntheticMonitors, 'fields': ('monitor_id', 'name', 'account__name', 'datacenter__name', 'email', 'permalink', 'url', 'dashboard')
        }, {
            'model': SyntheticAccounts, 'fields': ('name', 'account__name', 'monitors', 'created_at', 'last_updated', 'rotate')
        }, {
            'model': QuickLinks, 'fields': ('description', 'link', 'datacenter__name', 'service__name', 'source__name', 'keywords')
        }, {
            'model': KnowledgeBase, 'fields': ('document', 'created_at', 'created_by__user__username', 'modified_at', 'modified_by__user__username', 'views', 'tags')
        }, {
            'model': Scripts, 'fields': ('created_by__user__username', 'modified_by__user_username', 'name', 'description', 'created_at', 'modified_at', 'scheduled', 'language')
        }, {
            'model': Events, 'fields': ('script__name', 'description', 'schedule', 'minute', 'hour', 'day', 'months', 'dow', 'status', 'enabled')
        }]

    def dump_data(self):
        for item in self.models:
            model_name = item['model'].__name__.lower()
            objects = item['model'].objects.all()[:self.limits[model_name]] if model_name in self.limits.keys() else item['model'].objects.all()
            print(f'{model_name}: {objects.count()}')
            with gzip.open(os.path.join(self.serialized_dir, f'{model_name}.json.gz'), 'wt', encoding='utf-8') as f:
                data = self.serializers.serialize(objects, fields=item['fields'])
                f.write(data)

    def load_data(self):
        for item in self.models:
            model_name = item['model'].__name__.lower()

            if model_name == 'pagerduty' and item['model'].objects.count() > 0:
                continue

            print(f'updating {model_name}')
            with gzip.open(os.path.join(self.serialized_dir, f'{model_name}.json.gz'), 'r') as f:
                data = json.load(f)

            item['model'].objects.all().delete()
            for i in [i['fields'] for i in data]:
                kwargs = {}
                try:
                    for j in i:
                        if '__' in j:
                            field = '__'.join(j.split('__')[1:])
                            if j == 'user__username':
                                kwargs[j.split('__')[0]] = User.objects.get(**{field: i[j]})
                            elif j == 'datacenter__name':
                                kwargs[j.split('__')[0]] = Datacenters.objects.get(**{field: i[j]})
                            elif j == 'account__name':
                                kwargs[j.split('__')[0]] = NrAccounts.objects.get(**{field: i[j]})
                            elif j == 'policy__policy_id':
                                kwargs[j.split('__')[0]] = NrAlertPolicies.objects.get(**{field: i[j]})
                            elif j == 'service__name':
                                kwargs[j.split('__')[0]] = Services.objects.get(**{field: i[j]})
                            elif j == 'source__name':
                                kwargs[j.split('__')[0]] = Sources.objects.get(**{field: i[j]})
                            elif j == 'created_by__user__username' or j == 'modified_by__user__username':
                                kwargs[j.split('__')[0]] = SRER.objects.get(**{field: i[j]})
                            elif j == 'script__name':
                                kwargs[j.split('__')[0]] = Scripts.objects.get(**{field: i[j]})
                        elif isinstance(item['model']._meta.get_field(j), ManyToManyField):
                            pass
                        else:
                            kwargs[j] = i[j]
                    obj, created = item['model'].objects.update_or_create(**kwargs)
                    for j in i:
                        if '__' in j:
                            continue
                        if isinstance(item['model']._meta.get_field(j), ManyToManyField):
                            getattr(obj, j).add(*([SyntheticMonitors.objects.get(name=k) for k in i[j]]))
                except Exception as err:
                    print(str(err))

    @staticmethod
    def migrate():
        call_command('migrate', interactive=False)


def main():
    migrations = Migrations()
    migrations.migrate()
    migrations.load_data()


if __name__ == '__main__':
    main()
