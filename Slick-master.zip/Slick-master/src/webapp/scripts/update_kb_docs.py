import os
from webapp.models import *
from webapp.scripts import logger


def main():
    try:
        user = SRER.objects.get(user__username='admin')
        docs_dir = 'webapp/static/docs/'
        paths = []
        added, deleted = 0, 0
        for root, dirs, files in os.walk(docs_dir):
            dirs.sort()
            for file in files:
                if file.endswith(".md"):
                    path = os.path.join(root, file).replace(docs_dir, '')
                    if len(path.split('/')) == 1:
                        continue
                    paths.append(path)
                    obj, created = KnowledgeBase.objects.update_or_create(document=path, defaults={'created_by': user})
                    if created:
                        added += 1
                        logging.info(f'adding {path}')
        for i in KnowledgeBase.objects.all():
            if i.document not in paths:
                deleted += 1
                logging.info(f'deleting {i.document}')
                KnowledgeBase.objects.get(pk=i.pk).delete()
        logging.info(f'script completed! {added} added, {deleted} deleted')
    except Exception as err:
        logging.error(str(err))


logging = logger.config(__file__)
if __name__ == '__main__':
    main()
