#!/usr/bin/env python

import re
import sys
import time
import json
import argparse
import requests


class AlertPolicy(object):

    def __init__(self, account_id, api_key, description_to_add):
        self.account_id = account_id
        self.api_key = api_key
        self.description_to_add = description_to_add
        self.url = 'https://api.newrelic.com/graphql'
        self.headers = {
            'content-type': 'application/json',
            'api-key': self.api_key
        }
        self.mappings = {
            'STATIC': 'alertsNrqlConditionStaticUpdate',
            'BASELINE': 'alertsNrqlConditionBaselineUpdate',
            'OUTLIER': 'alertsNrqlConditionOutlierUpdate'
        }
        self.appname_like_re = re.compile(r'appName LIKE \'.*\' (AND|and) ')
        self.appname_equals_re = re.compile(r'appName = \'.*\' (AND|and) ')

    def get_nrql_condition(self, name):
        query = f'''{{
            actor {{
                account(id: {self.account_id}) {{
                    alerts {{
                        nrqlConditionsSearch(searchCriteria: {{name: "{name}"}}) {{
                            nrqlConditions {{
                                id
                                name
                                type
                                description
                                nrql {{
                                    query
                                }}
                            }}
                            totalCount
                        }}
                    }}
                }}
            }}
        }}'''
        data = json.dumps({'query': query})
        try:
            response = requests.post(self.url, headers=self.headers, data=data)
            if response.reason != 'OK':
                raise Exception(response.reason)

            data = response.json()['data']['actor']['account']['alerts']['nrqlConditionsSearch']
            if 'nrqlConditions' not in data:
                raise Exception(response.json())
            elif not data['nrqlConditions']:
                raise Exception('No conditions matched!')
            elif data['totalCount'] != 1:
                raise Exception('More than one condition returned')
            return data['nrqlConditions'][0]
        except Exception as error:
            return error

    def update_nrql_condition(self, name, dryrun=True):
        try:
            condition = self.get_nrql_condition(name)
            if isinstance(condition, Exception):
                raise Exception(condition)
            if self.appname_like_re.search(condition['nrql']['query']):
                app_name = self.appname_like_re.search(condition['nrql']['query']).group().split()[2].replace("'", '')
            elif self.appname_equals_re.search(condition['nrql']['query']):
                app_name = self.appname_equals_re.search(condition['nrql']['query']).group().split()[2].replace("'", '')
            else:
                app_name = condition['description']
            mutation = f'''mutation {{
                update_{condition['id']}: {self.mappings[condition['type']]}(id: {condition['id']}, accountId: {self.account_id}, condition: {{
                    description: "{app_name}, {self.description_to_add}"
                }}) {{
                    id
                    name
                    description
                }}
            }}'''
            print(f'UpdatingAlertPolicy: {condition["name"]} with description "{app_name}, {self.description_to_add}"')

            if not dryrun:
                with open('backup.json', 'a') as f:
                    f.write(json.dumps({'updated_at': int(time.time()), 'data': condition}) + '\n')

                data = json.dumps({'query': mutation})
                response = requests.post('https://api.newrelic.com/graphql',
                                         headers={'content-type': 'application/json', 'api-key': self.api_key},
                                         data=data)
                return response.json()

        except Exception as error:
            print(name, error)


def usage():
    parser = argparse.ArgumentParser()
    parser.add_argument('-f', '--file', help='File containing alert policy names on each line',
                        type=argparse.FileType('r'), required=True)
    parser.add_argument('-a', '--account', help='New Relic account id. eg: 1301884', required=True)
    parser.add_argument('-k', '--apikey', help='User API Key', required=True)
    parser.add_argument('-d', '--description',
                        help='add description to alert policy condition. eg. "Dashboard SLO Trend: https://one.nr/0X8wopEY5Rx"',
                        required=True)
    parser.add_argument('--dryrun', help='only show what is being updated', action='store_true', required=False)
    args = parser.parse_args()
    if not args.dryrun:
        answer = input('WARNING: execute the script with --dryrun option to review changes. '
                       'Do you still want to Continue ? (yes/no): ')
        if answer.lower() != 'yes':
            sys.exit(1)
        print()
    else:
        print('Note: DRY RUN mode, script WILL NOT publish anything. Review changes below:\n')
    return args


def main(account, apikey, description):
    alert_policy = AlertPolicy(account, apikey, description)
    with args.file as file:
        for line in file.readlines():
            name = line.split()[0].strip()
            alert_policy.update_nrql_condition(name, args.dryrun)


if __name__ == '__main__':
    args = usage()
    main(args.account, args.apikey, args.description)
