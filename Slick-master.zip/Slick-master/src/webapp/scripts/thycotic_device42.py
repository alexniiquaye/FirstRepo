#!/usr/bin/env python3

import argparse
from webapp.models import SRER
from webapp.scripts import thycotic


def main(synth_email_address, user=None):
    user = SRER.objects.get(user__username=user)
    secret_name = f'concurasp\\{user.i_number}-u'
    username = f'concurasp.com\\{user.user.username}'
    thycotic_url = 'https://seapr1thycotic.concurasp.com'
    dest_server = 'seapr1bast.concurasp.com'
    command = f'python3 ~/device42.py -u {user.user.username} -p {user.device42_password} -e {synth_email_address}'
    thycotic.main(username, secret_name, user.device42_password, thycotic_url, dest_server, command)


def usage():
    parser = argparse.ArgumentParser()
    parser.add_argument('-e', '--email_address', help="email_address", required=True, dest='e')
    parser.add_argument('-u', '--username', help="SRER username", required=True, dest='u')
    return parser.parse_args()


if __name__ == '__main__':
    args = usage()
    main(args.email_address, args.username)
