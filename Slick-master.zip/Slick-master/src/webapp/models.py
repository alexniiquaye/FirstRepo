import requests

from django.db import models
from django.contrib.auth.models import User
from django.db.models.signals import post_save
from django.dispatch import receiver
from django.utils.timezone import now
from mirage.fields import EncryptedCharField, EncryptedTextField


class PagerDuty(models.Model):
    id = models.CharField(primary_key=True, max_length=50)
    acknowledge_count = models.IntegerField()
    assignment_count = models.IntegerField()
    auto_escalation_count = models.IntegerField()
    auto_resolved = models.IntegerField()
    created_on = models.DateTimeField()
    description = models.CharField(max_length=500, null=True, blank=True)
    escalation_count = models.IntegerField()
    escalation_policy_id = models.CharField(max_length=50, null=True, blank=True)
    escalation_policy_name = models.CharField(max_length=100, null=True, blank=True)
    incident_number = models.IntegerField(unique=True)
    resolved_by_user_id = models.CharField(max_length=50, null=True, blank=True)
    resolved_by_user_name = models.CharField(max_length=100, null=True, blank=True)
    resolved_on = models.DateTimeField()
    seconds_to_first_ack = models.CharField(max_length=50, null=True, blank=True)
    seconds_to_resolve = models.CharField(max_length=50, null=True, blank=True)
    service_id = models.CharField(max_length=50, null=True, blank=True)
    service_name = models.CharField(max_length=100, null=True, blank=True)
    urgency = models.CharField(max_length=50, null=True, blank=True)

    def __str__(self):
        return str(self.id)

    class Meta:
        verbose_name = 'PagerDuty'
        verbose_name_plural = 'PagerDuty'


class Jira(models.Model):
    key = models.CharField(unique=True, max_length=50)
    summary = models.CharField(max_length=500, null=True, blank=True)
    issuetype = models.CharField(max_length=50, null=True, blank=True)
    priority = models.CharField(max_length=50, null=True, blank=True)
    project = models.CharField(max_length=50, null=True, blank=True)
    components = models.TextField()
    status = models.CharField(max_length=50, null=True, blank=True)
    resolution = models.CharField(max_length=50, null=True, blank=True)
    description = models.CharField(max_length=5000, null=True, blank=True)
    assignee = models.CharField(max_length=100, null=True, blank=True)
    reporter = models.CharField(max_length=100, null=True, blank=True)
    created = models.DateTimeField(null=True, blank=True)
    updated = models.DateTimeField(null=True, blank=True)
    resolved = models.DateTimeField(null=True, blank=True)  # resolutiondate
    urgency = models.CharField(max_length=50, null=True, blank=True)  # customfield_11303
    severity = models.CharField(max_length=50, null=True, blank=True)  # customfield_10010
    alarm_source = models.CharField(max_length=50, null=True, blank=True)  # customfield_12904
    datacenter = models.CharField(max_length=50, null=True, blank=True)  # customfield_10836
    after_the_fact = models.CharField(max_length=50, null=True, blank=True)  # customfield_12534
    incident_start_date = models.DateTimeField(null=True, blank=True)  # customfield_10493
    actual_start = models.DateTimeField(null=True, blank=True)  # customfield_10842
    actual_end = models.DateTimeField(null=True, blank=True)  # customfield_10844
    alarm_start = models.DateTimeField(null=True, blank=True)  # customfield_12905

    def __str__(self):
        return str(self.key)


class Incidents(models.Model):
    pagerduty_id = models.OneToOneField(PagerDuty, on_delete=models.CASCADE, primary_key=True)
    jira_id = models.OneToOneField(Jira, on_delete=models.CASCADE, blank=True, null=True)
    datacenter = models.CharField(max_length=50, blank=True, null=True)
    nr_account_name = models.CharField(max_length=50, blank=True, null=True)
    nr_account_id = models.IntegerField(blank=True, null=True)
    nr_condition_name = models.CharField(max_length=150, blank=True, null=True)
    nr_policy_name = models.CharField(max_length=150, blank=True, null=True)
    nr_targets = models.TextField(blank=True, null=True)
    nr_incident_id = models.IntegerField(blank=True, null=True)
    watcher_alert_id = models.CharField(max_length=150, blank=True, null=True)
    email_body = models.TextField(blank=True, null=True)
    region = models.CharField(max_length=50, blank=True, null=True)
    product = models.CharField(max_length=50, blank=True, null=True)
    tier = models.CharField(max_length=50, blank=True, null=True)
    dc = models.CharField(max_length=50, blank=True, null=True)
    alert_source = models.CharField(max_length=50, blank=True, null=True)
    trans = models.CharField(max_length=150, blank=True, null=True)
    alert_type = models.CharField(max_length=50, blank=True, null=True)
    alert_category = models.CharField(max_length=50, blank=True, null=True)
    sli_trans = models.CharField(max_length=150, blank=True, null=True)
    regex_key = models.CharField(max_length=100, blank=True, null=True)
    sli_alert_count = models.IntegerField(blank=True, null=True)
    synthetic_alert_count = models.IntegerField(blank=True, null=True)
    watcher_alert_count = models.IntegerField(blank=True, null=True)
    new_relic_alert_count = models.IntegerField(blank=True, null=True)
    dow = models.IntegerField(blank=True, null=True)
    jira_dc = models.CharField(max_length=50, blank=True, null=True)

    def __str__(self):
        return str(self.pagerduty_id)

    class Meta:
        verbose_name = 'Incident'
        verbose_name_plural = 'Incidents'


class NewRelic(models.Model):
    acknowledge_count = models.IntegerField()
    assignment_count = models.IntegerField()
    auto_escalation_count = models.IntegerField()
    auto_resolved = models.IntegerField()
    created_on = models.DateTimeField()
    description = models.CharField(max_length=500, null=True, blank=True)
    escalation_count = models.IntegerField()
    escalation_policies_deleted_on = models.CharField(max_length=10, null=True, blank=True)
    escalation_policy_id = models.CharField(max_length=50, null=True, blank=True)
    escalation_policy_name = models.CharField(max_length=100, null=True, blank=True)
    newrelic_id = models.CharField(max_length=50, null=True, blank=True)
    incident_key = models.CharField(max_length=100, null=True, blank=True)
    incident_number = models.IntegerField()
    last_trigger_event_occurred_at = models.DateTimeField()
    resolved_by_user_deleted_on = models.CharField(max_length=50, null=True, blank=True)
    resolved_by_user_id = models.CharField(max_length=50, null=True, blank=True)
    resolved_by_user_name = models.CharField(max_length=100, null=True, blank=True)
    resolved_on = models.DateTimeField(null=True, blank=True)
    seconds_to_first_ack = models.CharField(max_length=50, null=True, blank=True)
    seconds_to_resolve = models.IntegerField()
    service_deleted_on = models.CharField(max_length=50, null=True, blank=True)
    service_id = models.CharField(max_length=50, null=True, blank=True)
    service_name = models.CharField(max_length=100, null=True, blank=True)
    urgency = models.CharField(max_length=50, null=True, blank=True)

    def __str__(self):
        return self.incident_number


class NrAiIncident(models.Model):
    incidentId = models.CharField(max_length=50)
    timestamp = models.DateTimeField()
    account_id = models.IntegerField(null=True, blank=True)
    aggregationDuration = models.IntegerField(null=True, blank=True)
    closeCause = models.CharField(max_length=50, null=True, blank=True)
    closeTime = models.BigIntegerField(null=True, blank=True)
    closeViolationsOnExpiration = models.BooleanField(null=True, blank=True)
    conditionId = models.IntegerField(null=True, blank=True)
    conditionName = models.CharField(max_length=100, null=True, blank=True)
    degradationTime = models.DateTimeField(null=True, blank=True)
    description = models.CharField(max_length=500, null=True, blank=True)
    durationSeconds = models.IntegerField(null=True, blank=True)
    entity_guid = models.CharField(max_length=100, null=True, blank=True)
    evaluationOffsetSeconds = models.CharField(max_length=50, null=True, blank=True)
    evaluationType = models.CharField(max_length=50, null=True, blank=True)
    event = models.CharField(max_length=50, null=True, blank=True)
    expirationDuration = models.IntegerField(null=True, blank=True)
    muted = models.BooleanField(null=True, blank=True)
    nrqlEventType = models.CharField(max_length=50, null=True, blank=True)
    nrqlQuery = models.CharField(max_length=500, null=True, blank=True)
    openTime = models.DateTimeField()
    openViolationOnExpiration = models.BooleanField(null=True, blank=True)
    operator = models.CharField(max_length=5, null=True, blank=True)
    policyId = models.IntegerField(null=True, blank=True)
    policyName = models.CharField(max_length=100, null=True, blank=True)
    priority = models.CharField(max_length=50, null=True, blank=True)
    recoveryTime = models.BigIntegerField(null=True, blank=True)
    targetName = models.CharField(max_length=100, null=True, blank=True)
    threshold = models.CharField(max_length=100, null=True, blank=True)
    thresholdDuration = models.CharField(max_length=100, null=True, blank=True)
    thresholdOccurrences = models.CharField(max_length=50, null=True, blank=True)
    title = models.CharField(max_length=250, null=True, blank=True)
    type = models.CharField(max_length=50, null=True, blank=True)
    valueFunction = models.CharField(max_length=50, null=True, blank=True)
    violationTimeLimitSeconds = models.IntegerField(null=True, blank=True)
    runbookUrl = models.CharField(max_length=250, null=True, blank=True)
    entity_name = models.CharField(max_length=50, null=True, blank=True)
    entity_type = models.CharField(max_length=50, null=True, blank=True)
    mutingRuleId = models.CharField(max_length=50, null=True, blank=True)
    mutingRuleName = models.CharField(max_length=50, null=True, blank=True)
    violationUuId = models.CharField(max_length=50, null=True, blank=True)
    signalId = models.CharField(max_length=50, null=True, blank=True)

    def __str__(self):
        return str(self.incidentId)

    class Meta:
        unique_together = ('timestamp', 'incidentId', 'event')


class NrAccounts(models.Model):
    name = models.CharField(max_length=50)
    account_id = models.IntegerField(unique=True)

    def __str__(self):
        return str(self.name)


class NrAlertPolicies(models.Model):
    policy_id = models.IntegerField()
    name = models.CharField(max_length=100)
    account = models.ForeignKey(NrAccounts, on_delete=models.CASCADE)
    conditions = models.IntegerField(blank=True, null=True)
    channels = models.CharField(max_length=250)

    def __str__(self):
        return str(self.name)


class NrAlertConditions(models.Model):
    name = models.CharField(max_length=100)
    policy = models.ForeignKey(NrAlertPolicies, on_delete=models.CASCADE)
    created_at = models.DateTimeField()
    product = models.CharField(max_length=50)
    description = models.CharField(max_length=250, blank=True, null=True)

    def __str__(self):
        return str(self.name)


class SRER(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    i_number = models.CharField(max_length=50, blank=True, null=True)
    region = models.CharField(max_length=30, choices=(('US', 'US'), ('EMEA', 'EMEA'), ('APAC', 'APAC')))
    pagerduty_token = EncryptedCharField(blank=True, null=True)
    pagerduty_id = EncryptedCharField(blank=True, null=True)
    concur_spend_management_1301883 = EncryptedCharField(blank=True, null=True)
    concur_travel_1301884 = EncryptedCharField(blank=True, null=True)
    concur_shared_1280715 = EncryptedCharField(blank=True, null=True)
    concur_analytics_1301885 = EncryptedCharField(blank=True, null=True)
    shared_platform_services_1301887 = EncryptedCharField(blank=True, null=True)
    concur_integration_2596260 = EncryptedCharField(blank=True, null=True)
    prod_uspscc_hsm_2439350 = EncryptedCharField(blank=True, null=True)
    concur_imaging_1301886 = EncryptedCharField(blank=True, null=True)
    concur_us2_3111936 = EncryptedCharField(blank=True, null=True)
    concur_eu2_3111938 = EncryptedCharField(blank=True, null=True)
    jira_token = EncryptedCharField(blank=True, null=True)
    slack_api_token = EncryptedCharField(blank=True, null=True)
    device42_username = models.CharField(max_length=80, blank=True, null=True)
    device42_password = EncryptedCharField(blank=True, null=True)
    github_token = EncryptedCharField(blank=True, null=True)
    watcher_session_sea = EncryptedTextField(blank=True, null=True)
    watcher_session_par = EncryptedTextField(blank=True, null=True)
    watcher_session_beipr1 = EncryptedTextField(blank=True, null=True)
    aviary_api = EncryptedCharField(blank=True, null=True)

    def __str__(self):
        return self.user.username

    class Meta:
        verbose_name = 'SRER User'
        verbose_name_plural = 'SRER Users'


class Datacenters(models.Model):
    name = models.CharField(max_length=50)
    acronym = models.CharField(max_length=5)

    def __str__(self):
        return str(self.name)


class Services(models.Model):
    name = models.CharField(max_length=50)
    product = models.CharField(max_length=50)

    def __str__(self):
        return str(self.name)


class Sources(models.Model):
    name = models.CharField(max_length=50)

    def __str__(self):
        return str(self.name)


class NrDashboards(models.Model):
    name = models.CharField(max_length=50, unique=True)
    datacenter = models.ForeignKey(Datacenters, on_delete=models.CASCADE)
    account = models.ForeignKey(NrAccounts, on_delete=models.CASCADE)
    role_type = models.CharField(max_length=50, null=True, blank=True)
    url = models.URLField(max_length=200)
    mobile = models.BooleanField(default=False)
    keywords = models.CharField(max_length=50, null=True, blank=True)
    query = models.TextField()
    presentation = models.TextField()

    def __str__(self):
        return str(self.name)


class SyntheticMonitors(models.Model):
    monitor_id = models.UUIDField(unique=True)
    name = models.CharField(max_length=80)
    account = models.ForeignKey(NrAccounts, on_delete=models.CASCADE)
    datacenter = models.ForeignKey(Datacenters, on_delete=models.CASCADE)
    email = models.CharField(max_length=50, null=True, blank=True)
    permalink = models.CharField(max_length=50)
    url = models.URLField(max_length=200)
    dashboard = models.ManyToManyField(NrDashboards)

    def __str__(self):
        return str(self.name)

    class Meta:
        verbose_name_plural = "SyntheticMonitors"


class SyntheticAccounts(models.Model):
    name = models.CharField(max_length=30, unique=True)
    account = models.ForeignKey(NrAccounts, on_delete=models.CASCADE)
    monitors = models.ManyToManyField(SyntheticMonitors)
    created_at = models.DateTimeField(null=True, blank=True)
    last_updated = models.DateTimeField(null=True, blank=True)
    rotate = models.BooleanField(default=True)

    def __str__(self):
        return str(self.name)

    class Meta:
        verbose_name_plural = "SyntheticAccounts"


class QuickLinks(models.Model):
    description = models.CharField(max_length=150)
    link = models.CharField(max_length=150)
    datacenter = models.ForeignKey(Datacenters, on_delete=models.CASCADE)
    service = models.ForeignKey(Services, on_delete=models.CASCADE)
    source = models.ForeignKey(Sources, on_delete=models.CASCADE)
    keywords = models.CharField(max_length=250)

    def __str__(self):
        return f'{self.datacenter}: {self.service} - {self.description}'

    class Meta:
        verbose_name_plural = "QuickLinks"


class KnowledgeBase(models.Model):
    document = models.CharField(max_length=255, unique=True)
    created_at = models.DateTimeField(default=now)
    created_by = models.ForeignKey(SRER, on_delete=models.CASCADE)
    modified_at = models.DateTimeField(blank=True, null=True)
    modified_by = models.ForeignKey(SRER, on_delete=models.CASCADE, blank=True, null=True, related_name='kb_modified_by')
    views = models.IntegerField(default=0)
    tags = models.TextField(null=True)

    def __str__(self):
        return str(self.document)


class KBLikes(models.Model):
    liked_at = models.DateTimeField(default=now)
    user = models.ForeignKey(SRER, on_delete=models.CASCADE)
    document = models.ForeignKey(KnowledgeBase, on_delete=models.CASCADE)

    class Meta:
        unique_together = ('user', 'document',)

    def __str__(self):
        return str(self.document)


class KBComments(models.Model):
    comment = models.TextField()
    document = models.ForeignKey(KnowledgeBase, on_delete=models.CASCADE)
    created_at = models.DateTimeField(default=now)
    user = models.ForeignKey(SRER, on_delete=models.CASCADE)
    likes = models.IntegerField(default=0)

    def __str__(self):
        return str(self.document)


class Scripts(models.Model):
    name = models.CharField(max_length=70, unique=True)
    description = models.CharField(max_length=255, blank=True, null=True)
    created_at = models.DateTimeField(default=now)
    created_by = models.ForeignKey(SRER, on_delete=models.CASCADE)
    modified_at = models.DateTimeField(blank=True, null=True)
    modified_by = models.ForeignKey(SRER, on_delete=models.CASCADE, blank=True, null=True, related_name='scripts_modified_by')
    scheduled = models.BooleanField(default=False)
    language = models.CharField(max_length=15, default='python')

    def __str__(self):
        return str(self.name)


class Jobs(models.Model):
    script = models.ForeignKey(Scripts, on_delete=models.CASCADE)
    start = models.DateTimeField(default=now)
    end = models.DateTimeField(blank=True, null=True)
    duration = models.FloatField(blank=True, null=True)
    executed_by = models.ForeignKey(SRER, on_delete=models.CASCADE)
    result = models.CharField(max_length=20, choices=(('SUCCESS', 'SUCCESS'), ('FAILED', 'FAILED')), blank=True, null=True)
    output = models.TextField(blank=True, null=True)

    def __str__(self):
        return str(self.script)


class Events(models.Model):
    name = models.CharField(max_length=250, blank=True, null=True)
    script = models.ForeignKey(Scripts, on_delete=models.CASCADE)
    schedule = models.CharField(max_length=100)
    minute = models.CharField(max_length=250, default=f'{set(range(0, 60))}', editable=False)
    hour = models.CharField(max_length=110, default=f'{set(range(0, 24))}', editable=False)
    day = models.CharField(max_length=120, default=f'{set(range(1, 32))}', editable=False)
    months = models.CharField(max_length=50, default=f'{set(range(1, 13))}', editable=False)
    dow = models.CharField(max_length=25, default=f'{set(range(0, 7))}', editable=False)
    status = models.CharField(max_length=20, choices=(('RUNNING', 'RUNNING'), ('IDLE', 'IDLE')), default='IDLE', editable=False)
    enabled = models.BooleanField(default=False)

    def __str__(self):
        return str(self.script)

    class Meta:
        verbose_name = 'Events'
        verbose_name_plural = 'Events'


@receiver(post_save, sender=Events)
def save_schedule(sender, instance, **kwargs):
    minute, hour, day, month, dow = instance.schedule.split()
    kwargs = {}
    if '/' in minute:
        kwargs['minute'] = f'{set(range(0, 60, int(minute.split("/")[-1])))}'
    elif '*' not in minute:
        kwargs['minute'] = '{%s}' % minute
    if '-' in hour:
        kwargs['hour'] = f'{set(range(int(hour.split("-")[0]), int(hour.split("-")[1])))}'
    elif '*' not in hour:
        kwargs['hour'] = '{%s}' % hour
    if '-' in day:
        kwargs['day'] = f'{set(range(int(day.split("-")[0]), int(day.split("-")[1]) + 1))}'
    elif '*' not in day:
        kwargs['day'] = '{%s}' % day
    if '-' in month:
        kwargs['month'] = f'{set(range(int(month.split("-")[0]), int(month.split("-")[1]) + 1))}'
    elif '*' not in month:
        kwargs['month'] = '{%s}' % month
    if '-' in dow:
        kwargs['dow'] = f'{set(range(int(dow.split("-")[0]) - 1, int(dow.split("-")[1])))}'
    elif '*' not in dow:
        kwargs['dow'] = '{%s}' % dow
    Events.objects.filter(pk=instance.pk).update(**kwargs)


@receiver(post_save, sender=User)
def create_user_profile(sender, instance, created, **kwargs):
    if created:
        if instance.username == 'admin':
            SRER.objects.create(user=instance, region='US')
        else:
            slack_headers = {
                'Content-type': 'application/json',
                'Authorization': f'Bearer {SRER.objects.get(user__username="admin").slack_api_token}'
            }
            response = requests.get(f'https://slack.com/api/users.lookupByEmail?email={instance.email}', headers=slack_headers).json()['user']
            i_number = response['name']
            region = 'EMEA' if 'Europe' in response['tz'] else 'APAC' if 'Asia' in response['tz'] else 'US'
            SRER.objects.create(user=instance, i_number=i_number, region=region)


@receiver(post_save, sender=PagerDuty)
def create_incident(sender, instance, created, **kwargs):
    if created:
        Incidents.objects.create(pagerduty_id=instance)
