from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from django.contrib.auth import authenticate, login, logout
from django.db.models import Count, Avg
from webapp.api import get_pd_services
from webapp.models import *
from django.http import HttpResponse
import json

from datetime import datetime
from collections import Counter


def login_view(request):
    if request.method == 'POST':
        try:
            username = request.POST.get('username', None)
            password = request.POST.get('password', None)
            user = authenticate(username=username, password=password)
            if user:
                login(request, user)
                return redirect(first_responder)
        except Exception as error:
            print(error)
    return render(request, 'webapp/login.html', {})


def logout_view(request):
    logout(request)
    return redirect(dashboard)


def health(request):
    return HttpResponse('OK')


def dashboard(request):
    return render(request, 'webapp/dashboard.html', {})


def newrelic_incidents_data(request):
    return render(request, 'webapp/newrelic-incidents-data.html', {})


def newrelic_alert_policies(request):
    return render(request, 'webapp/newrelic-alert-policies.html', {})


def synthetic_accounts(request):
    qs = SyntheticAccounts.objects.prefetch_related('monitors').all()
    monitors = SyntheticMonitors.objects.all()
    return render(request, 'webapp/synthetic-accounts.html', {'qs': qs, 'monitors': monitors})


@login_required(login_url='/login')
def first_responder(request):
    return render(request, 'webapp/first-responder.html', {})


@login_required(login_url='/login')
def changes_in_progress(request):
    default_query = '''(status = "In Progress" AND project = "Operations Service Management" AND "Data Center" in ("Lynnwood - Com", "Paris - Com", China, "US Gov West") AND "Affected Service(s)." in (Travel, Expense, Invoice, Mobile) AND updated >= -24h) OR (issueFunction IN parentsof("cf[19405] = 'External Communication'") AND status = 'Pending Approval' AND Key NOT IN (OPI-5265819, OPI-5423471) AND (component not in (Government-Service-Delivery) OR component is EMPTY) AND "Data Center" not in ("Lynnwood - CGE Prev", "Lynnwood - CGE Stable", "Lynnwood - Impl", "Paris - Impl") AND "Request Type" in ("Change Requiring downtime (impacting outage)", "OS Upgrade (version)/Upgrade of DBMS")) ORDER BY updated'''
    return render(request, 'webapp/changes-in-progress.html', {'default_query': default_query})


def change_history(request):
    return render(request, 'webapp/change-history.html', {})


def quick_links(request):
    qs = QuickLinks.objects.all()
    products = qs.values_list('service__product', flat=True).distinct()
    products_count = qs.values('service__product', 'datacenter__name').annotate(count=Count('service__product'))
    return render(request, 'webapp/quick-links.html', {'qs': qs, 'products': products, 'products_count': products_count})


def synthetics_health(request):
    return render(request, 'webapp/synthetics-health.html', {})


def knowledge_base(request):
    qs = KnowledgeBase.objects.all().prefetch_related()

    articles = dict(Counter(([i.document.split('/')[0] for i in KnowledgeBase.objects.all() if
                              i.document.split('/')[-1].lower() != 'index.md' and 'description' not in i.document.split('/')[-1]])))

    for k, v in articles.items():
        articles[k] = {'count': v, 'docs': []}

    for k, v in articles.items():
        for i in KnowledgeBase.objects.all():
            document = i.document.split('/')
            if document[0] == k:
                if document[-1].lower() != 'index.md' and 'description.md' not in document[-1].lower():
                    articles[k]['docs'].append(i.document)

    latest_articles = qs.order_by('created_by')[:5]
    popular_articles = qs.order_by('views').reverse()[:5]

    return render(request, 'webapp/knowledge-base.html', {'qs': qs, 'articles': articles, 'latest_articles': latest_articles,
                                                          'popular_articles': popular_articles, })


@login_required(login_url='/login')
def scripts(request):
    scripts_qs = Scripts.objects.all().order_by('name')
    events_qs = Events.objects.all()
    jobs_qs = Jobs.objects.all()
    job_failed_today = jobs_qs.filter(start__date=datetime.today().date(), end__isnull=False, result='FAILED').count()
    avg_job_duration = round(jobs_qs.aggregate(Avg('duration'))['duration__avg'], 1) if jobs_qs.count() > 0 else 0
    return render(request, 'webapp/scripts.html', {'scripts_qs': scripts_qs, 'events_qs': events_qs,
                                                   'jobs_qs': jobs_qs, 'job_failed_today': job_failed_today,
                                                   'avg_job_duration': avg_job_duration})


@login_required(login_url='/login')
def pagerduty_muting(request):
    return render(request, 'webapp/pagerduty-muting.html', {})


def test(request):
    return render(request, 'webapp/test.html', {})
