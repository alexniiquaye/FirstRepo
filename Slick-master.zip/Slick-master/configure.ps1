# Please use powershell 7
param (
    [switch]$cleanup,
	[switch]$loaddata
);
$venv = Read-Host "Provide full path to you python venv (without Slick folder itself)"
$arturi = Read-Host "Provide Artifactory URI for DB file (eg.: https://artifactory.concurtech.net/artifactory/util-sandbox/srer/slick/db/db.sqlite3_2021-11-18.tar)"
$pdtoken = Read-Host "Provide PagerDuty Token."
$pdid = Read-Host "Provide PagerDuty User ID."
$region = Read-Host "Provide Region - US/EMEA/APAC."
$jirauser = Read-Host "Jira username (plain text, not hex)"
$jirapass = Read-Host "Jira password (plain text, not hex)" -maskinput
$gittoken = Read-Host "Github token"
$watchersea = Read-Host "Watcher session SEA"
$watcherpar = Read-Host "Watcher session PAR"
$watcherbei = Read-Host "Watcher session BEI"
$nrtravel = Read-Host "NR travel API key"
$nrspend = Read-Host "NR spend API key"
$nrshared = Read-Host "NR shared API key"
$nrintegration = Read-Host "NR integration API key"
$nranalytics = Read-Host "NR Analytics API key"
$nrplatform = Read-Host "NR Shared Platform API key"
$nruspscc = Read-Host "NR USPSCC API key"
$nrimaging = Read-Host "NR Imaging API key"
$nrus2 = Read-Host "NR US2 API key"
$nreu2 = Read-Host "NR EU2 API key"
$slack = Read-Host "Slack API token, leave empty if not required."
$d42user = Read-Host "d42 username"
$d42pass = Read-Host "d42 pasword" -maskinput
$slick_username = Read-Host "Slick username"
$slick_email = Read-Host "Slick email"
$slick_password = Read-Host "Slick password" -maskinput
$slick_password_conf = Read-Host "Confirm Slick pasword for login" -maskinput
if ($slick_password -ne $slick_password_conf) {
    Write-Host "Password does not match!"
	exit 1
}
Set-Location $venv
if (Test-Path -Path "$venv/Slick") {
    Write-Output "Folder already exists. Exiting..."
   exit 1
}
else {
    git clone https://github.concur.com/SRER/Slick.git
}
python3 -m venv Slick
Invoke-WebRequest https://www.sqlite.org/2021/sqlite-tools-win32-x86-3370000.zip -OutFile "$venv\sqlite.zip"
Expand-Archive -Path "$venv\sqlite.zip" -DestinationPath "$venv"
Set-Location "$venv\sqlite-tools-*"
cp .\sqlite3.exe ../
Set-Location "$venv/Slick/data"
Invoke-WebRequest ${arturi} -OutFile dbsqlite3.tgz
tar -xzf dbsqlite3.tgz
Set-Location "$venv/Slick"
write-host $venv
& "$venv\Slick\Scripts\Activate.ps1" && pip install -r src/requirements.txt
if (-Not (Test-Path -Path "$venv/Slick/src/webapp/creds.py" -PathType Leaf)) {
	New-Item "$venv/Slick/src/webapp/creds.py" -ItemType file
}
if (-Not (Get-Content "$venv/Slick/src/webapp/creds.py"|select-string -Pattern 'pd_token' -CaseSensitive -SimpleMatch -quiet)){
	Write-Output "pd_token = '$pdtoken'" >> "$venv/Slick/src/webapp/creds.py"
}	
if (-Not (Get-Content "$venv/Slick/src/webapp/creds.py"|select-string -Pattern 'jira_username' -CaseSensitive -SimpleMatch -quiet)){
	$jira_username = ("$jirauser"| Format-Hex | Select-Object -Expand Bytes | ForEach-Object { '{0:x2}' -f $_ }) -join ''
	Write-Output "jira_username = '$jira_username'" >> "$venv/Slick/src/webapp/creds.py"
}
if (-Not (Get-Content "$venv/Slick/src/webapp/creds.py"|select-string -Pattern 'jira_password' -CaseSensitive -SimpleMatch -quiet)){
	$jira_password = ("$jirapass"| Format-Hex | Select-Object -Expand Bytes | ForEach-Object { '{0:x2}' -f $_ }) -join ''
	Write-Output "jira_password = '$jira_password'" >> "$venv/Slick/src/webapp/creds.py"
}
if (-Not (Get-Content "$venv/Slick/src/webapp/creds.py"|select-string -Pattern 'github_token' -CaseSensitive -SimpleMatch -quiet)){
	Write-Output "github_token = '$gittoken'" >> "$venv/Slick/src/webapp/creds.py"
}	
if (-Not (Get-Content "$venv/Slick/src/webapp/creds.py"|select-string -Pattern 'watcher_session' -CaseSensitive -SimpleMatch -quiet)){
   Write-Output "watcher_session = {" >> "$venv/Slick/src/webapp/creds.py"
   Write-Output "    'sea': '$watchersea'," >> "$venv/Slick/src/webapp/creds.py"
   Write-Output "    'par': '$watcherpar'," >> "$venv/Slick/src/webapp/creds.py"
   Write-Output "    'sea': '$watcherbei'" >> "$venv/Slick/src/webapp/creds.py"
   Write-Output "}" >> "$venv/Slick/src/webapp/creds.py"
}
if (-Not (Get-Content "$venv/Slick/src/webapp/creds.py"|select-string -Pattern 'concur_travel__1301884' -CaseSensitive -SimpleMatch -quiet)){
	Write-Output "concur_travel__1301884 = '$nrtravel'" >> "$venv/Slick/src/webapp/creds.py"
}
if (-Not (Get-Content "$venv/Slick/src/webapp/creds.py"|select-string -Pattern 'concur_spend_management__1301883' -CaseSensitive -SimpleMatch -quiet)){
	Write-Output "concur_spend_management__1301883 = '$nrspend'" >> "$venv/Slick/src/webapp/creds.py"
}
if (-Not (Get-Content "$venv/Slick/src/webapp/creds.py"|select-string -Pattern 'concur_shared__1280715' -CaseSensitive -SimpleMatch -quiet)){
	Write-Output "concur_shared__1280715 = '$nrshared'" >> "$venv/Slick/src/webapp/creds.py"
}
if (-Not (Get-Content "$venv/Slick/src/webapp/creds.py"|select-string -Pattern 'concur_integration__2596260' -CaseSensitive -SimpleMatch -quiet)){
	Write-Output "concur_integration__2596260 = '$nrintegration'" >> "$venv/Slick/src/webapp/creds.py"
}
if (-Not (Get-Content "$venv/Slick/src/webapp/creds.py"|select-string -Pattern 'concur_analytics__1301885' -CaseSensitive -SimpleMatch -quiet)){
	Write-Output "concur_analytics__1301885 = '$nranalytics'" >> "$venv/Slick/src/webapp/creds.py"
}
if (-Not (Get-Content "$venv/Slick/src/webapp/creds.py"|select-string -Pattern 'shared_platform_services__1301887' -CaseSensitive -SimpleMatch -quiet)){
	Write-Output "shared_platform_services__1301887 = '$nrplatform'" >> "$venv/Slick/src/webapp/creds.py"
}
if (-Not (Get-Content "$venv/Slick/src/webapp/creds.py"|select-string -Pattern 'prod_uspscc_hsm__2439350' -CaseSensitive -SimpleMatch -quiet)){
	Write-Output "prod_uspscc_hsm__2439350 = '$nruspscc'" >> "$venv/Slick/src/webapp/creds.py"
}
if (-Not (Get-Content "$venv/Slick/src/webapp/creds.py"|select-string -Pattern 'concur_imaging__1301886' -CaseSensitive -SimpleMatch -quiet)){
	Write-Output "concur_imaging__1301886 = '$nrimaging'" >> "$venv/Slick/src/webapp/creds.py"
}
if (-Not (Get-Content "$venv/Slick/src/webapp/creds.py"|select-string -Pattern 'concur_us2__3111936' -CaseSensitive -SimpleMatch -quiet)){
	Write-Output "concur_us2__3111936 = '$nrus2'" >> "$venv/Slick/src/webapp/creds.py"
}
if (-Not (Get-Content "$venv/Slick/src/webapp/creds.py"|select-string -Pattern 'concur_eu2__3111938' -CaseSensitive -SimpleMatch -quiet)){
	Write-Output "concur_eu2__3111938 = '$nreu2'" >> "$venv/Slick/src/webapp/creds.py"
}
if (-Not (Get-Content "$venv/Slick/src/webapp/creds.py"|select-string -Pattern 'slack_api_token' -CaseSensitive -SimpleMatch -quiet)){
	Write-Output "slack_api_token = '$slack'" >> "$venv/Slick/src/webapp/creds.py"
}
if (-Not (Get-Content "$venv/Slick/src/webapp/creds.py"|select-string -Pattern 'device42_username' -CaseSensitive -SimpleMatch -quiet)){
	$device42_username = ("$d42user"| Format-Hex | Select-Object -Expand Bytes | ForEach-Object { '{0:x2}' -f $_ }) -join ''
	Write-Output "device42_username = '$device42_username'" >> "$venv/Slick/src/webapp/creds.py"
}
if (-Not (Get-Content "$venv/Slick/src/webapp/creds.py"|select-string -Pattern 'device42_password' -CaseSensitive -SimpleMatch -quiet)){
	$device42_password = ("$d42pass"| Format-Hex | Select-Object -Expand Bytes | ForEach-Object { '{0:x2}' -f $_ }) -join ''
	Write-Output "device42_password = '$device42_password'" >> "$venv/Slick/src/webapp/creds.py"
}
Set-Location "$venv"
if ($cleanup){
	& "$venv\Slick\Scripts\Activate.ps1" && Write-Output "from django.db.migrations.recorder import MigrationRecorder; qs = list(MigrationRecorder.Migration.objects.all().filter(name='0065_auto_20211126_0030').values_list('pk', flat=True));print(qs)"| python "$venv/Slick/src/manage.py" shell
	& "$venv\Slick\Scripts\Activate.ps1" && Write-Output "DROP TABLE IF EXISTS webapp_scripts; DROP TABLE IF EXISTS webapp_jobs;" |python "$venv/Slick/src/manage.py" dbshell
}
if ($loaddata){
	& "$venv\Slick\Scripts\Activate.ps1" && Write-Output "from webapp.scripts import migrations; migrations.main()" | python "$venv/Slick/src/manage.py" shell
}
& "$venv\Slick\Scripts\Activate.ps1" && Write-Output "from django.contrib.auth import get_user_model; User = get_user_model(); User.objects.create_superuser('$slick_username', '$slick_email', '$slick_password')" | python "$venv/Slick/src/manage.py" shell
& "$venv\Slick\Scripts\Activate.ps1" && Write-Output "from webapp.models import *; from django.contrib.auth.models import User; from webapp import creds; user = User.objects.get(username='$slick_username'); SRER.objects.update_or_create(user=user, defaults={'pagerduty_token': '$pdtoken', 'pagerduty_id': '$pdid', 'region': '$region'})" | python "$venv/Slick/src/manage.py" shell
& "$venv\Slick\Scripts\Activate.ps1" && python "$venv/Slick/src/manage.py" migrate --no-input && python "$venv/Slick/src/manage.py" runserver
