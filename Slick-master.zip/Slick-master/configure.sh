#!/bin/bash
echo "Provide full path to you python venv (without Slick folder itself)"
read -p 'Python venv: ' venv
echo "Provide Artifactory URI for DB file (eg.: https://artifactory.concurtech.net/artifactory/util-sandbox/srer/slick/db/db.sqlite3_2021-11-18.tar)"
read -p 'Python venv: ' arturi
echo "Provide PagerDuty Token."
read -p 'PD token: ' pdtoken
echo "Provide PagerDuty User ID."
read -p 'PD ID: ' pdid
echo "Provide Region - US/EMEA/APAC."
read -p 'Region: ' region
echo "Jira username (plain text, not hex)"
read -p 'Jira username: ' jirauser
echo "Jira password (plain text, not hex)"
read -p 'Jira password: ' jirapass
echo "Github token"
read -p 'Github token: ' gittoken
echo "Watcher session SEA"
read -p 'Watcher session SEA: ' watchersea
echo "Watcher session PAR"
read -p 'Watcher session PAR: ' watcherpar
echo "Watcher session BEI"
read -p 'Watcher session BEI: ' watcherbei
echo "NR travel API key"
read -p 'NR Travel: ' nrtravel
echo "NR spend API key"
read -p 'NR Spend: ' nrspend
echo "NR shared API key"
read -p 'NR Shared: ' nrshared
echo "NR integration API key"
read -p 'NR Integration: ' nrintegration
echo "NR Analytics API key"
read -p 'NR Analytics: ' nranalytics
echo "NR Shared Platform API key"
read -p 'NR Platform: ' nrplatform
echo "NR USPSCC API key"
read -p 'NR USPSCC: ' nruspscc
echo "NR Imaging API key"
read -p 'NR Imaging: ' nrimaging
echo "NR US2 API key"
read -p 'NR US2: ' nrus2
echo "NR EU2 API key"
read -p 'NR EU2: ' nreu2
echo "Slack API token, leave empty if not required."
read -p 'Slack API token: ' slack
echo "d42 username"
read -p 'D42: ' d42user
echo "d42 pasword"
read -p 'D42: ' d42pass
cd "$venv"
echo "Slick username"
read -p 'Slick username: ' slick_username
echo "Slick email"
read -p 'Slick email: ' slick_email
echo "Slick pasword for login"
read -p 'Slick password: ' slick_password
echo "Confirm Slick pasword for login"
read -p 'Confirm Slick password: ' slick_password_conf
if [[ "$slick_password" != "$slick_password_conf" ]];
then
   exit 1
fi
cd "$venv"
git clone https://github.concur.com/SRER/Slick.git
python3 -m venv Slick
cd "$venv/Slick/data"
wget ${arturi} -O dbsqlite3.tgz
tar -xzf dbsqlite3.tgz
cd "$venv/Slick"
source "${venv}/Slick/bin/activate" && pip install -r src/requirements.txt
if [ ! -f src/webapp/creds.py ]; then
  touch src/webapp/creds.py
fi
if [[ ! `grep "pd_token" src/webapp/creds.py` ]];then
   echo "pd_token = '"$pdtoken"'" >> src/webapp/creds.py
fi
if [[ ! `grep "jira_username" src/webapp/creds.py` ]];then
   jira_username=`echo -n $jirauser | od -A n -t x1 | sed 's/^ *//;s/ //g'`
   echo "jira_username = '"$jira_username"'" >> src/webapp/creds.py
fi
if [[ ! `grep "jira_password" src/webapp/creds.py` ]];then
   jira_password=`echo -n $jirapass | od -A n -t x1 | sed 's/^ *//;s/ //g'`
   echo "jira_password = '"$jira_password"'" >> src/webapp/creds.py
fi
if [[ ! `grep "github_token" src/webapp/creds.py` ]];then
   echo "github_token = '"$gittoken"'" >> src/webapp/creds.py
fi
if [[ ! `grep "watcher_session" src/webapp/creds.py` ]];then
   echo -e "watcher_session = {\n" >> src/webapp/creds.py
   echo -e "    'sea': '"$watchersea"',\n" >> src/webapp/creds.py
   echo -e "    'par': '"$watcherpar"',\n" >> src/webapp/creds.py
   echo -e "    'sea': '"$watcherbei"'\n" >> src/webapp/creds.py
   echo -e "}" >> src/webapp/creds.py
fi
if [[ ! `grep "concur_travel__1301884" src/webapp/creds.py` ]];then
   echo "concur_travel__1301884 = '"$nrtravel"'" >> src/webapp/creds.py
fi
if [[ ! `grep "concur_spend_management__1301883" src/webapp/creds.py` ]];then
   echo "concur_spend_management__1301883 = '"$nrspend"'" >> src/webapp/creds.py
fi
if [[ ! `grep "concur_shared__1280715" src/webapp/creds.py` ]];then
   echo "concur_shared__1280715 = '"$nrshared"'" >> src/webapp/creds.py
fi
if [[ ! `grep "concur_integration__2596260" src/webapp/creds.py` ]];then
   echo "concur_integration__2596260 = '"$nrintegration"'" >> src/webapp/creds.py
fi
if [[ ! `grep "concur_analytics__1301885" src/webapp/creds.py` ]];then
   echo "concur_analytics__1301885 = '"$nranalytics"'" >> src/webapp/creds.py
fi
if [[ ! `grep "shared_platform_services__1301887" src/webapp/creds.py` ]];then
   echo "shared_platform_services__1301887 = '"$nrplatform"'" >> src/webapp/creds.py
fi
if [[ ! `grep "prod_uspscc_hsm__2439350" src/webapp/creds.py` ]];then
   echo "prod_uspscc_hsm__2439350 = '"$nruspscc"'" >> src/webapp/creds.py
fi
if [[ ! `grep "concur_imaging__1301886" src/webapp/creds.py` ]];then
   echo "concur_imaging__1301886 = '"$nrimaging"'" >> src/webapp/creds.py
fi
if [[ ! `grep "concur_us2__3111936" src/webapp/creds.py` ]];then
   echo "concur_us2__3111936 = '"$nrus2"'" >> src/webapp/creds.py
fi
if [[ ! `grep "concur_eu2__3111938" src/webapp/creds.py` ]];then
   echo "concur_eu2__3111938 = '"$nreu2"'" >> src/webapp/creds.py
fi
if [[ ! `grep "slack_api_token" src/webapp/creds.py` ]];then
   echo "slack_api_token = '"$slack"'" >> src/webapp/creds.py
fi
if [[ ! `grep "device42_username" src/webapp/creds.py` ]];then
   device42_username=`echo -n $d42user | od -A n -t x1 | sed 's/^ *//;s/ //g'`
   echo "device42_username = '"$device42_username"'" >> src/webapp/creds.py
fi
if [[ ! `grep "device42_password" src/webapp/creds.py` ]];then
   device42_password=`echo -n $d42pass | od -A n -t x1 | sed 's/^ *//;s/ //g'`
   echo "device42_password = '"$device42_password"'" >> src/webapp/creds.py
fi
cd "$venv"
while getopts cl flag
do
    case "${flag}" in
        c)
          source "${venv}/Slick/bin/activate" && echo "from django.db.migrations.recorder import MigrationRecorder; qs = list(MigrationRecorder.Migration.objects.all().filter(name='0065_auto_20211126_0030').values_list('pk', flat=True));print(qs)"| python "$venv/Slick/src/manage.py" shell
	       source "${venv}/Slick/bin/activate" && echo "DROP TABLE IF EXISTS webapp_scripts; DROP TABLE IF EXISTS webapp_jobs;" |python "$venv/Slick/src/manage.py" dbshell ;;
        l) source "${venv}/Slick/bin/activate" && echo "from webapp.scripts import migrations; migrations.main()" | python "$venv/Slick/src/manage.py" shell ;;
    esac
done
source "${venv}/Slick/bin/activate" && echo "from django.contrib.auth import get_user_model; User = get_user_model(); User.objects.create_superuser('"$slick_username"', '"$slick_email"', '"$slick_password"')" | python "${venv}/Slick/src/manage.py" shell
source "${venv}/Slick/bin/activate" && echo "from webapp.models import *; from django.contrib.auth.models import User; from webapp import creds; user = User.objects.get(username="$slick_username"); SRER.objects.update_or_create(user=user, defaults={'pagerduty_token': "$pdtoken", 'pagerduty_id': "$pdid", 'region': "$region"})" | python "${venv}/Slick/src/manage.py" shell
source "${venv}/Slick/bin/activate" && python "${venv}/Slick/src/manage.py" migrate --no-input && python "${venv}/Slick/src/manage.py" runserver